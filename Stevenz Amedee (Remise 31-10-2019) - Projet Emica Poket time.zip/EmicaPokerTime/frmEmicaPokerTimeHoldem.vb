﻿Option Strict On
Imports System.IO
Public Class frmEmicaPokerTimeHoldem

    Const constStrHeaderCSV As String = "Nom;Prenom;AnneDeNaissance;Email;Psw;Money;Actif"
    Const constStringSaveData As String = "\Textes\data.csv"

    Private Sub frmEmicaPokerTimeHoldem_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'PREPARE L AFFICHAGE D'ACCUEIL EN ONLOAD
        Dim strPathImgBacground As String = "\Images\" & "imgTapis.jpg"
        Dim strPathImgLogo As String = "\Images\" & "imgLogoAS.png"

        ''OBTENIR LA HAUTEUR LARGEUR DE L ECRAN DE L UTILISATEUR
        Dim intX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intY As Integer = Screen.PrimaryScreen.Bounds.Height
        'APPEL DE FONCTION VOIR SI LE FICHIER DATA.CSV EXIT
        fntFileExist()
        'AFFECTATION DES VALEUR DE LARGEUR HAUTEUR DU FRAME
        Me.Size = New System.Drawing.Size(1362, 740)
        'POSITIONNER LE FRAME AU CENTRE DE L ECRAN
        Me.Location = New Point(CInt((intX / 2) - (Me.Width / 2)), CInt(((intY / 2) - (Me.Height / 2))))

        'AFFECTATION DES IMAGES ET LA LOCALISATION
        picBackgroundImage.Image = Image.FromFile(Application.StartupPath & strPathImgBacground)
        picLogoBCK.Image = Image.FromFile(Application.StartupPath & strPathImgLogo)
        picLogoBCK.Parent = picBackgroundImage
        picLogoBCK.Location = New Point(CInt((Me.Width / 2) - (picLogoBCK.Width / 2)), CInt(((Me.Height / 2) - (picLogoBCK.Height / 2))))
        lblTitreDuJeux.Location = New Point(CInt((picLogoBCK.Width / 2) - (lblTitreDuJeux.Width / 2)), CInt(((picLogoBCK.Height / 2) - (lblTitreDuJeux.Height / 2))))

        'TRANSPARANCE DE L IMAGE
        picLogoBCK.BackColor = Color.Transparent
        lblTitreDuJeux.Parent = picLogoBCK


        btnInscription.TabIndex = 1
        btnInscription.AutoEllipsis = True
        btnInscription.FlatStyle = FlatStyle.System

        btnMember.TabIndex = 2
        btnMember.AutoEllipsis = True
        btnMember.FlatStyle = FlatStyle.System

        btnQuitter.TabIndex = 3
        btnQuitter.AutoEllipsis = True
        btnQuitter.FlatStyle = FlatStyle.System


    End Sub

    Private Sub btnInscription_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInscription.Click

        'CACHER LA FENETRE ACTUELLE
        Me.Hide()
        'OUVIRIRE LA FENETRE FORM INSCRIPTION
        frmInscription.Show()

    End Sub

    Private Sub btnMember_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMember.Click

        'CACHER LA FENETRE ACTUELLE
        Me.Hide()
        'OUVRIRE LA FENETRE FORM DEJA MEMBRE
        frmDejaMembre.Show()

    End Sub

    Private Sub btnQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitter.Click

        'QUITTER LE JEU
        fntArretProgramme()

    End Sub

    Public Sub fntArretProgramme()

        'ARRET DU PROGRAMME
        End

    End Sub

    Public Sub fntApropos()

        'AFFICHER LE FRAME AUTEUR
        frmAPropos.Show()

    End Sub

    Public Sub fntAide()

        'APPARITON DU FORM AIDE
        frmAide.Show()

    End Sub

    Private Sub fntFileExist()

        'ON VERIRFIE SI LE FICHIER EXISTE
        If Not System.IO.File.Exists(Application.StartupPath & constStringSaveData) Then
            'SI IL EXISTE PAS ON LE CREER
            Using sw As New StreamWriter(Application.StartupPath & constStringSaveData, False)
                sw.WriteLine(constStrHeaderCSV)
                sw.Close()
            End Using
        End If

    End Sub

    Private Sub tsmDevenirMembre_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmDevenirMembre.Click

        'CACHER LA FENETRE ACTUELLE
        Me.Hide()
        'OUVIRIRE LA FENETRE FORM INSCRIPTION
        frmInscription.Show()

    End Sub

    Private Sub tsmDejaMembre_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmDejaMembre.Click

        'CACHER LA FENETRE ACTUELLE
        Me.Hide()
        'OUVRIRE LA FENETRE FORM DEJA MEMBRE
        frmDejaMembre.Show()

    End Sub

    Private Sub tsmQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmQuitter.Click

        'QUITTER
        fntArretProgramme()

    End Sub

    Private Sub tsmAide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAide.Click

        'APPEL DE FONCTION
        fntAide()

    End Sub

    Private Sub tsmAPropos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAPropos.Click

        'APPEL DE LA FORM AUTEJR
        frmAPropos.Show()

    End Sub

End Class
