﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGamePlay
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmGamePlay))
        Me.mnsMenuPoker = New System.Windows.Forms.MenuStrip()
        Me.tsmItemJeux = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmCommencer = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSauvegarder = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDéconnecter = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmQuitter = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAide = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAPropos = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmGameRules = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblCroupier = New System.Windows.Forms.Label()
        Me.lblJoueur = New System.Windows.Forms.Label()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.btnFold = New System.Windows.Forms.Button()
        Me.btnRaiseDonw = New System.Windows.Forms.Button()
        Me.lblMontant = New System.Windows.Forms.Label()
        Me.btnRaiseUp = New System.Windows.Forms.Button()
        Me.lblMiseJoeur = New System.Windows.Forms.Label()
        Me.btnJouer = New System.Windows.Forms.Button()
        Me.lblMiseCroupier = New System.Windows.Forms.Label()
        Me.lblBanque = New System.Windows.Forms.Label()
        Me.lblPot = New System.Windows.Forms.Label()
        Me.btnEqualiser = New System.Windows.Forms.Button()
        Me.timSauvegardeAutomatique = New System.Windows.Forms.Timer(Me.components)
        Me.btnRaiseDownCentsMille = New System.Windows.Forms.Button()
        Me.btnRaiseUpCentsMille = New System.Windows.Forms.Button()
        Me.btnAllIn = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.picMisePot = New System.Windows.Forms.PictureBox()
        Me.picCarteJoueurTwo = New System.Windows.Forms.PictureBox()
        Me.picCarteJoueurOne = New System.Windows.Forms.PictureBox()
        Me.picCarteCroupierTwo = New System.Windows.Forms.PictureBox()
        Me.picCarteCroupierOne = New System.Windows.Forms.PictureBox()
        Me.picCarteCommuneFive = New System.Windows.Forms.PictureBox()
        Me.picCarteCommuneFour = New System.Windows.Forms.PictureBox()
        Me.picCarteCommuneTree = New System.Windows.Forms.PictureBox()
        Me.picCarteCommuneTwo = New System.Windows.Forms.PictureBox()
        Me.picCarteCommuneOne = New System.Windows.Forms.PictureBox()
        Me.picBackgroundImage = New System.Windows.Forms.PictureBox()
        Me.btnCommencerLaPartie = New System.Windows.Forms.Button()
        Me.mnsMenuPoker.SuspendLayout()
        CType(Me.picMisePot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteJoueurTwo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteJoueurOne, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteCroupierTwo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteCroupierOne, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteCommuneFive, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteCommuneFour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteCommuneTree, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteCommuneTwo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCarteCommuneOne, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnsMenuPoker
        '
        Me.mnsMenuPoker.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmItemJeux, Me.tsmHelp})
        Me.mnsMenuPoker.Location = New System.Drawing.Point(0, 0)
        Me.mnsMenuPoker.Name = "mnsMenuPoker"
        Me.mnsMenuPoker.Size = New System.Drawing.Size(1346, 24)
        Me.mnsMenuPoker.TabIndex = 1
        Me.mnsMenuPoker.Text = "MenuStrip1"
        '
        'tsmItemJeux
        '
        Me.tsmItemJeux.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmCommencer, Me.tsmSauvegarder, Me.tsmDéconnecter, Me.tsmQuitter})
        Me.tsmItemJeux.Name = "tsmItemJeux"
        Me.tsmItemJeux.Size = New System.Drawing.Size(42, 20)
        Me.tsmItemJeux.Text = "Jeux"
        '
        'tsmCommencer
        '
        Me.tsmCommencer.Name = "tsmCommencer"
        Me.tsmCommencer.Size = New System.Drawing.Size(141, 22)
        Me.tsmCommencer.Text = "Commencer"
        '
        'tsmSauvegarder
        '
        Me.tsmSauvegarder.Name = "tsmSauvegarder"
        Me.tsmSauvegarder.Size = New System.Drawing.Size(141, 22)
        Me.tsmSauvegarder.Text = "Sauvegarder"
        '
        'tsmDéconnecter
        '
        Me.tsmDéconnecter.Name = "tsmDéconnecter"
        Me.tsmDéconnecter.Size = New System.Drawing.Size(141, 22)
        Me.tsmDéconnecter.Text = "Déconnecter"
        '
        'tsmQuitter
        '
        Me.tsmQuitter.Name = "tsmQuitter"
        Me.tsmQuitter.Size = New System.Drawing.Size(141, 22)
        Me.tsmQuitter.Text = "Quitter"
        '
        'tsmHelp
        '
        Me.tsmHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAide, Me.tsmAPropos, Me.tsmGameRules})
        Me.tsmHelp.Name = "tsmHelp"
        Me.tsmHelp.Size = New System.Drawing.Size(24, 20)
        Me.tsmHelp.Text = "?"
        '
        'tsmAide
        '
        Me.tsmAide.Name = "tsmAide"
        Me.tsmAide.Size = New System.Drawing.Size(140, 22)
        Me.tsmAide.Text = "Aide"
        '
        'tsmAPropos
        '
        Me.tsmAPropos.Name = "tsmAPropos"
        Me.tsmAPropos.Size = New System.Drawing.Size(140, 22)
        Me.tsmAPropos.Text = "A Propos"
        '
        'tsmGameRules
        '
        Me.tsmGameRules.Name = "tsmGameRules"
        Me.tsmGameRules.Size = New System.Drawing.Size(140, 22)
        Me.tsmGameRules.Text = "Règle du Jeu"
        '
        'lblCroupier
        '
        Me.lblCroupier.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!)
        Me.lblCroupier.ForeColor = System.Drawing.Color.White
        Me.lblCroupier.Location = New System.Drawing.Point(12, 46)
        Me.lblCroupier.Name = "lblCroupier"
        Me.lblCroupier.Size = New System.Drawing.Size(394, 55)
        Me.lblCroupier.TabIndex = 2
        Me.lblCroupier.Text = "Croupier"
        '
        'lblJoueur
        '
        Me.lblJoueur.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblJoueur.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJoueur.ForeColor = System.Drawing.Color.White
        Me.lblJoueur.Location = New System.Drawing.Point(12, 493)
        Me.lblJoueur.Name = "lblJoueur"
        Me.lblJoueur.Size = New System.Drawing.Size(448, 55)
        Me.lblJoueur.TabIndex = 3
        Me.lblJoueur.Text = "Joueur"
        '
        'btnCheck
        '
        Me.btnCheck.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCheck.AutoEllipsis = True
        Me.btnCheck.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnCheck.Enabled = False
        Me.btnCheck.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCheck.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnCheck.Location = New System.Drawing.Point(1127, 554)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(186, 68)
        Me.btnCheck.TabIndex = 6
        Me.btnCheck.Text = "Check"
        Me.btnCheck.UseVisualStyleBackColor = False
        '
        'btnFold
        '
        Me.btnFold.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnFold.AutoEllipsis = True
        Me.btnFold.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnFold.Enabled = False
        Me.btnFold.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFold.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnFold.Location = New System.Drawing.Point(1127, 480)
        Me.btnFold.Name = "btnFold"
        Me.btnFold.Size = New System.Drawing.Size(186, 68)
        Me.btnFold.TabIndex = 5
        Me.btnFold.Text = "FOLD"
        Me.btnFold.UseVisualStyleBackColor = False
        '
        'btnRaiseDonw
        '
        Me.btnRaiseDonw.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRaiseDonw.AutoEllipsis = True
        Me.btnRaiseDonw.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRaiseDonw.Enabled = False
        Me.btnRaiseDonw.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRaiseDonw.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRaiseDonw.Location = New System.Drawing.Point(935, 629)
        Me.btnRaiseDonw.Name = "btnRaiseDonw"
        Me.btnRaiseDonw.Size = New System.Drawing.Size(186, 68)
        Me.btnRaiseDonw.TabIndex = 4
        Me.btnRaiseDonw.Text = "Diminuer la mise X 1,000$"
        Me.btnRaiseDonw.UseVisualStyleBackColor = False
        '
        'lblMontant
        '
        Me.lblMontant.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblMontant.BackColor = System.Drawing.Color.Transparent
        Me.lblMontant.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMontant.ForeColor = System.Drawing.Color.White
        Me.lblMontant.Location = New System.Drawing.Point(12, 617)
        Me.lblMontant.Name = "lblMontant"
        Me.lblMontant.Size = New System.Drawing.Size(448, 73)
        Me.lblMontant.TabIndex = 7
        Me.lblMontant.Text = "50"
        Me.lblMontant.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnRaiseUp
        '
        Me.btnRaiseUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRaiseUp.AutoEllipsis = True
        Me.btnRaiseUp.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRaiseUp.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRaiseUp.Location = New System.Drawing.Point(935, 554)
        Me.btnRaiseUp.Name = "btnRaiseUp"
        Me.btnRaiseUp.Size = New System.Drawing.Size(186, 68)
        Me.btnRaiseUp.TabIndex = 3
        Me.btnRaiseUp.Text = "Augmenter la mise X 1,000$"
        Me.btnRaiseUp.UseVisualStyleBackColor = False
        '
        'lblMiseJoeur
        '
        Me.lblMiseJoeur.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!)
        Me.lblMiseJoeur.ForeColor = System.Drawing.Color.White
        Me.lblMiseJoeur.Location = New System.Drawing.Point(12, 554)
        Me.lblMiseJoeur.Name = "lblMiseJoeur"
        Me.lblMiseJoeur.Size = New System.Drawing.Size(448, 50)
        Me.lblMiseJoeur.TabIndex = 18
        Me.lblMiseJoeur.Text = "0"
        Me.lblMiseJoeur.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnJouer
        '
        Me.btnJouer.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnJouer.AutoEllipsis = True
        Me.btnJouer.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnJouer.Enabled = False
        Me.btnJouer.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnJouer.Location = New System.Drawing.Point(1127, 629)
        Me.btnJouer.Name = "btnJouer"
        Me.btnJouer.Size = New System.Drawing.Size(186, 68)
        Me.btnJouer.TabIndex = 9
        Me.btnJouer.Text = "Miser"
        Me.btnJouer.UseVisualStyleBackColor = False
        '
        'lblMiseCroupier
        '
        Me.lblMiseCroupier.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!)
        Me.lblMiseCroupier.ForeColor = System.Drawing.Color.White
        Me.lblMiseCroupier.Location = New System.Drawing.Point(12, 112)
        Me.lblMiseCroupier.Name = "lblMiseCroupier"
        Me.lblMiseCroupier.Size = New System.Drawing.Size(411, 50)
        Me.lblMiseCroupier.TabIndex = 21
        Me.lblMiseCroupier.Text = "0"
        Me.lblMiseCroupier.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblBanque
        '
        Me.lblBanque.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!)
        Me.lblBanque.ForeColor = System.Drawing.Color.White
        Me.lblBanque.Location = New System.Drawing.Point(792, 46)
        Me.lblBanque.Name = "lblBanque"
        Me.lblBanque.Size = New System.Drawing.Size(521, 165)
        Me.lblBanque.TabIndex = 22
        Me.lblBanque.Text = "La Banque"
        '
        'lblPot
        '
        Me.lblPot.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblPot.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPot.ForeColor = System.Drawing.Color.White
        Me.lblPot.Location = New System.Drawing.Point(935, 211)
        Me.lblPot.Name = "lblPot"
        Me.lblPot.Size = New System.Drawing.Size(378, 35)
        Me.lblPot.TabIndex = 24
        Me.lblPot.Text = "0"
        Me.lblPot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnEqualiser
        '
        Me.btnEqualiser.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEqualiser.AutoEllipsis = True
        Me.btnEqualiser.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnEqualiser.Enabled = False
        Me.btnEqualiser.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnEqualiser.Location = New System.Drawing.Point(935, 480)
        Me.btnEqualiser.Name = "btnEqualiser"
        Me.btnEqualiser.Size = New System.Drawing.Size(186, 68)
        Me.btnEqualiser.TabIndex = 7
        Me.btnEqualiser.Tag = "8"
        Me.btnEqualiser.Text = "Egaliser"
        Me.btnEqualiser.UseVisualStyleBackColor = False
        Me.btnEqualiser.Visible = False
        '
        'timSauvegardeAutomatique
        '
        Me.timSauvegardeAutomatique.Interval = 300000
        '
        'btnRaiseDownCentsMille
        '
        Me.btnRaiseDownCentsMille.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRaiseDownCentsMille.AutoEllipsis = True
        Me.btnRaiseDownCentsMille.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRaiseDownCentsMille.Enabled = False
        Me.btnRaiseDownCentsMille.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRaiseDownCentsMille.Location = New System.Drawing.Point(743, 628)
        Me.btnRaiseDownCentsMille.Name = "btnRaiseDownCentsMille"
        Me.btnRaiseDownCentsMille.Size = New System.Drawing.Size(186, 68)
        Me.btnRaiseDownCentsMille.TabIndex = 2
        Me.btnRaiseDownCentsMille.Text = "Diminuer la mise X 100,000$"
        Me.btnRaiseDownCentsMille.UseVisualStyleBackColor = False
        '
        'btnRaiseUpCentsMille
        '
        Me.btnRaiseUpCentsMille.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRaiseUpCentsMille.AutoEllipsis = True
        Me.btnRaiseUpCentsMille.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRaiseUpCentsMille.Enabled = False
        Me.btnRaiseUpCentsMille.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRaiseUpCentsMille.Location = New System.Drawing.Point(743, 554)
        Me.btnRaiseUpCentsMille.Name = "btnRaiseUpCentsMille"
        Me.btnRaiseUpCentsMille.Size = New System.Drawing.Size(186, 68)
        Me.btnRaiseUpCentsMille.TabIndex = 1
        Me.btnRaiseUpCentsMille.Text = "Augmenter la mise X 100,000$"
        Me.btnRaiseUpCentsMille.UseVisualStyleBackColor = False
        '
        'btnAllIn
        '
        Me.btnAllIn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAllIn.AutoEllipsis = True
        Me.btnAllIn.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnAllIn.Enabled = False
        Me.btnAllIn.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnAllIn.Location = New System.Drawing.Point(466, 628)
        Me.btnAllIn.Name = "btnAllIn"
        Me.btnAllIn.Size = New System.Drawing.Size(271, 69)
        Me.btnAllIn.TabIndex = 8
        Me.btnAllIn.Text = "All In"
        Me.btnAllIn.UseVisualStyleBackColor = False
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'picMisePot
        '
        Me.picMisePot.Location = New System.Drawing.Point(935, 249)
        Me.picMisePot.Name = "picMisePot"
        Me.picMisePot.Size = New System.Drawing.Size(378, 225)
        Me.picMisePot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMisePot.TabIndex = 23
        Me.picMisePot.TabStop = False
        '
        'picCarteJoueurTwo
        '
        Me.picCarteJoueurTwo.Location = New System.Drawing.Point(629, 433)
        Me.picCarteJoueurTwo.Name = "picCarteJoueurTwo"
        Me.picCarteJoueurTwo.Size = New System.Drawing.Size(108, 178)
        Me.picCarteJoueurTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteJoueurTwo.TabIndex = 16
        Me.picCarteJoueurTwo.TabStop = False
        '
        'picCarteJoueurOne
        '
        Me.picCarteJoueurOne.Location = New System.Drawing.Point(466, 433)
        Me.picCarteJoueurOne.Name = "picCarteJoueurOne"
        Me.picCarteJoueurOne.Size = New System.Drawing.Size(108, 178)
        Me.picCarteJoueurOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteJoueurOne.TabIndex = 15
        Me.picCarteJoueurOne.TabStop = False
        '
        'picCarteCroupierTwo
        '
        Me.picCarteCroupierTwo.Location = New System.Drawing.Point(629, 46)
        Me.picCarteCroupierTwo.Name = "picCarteCroupierTwo"
        Me.picCarteCroupierTwo.Size = New System.Drawing.Size(108, 178)
        Me.picCarteCroupierTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteCroupierTwo.TabIndex = 14
        Me.picCarteCroupierTwo.TabStop = False
        '
        'picCarteCroupierOne
        '
        Me.picCarteCroupierOne.Location = New System.Drawing.Point(466, 46)
        Me.picCarteCroupierOne.Name = "picCarteCroupierOne"
        Me.picCarteCroupierOne.Size = New System.Drawing.Size(108, 173)
        Me.picCarteCroupierOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteCroupierOne.TabIndex = 13
        Me.picCarteCroupierOne.TabStop = False
        '
        'picCarteCommuneFive
        '
        Me.picCarteCommuneFive.Location = New System.Drawing.Point(772, 239)
        Me.picCarteCommuneFive.Name = "picCarteCommuneFive"
        Me.picCarteCommuneFive.Size = New System.Drawing.Size(108, 178)
        Me.picCarteCommuneFive.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteCommuneFive.TabIndex = 12
        Me.picCarteCommuneFive.TabStop = False
        '
        'picCarteCommuneFour
        '
        Me.picCarteCommuneFour.Location = New System.Drawing.Point(657, 239)
        Me.picCarteCommuneFour.Name = "picCarteCommuneFour"
        Me.picCarteCommuneFour.Size = New System.Drawing.Size(108, 178)
        Me.picCarteCommuneFour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteCommuneFour.TabIndex = 11
        Me.picCarteCommuneFour.TabStop = False
        '
        'picCarteCommuneTree
        '
        Me.picCarteCommuneTree.Location = New System.Drawing.Point(543, 239)
        Me.picCarteCommuneTree.Name = "picCarteCommuneTree"
        Me.picCarteCommuneTree.Size = New System.Drawing.Size(108, 178)
        Me.picCarteCommuneTree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteCommuneTree.TabIndex = 10
        Me.picCarteCommuneTree.TabStop = False
        '
        'picCarteCommuneTwo
        '
        Me.picCarteCommuneTwo.Location = New System.Drawing.Point(429, 239)
        Me.picCarteCommuneTwo.Name = "picCarteCommuneTwo"
        Me.picCarteCommuneTwo.Size = New System.Drawing.Size(108, 178)
        Me.picCarteCommuneTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteCommuneTwo.TabIndex = 9
        Me.picCarteCommuneTwo.TabStop = False
        '
        'picCarteCommuneOne
        '
        Me.picCarteCommuneOne.BackColor = System.Drawing.Color.Transparent
        Me.picCarteCommuneOne.Location = New System.Drawing.Point(315, 239)
        Me.picCarteCommuneOne.Name = "picCarteCommuneOne"
        Me.picCarteCommuneOne.Size = New System.Drawing.Size(108, 178)
        Me.picCarteCommuneOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCarteCommuneOne.TabIndex = 8
        Me.picCarteCommuneOne.TabStop = False
        '
        'picBackgroundImage
        '
        Me.picBackgroundImage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.picBackgroundImage.Location = New System.Drawing.Point(0, 24)
        Me.picBackgroundImage.Name = "picBackgroundImage"
        Me.picBackgroundImage.Size = New System.Drawing.Size(1346, 677)
        Me.picBackgroundImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBackgroundImage.TabIndex = 0
        Me.picBackgroundImage.TabStop = False
        '
        'btnCommencerLaPartie
        '
        Me.btnCommencerLaPartie.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnCommencerLaPartie.Location = New System.Drawing.Point(466, 278)
        Me.btnCommencerLaPartie.Name = "btnCommencerLaPartie"
        Me.btnCommencerLaPartie.Size = New System.Drawing.Size(271, 94)
        Me.btnCommencerLaPartie.TabIndex = 25
        Me.btnCommencerLaPartie.Text = "Commencer"
        Me.btnCommencerLaPartie.UseVisualStyleBackColor = True
        '
        'frmGamePlay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 701)
        Me.Controls.Add(Me.btnCommencerLaPartie)
        Me.Controls.Add(Me.lblJoueur)
        Me.Controls.Add(Me.lblMiseJoeur)
        Me.Controls.Add(Me.lblMontant)
        Me.Controls.Add(Me.btnAllIn)
        Me.Controls.Add(Me.btnRaiseUpCentsMille)
        Me.Controls.Add(Me.btnRaiseDownCentsMille)
        Me.Controls.Add(Me.btnEqualiser)
        Me.Controls.Add(Me.lblPot)
        Me.Controls.Add(Me.picMisePot)
        Me.Controls.Add(Me.lblBanque)
        Me.Controls.Add(Me.lblMiseCroupier)
        Me.Controls.Add(Me.btnJouer)
        Me.Controls.Add(Me.btnRaiseUp)
        Me.Controls.Add(Me.picCarteJoueurTwo)
        Me.Controls.Add(Me.picCarteJoueurOne)
        Me.Controls.Add(Me.picCarteCroupierTwo)
        Me.Controls.Add(Me.picCarteCroupierOne)
        Me.Controls.Add(Me.picCarteCommuneFive)
        Me.Controls.Add(Me.picCarteCommuneFour)
        Me.Controls.Add(Me.picCarteCommuneTree)
        Me.Controls.Add(Me.picCarteCommuneTwo)
        Me.Controls.Add(Me.picCarteCommuneOne)
        Me.Controls.Add(Me.btnRaiseDonw)
        Me.Controls.Add(Me.btnFold)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.lblCroupier)
        Me.Controls.Add(Me.picBackgroundImage)
        Me.Controls.Add(Me.mnsMenuPoker)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnsMenuPoker
        Me.Name = "frmGamePlay"
        Me.Text = "EPTH - Emica Poker Time Holdem - Jeux"
        Me.mnsMenuPoker.ResumeLayout(False)
        Me.mnsMenuPoker.PerformLayout()
        CType(Me.picMisePot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteJoueurTwo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteJoueurOne, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteCroupierTwo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteCroupierOne, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteCommuneFive, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteCommuneFour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteCommuneTree, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteCommuneTwo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCarteCommuneOne, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picBackgroundImage As System.Windows.Forms.PictureBox
    Friend WithEvents mnsMenuPoker As System.Windows.Forms.MenuStrip
    Friend WithEvents tsmItemJeux As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmCommencer As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmSauvegarder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmQuitter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmGameRules As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblCroupier As System.Windows.Forms.Label
    Friend WithEvents lblJoueur As System.Windows.Forms.Label
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents btnFold As System.Windows.Forms.Button
    Friend WithEvents btnRaiseDonw As System.Windows.Forms.Button
    Friend WithEvents lblMontant As System.Windows.Forms.Label
    Friend WithEvents picCarteCommuneOne As System.Windows.Forms.PictureBox
    Friend WithEvents picCarteCommuneTwo As System.Windows.Forms.PictureBox
    Friend WithEvents picCarteCommuneTree As System.Windows.Forms.PictureBox
    Friend WithEvents picCarteCommuneFour As System.Windows.Forms.PictureBox
    Friend WithEvents picCarteCommuneFive As System.Windows.Forms.PictureBox
    Friend WithEvents picCarteCroupierOne As System.Windows.Forms.PictureBox
    Friend WithEvents picCarteCroupierTwo As System.Windows.Forms.PictureBox
    Friend WithEvents picCarteJoueurOne As System.Windows.Forms.PictureBox
    Friend WithEvents picCarteJoueurTwo As System.Windows.Forms.PictureBox
    Friend WithEvents tsmAide As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAPropos As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnRaiseUp As System.Windows.Forms.Button
    Friend WithEvents lblMiseJoeur As System.Windows.Forms.Label
    Friend WithEvents btnJouer As System.Windows.Forms.Button
    Friend WithEvents lblMiseCroupier As System.Windows.Forms.Label
    Friend WithEvents lblBanque As System.Windows.Forms.Label
    Friend WithEvents picMisePot As System.Windows.Forms.PictureBox
    Friend WithEvents lblPot As System.Windows.Forms.Label
    Friend WithEvents btnEqualiser As System.Windows.Forms.Button
    Friend WithEvents timSauvegardeAutomatique As System.Windows.Forms.Timer
    Friend WithEvents btnRaiseDownCentsMille As System.Windows.Forms.Button
    Friend WithEvents btnRaiseUpCentsMille As System.Windows.Forms.Button
    Friend WithEvents btnAllIn As System.Windows.Forms.Button
    Friend WithEvents tsmDéconnecter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents btnCommencerLaPartie As System.Windows.Forms.Button
End Class
