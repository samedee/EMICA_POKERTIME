﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLoading
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pgbBrassage = New System.Windows.Forms.ProgressBar()
        Me.lblProgression = New System.Windows.Forms.Label()
        Me.timTempDeBrassage = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'pgbBrassage
        '
        Me.pgbBrassage.Location = New System.Drawing.Point(34, 66)
        Me.pgbBrassage.Name = "pgbBrassage"
        Me.pgbBrassage.Size = New System.Drawing.Size(761, 23)
        Me.pgbBrassage.TabIndex = 0
        '
        'lblProgression
        '
        Me.lblProgression.AutoSize = True
        Me.lblProgression.Location = New System.Drawing.Point(397, 31)
        Me.lblProgression.Name = "lblProgression"
        Me.lblProgression.Size = New System.Drawing.Size(21, 13)
        Me.lblProgression.TabIndex = 1
        Me.lblProgression.Text = "0%"
        '
        'timTempDeBrassage
        '
        '
        'frmLoading
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(824, 124)
        Me.Controls.Add(Me.lblProgression)
        Me.Controls.Add(Me.pgbBrassage)
        Me.Name = "frmLoading"
        Me.Text = "BRASSAGE EN COUR"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pgbBrassage As System.Windows.Forms.ProgressBar
    Friend WithEvents lblProgression As System.Windows.Forms.Label
    Friend WithEvents timTempDeBrassage As System.Windows.Forms.Timer
End Class
