﻿Option Strict On
Public Class Form1

    'Declaration des constant string Carte
    Const constStrCarteAs As String = "A"
    Const constStrCarteKing As String = "K"
    Const constStrCarteQueen As String = "Q"
    Const constStrCarteJack As String = "J"
    Const constStrCarte10 As String = "10"
    Const constStrCarte9 As String = "9"
    Const constStrCarte8 As String = "8"
    Const constStrCarte7 As String = "7"
    Const constStrCarte6 As String = "6"
    Const constStrCarte5 As String = "5"
    Const constStrCarte4 As String = "4"
    Const constStrCarte3 As String = "3"
    Const constStrCarte2 As String = "2"

    Const constStrCouleurNoir As String = "Noir"
    Const constStrCouleurRouge As String = "Rouge"

    Const constStrSymboleCoeur As String = "Coeur"
    Const constStrSymboleCarre As String = "Carre"
    Const constStrSymboleTreple As String = "Treple"
    Const constStrSymbolePique As String = "Pique"

    Dim tblStrCard(52, 3) As String


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load



        '2 COEUR ROUGE
        tblStrCard(0, 0) = constStrCarte2
        tblStrCard(0, 1) = constStrSymboleCoeur
        tblStrCard(0, 2) = constStrCouleurRouge
        '2 TREFLE NOIR
        tblStrCard(1, 0) = constStrCarte2
        tblStrCard(1, 1) = constStrSymboleTreple
        tblStrCard(1, 2) = constStrCouleurNoir
        '2 CARRE ROUGE
        tblStrCard(2, 0) = constStrCarte2
        tblStrCard(2, 1) = constStrSymboleCarre
        tblStrCard(2, 2) = constStrCouleurRouge
        '2 PIQUE NOIR
        tblStrCard(3, 0) = constStrCarte2
        tblStrCard(3, 1) = constStrSymbolePique
        tblStrCard(3, 2) = constStrCouleurNoir
        '************************************************************
        '3 COEUR ROUGE
        tblStrCard(4, 0) = constStrCarte3
        tblStrCard(4, 1) = constStrSymboleCoeur
        tblStrCard(4, 2) = constStrCouleurRouge
        '3 TREFFLE NOIR
        tblStrCard(5, 0) = constStrCarte3
        tblStrCard(5, 1) = constStrSymboleTreple
        tblStrCard(5, 2) = constStrCouleurNoir
        '3 CARRE ROUGE
        tblStrCard(6, 0) = constStrCarte3
        tblStrCard(6, 1) = constStrSymboleCarre
        tblStrCard(6, 2) = constStrCouleurRouge
        '3 PIQUE NOIR
        tblStrCard(7, 0) = constStrCarte3
        tblStrCard(7, 1) = constStrSymbolePique
        tblStrCard(7, 2) = constStrCouleurNoir
        '************************************************************
        '4 COEUR ROUGE
        tblStrCard(8, 0) = constStrCarte4
        tblStrCard(8, 1) = constStrSymboleCoeur
        tblStrCard(8, 2) = constStrCouleurRouge
        '4 TREFLE NOIR
        tblStrCard(9, 0) = constStrCarte4
        tblStrCard(9, 1) = constStrSymboleTreple
        tblStrCard(9, 2) = constStrCouleurNoir
        '4 CARRE ROUGE
        tblStrCard(10, 0) = constStrCarte4
        tblStrCard(10, 1) = constStrSymboleCarre
        tblStrCard(10, 2) = constStrCouleurRouge
        '4 PIQUE NOIR
        tblStrCard(11, 0) = constStrCarte4
        tblStrCard(11, 1) = constStrSymbolePique
        tblStrCard(11, 2) = constStrCouleurNoir
        '************************************************************
        '5 COEUR ROUGE
        tblStrCard(12, 0) = constStrCarte5
        tblStrCard(12, 1) = constStrSymboleCoeur
        tblStrCard(12, 2) = constStrCouleurRouge
        '5 TREFLE NOIR
        tblStrCard(13, 0) = constStrCarte5
        tblStrCard(13, 1) = constStrSymboleTreple
        tblStrCard(13, 2) = constStrCouleurNoir
        '5 CARRE ROUGE
        tblStrCard(14, 0) = constStrCarte5
        tblStrCard(14, 1) = constStrSymboleCarre
        tblStrCard(14, 2) = constStrCouleurRouge
        '5 PIQUE NOIR
        tblStrCard(15, 0) = constStrCarte5
        tblStrCard(15, 1) = constStrSymbolePique
        tblStrCard(15, 2) = constStrCouleurNoir
        '************************************************************
        '6 COEUR ROUGE
        tblStrCard(16, 0) = constStrCarte6
        tblStrCard(16, 1) = constStrSymboleCoeur
        tblStrCard(16, 2) = constStrCouleurRouge
        '6 TREFLE NOIR
        tblStrCard(17, 0) = constStrCarte6
        tblStrCard(17, 1) = constStrSymboleTreple
        tblStrCard(17, 2) = constStrCouleurNoir
        '6 CARRE ROUGE
        tblStrCard(18, 0) = constStrCarte6
        tblStrCard(18, 1) = constStrSymboleCarre
        tblStrCard(18, 2) = constStrCouleurRouge
        '6 PIQUE NOIR
        tblStrCard(19, 0) = constStrCarte6
        tblStrCard(19, 1) = constStrSymbolePique
        tblStrCard(19, 2) = constStrCouleurNoir
        '************************************************************
        '7 COEUR ROUGE
        tblStrCard(20, 0) = constStrCarte7
        tblStrCard(20, 1) = constStrSymboleCoeur
        tblStrCard(20, 2) = constStrCouleurRouge
        '7 TREFLE NOIR
        tblStrCard(21, 0) = constStrCarte7
        tblStrCard(21, 1) = constStrSymboleTreple
        tblStrCard(21, 2) = constStrCouleurNoir
        '7 CARRE ROUGE
        tblStrCard(22, 0) = constStrCarte7
        tblStrCard(22, 1) = constStrSymboleCarre
        tblStrCard(22, 2) = constStrCouleurRouge
        '7 PIQUE NOIR
        tblStrCard(23, 0) = constStrCarte7
        tblStrCard(23, 1) = constStrSymbolePique
        tblStrCard(23, 2) = constStrCouleurNoir
        '************************************************************
        '8 COEUR ROUGE
        tblStrCard(24, 0) = constStrCarte8
        tblStrCard(24, 1) = constStrSymboleCoeur
        tblStrCard(24, 2) = constStrCouleurRouge
        '8 TREFLE NOIR
        tblStrCard(25, 0) = constStrCarte8
        tblStrCard(25, 1) = constStrSymboleTreple
        tblStrCard(25, 2) = constStrCouleurNoir
        '8 CARRE ROUGE
        tblStrCard(26, 0) = constStrCarte8
        tblStrCard(26, 1) = constStrSymboleCarre
        tblStrCard(26, 2) = constStrCouleurRouge
        '8 PIQUE NOIR
        tblStrCard(27, 0) = constStrCarte8
        tblStrCard(27, 1) = constStrSymbolePique
        tblStrCard(27, 2) = constStrCouleurNoir
        '************************************************************
        '9 COEUR ROUGE
        tblStrCard(28, 0) = constStrCarte9
        tblStrCard(28, 1) = constStrSymboleCoeur
        tblStrCard(28, 2) = constStrCouleurRouge
        '9 TREFLE NOIR
        tblStrCard(29, 0) = constStrCarte9
        tblStrCard(29, 1) = constStrSymboleTreple
        tblStrCard(29, 2) = constStrCouleurNoir
        '9 CARRE ROUGE
        tblStrCard(30, 0) = constStrCarte9
        tblStrCard(30, 1) = constStrSymboleCarre
        tblStrCard(30, 2) = constStrCouleurRouge
        '9 PIQUE NOIR
        tblStrCard(31, 0) = constStrCarte9
        tblStrCard(31, 1) = constStrSymbolePique
        tblStrCard(31, 2) = constStrCouleurNoir
        '************************************************************
        '10 COEUR ROUGE
        tblStrCard(32, 0) = constStrCarte10
        tblStrCard(32, 1) = constStrSymboleCoeur
        tblStrCard(32, 2) = constStrCouleurRouge
        '10 TREFLE NOIR
        tblStrCard(33, 0) = constStrCarte10
        tblStrCard(33, 1) = constStrSymboleTreple
        tblStrCard(33, 2) = constStrCouleurNoir
        '10 CARRE ROUGE
        tblStrCard(34, 0) = constStrCarte10
        tblStrCard(34, 1) = constStrSymboleCarre
        tblStrCard(34, 2) = constStrCouleurRouge
        '10 PIQUE NOIR
        tblStrCard(35, 0) = constStrCarte10
        tblStrCard(35, 1) = constStrSymbolePique
        tblStrCard(35, 2) = constStrCouleurNoir
        '************************************************************
        'J COEUR ROUGE
        tblStrCard(36, 0) = constStrCarteJack
        tblStrCard(36, 1) = constStrSymboleCoeur
        tblStrCard(36, 2) = constStrCouleurRouge
        'J TREFLE NOIR
        tblStrCard(37, 0) = constStrCarteJack
        tblStrCard(37, 1) = constStrSymboleTreple
        tblStrCard(37, 2) = constStrCouleurNoir
        'J CARRE ROUGE
        tblStrCard(38, 0) = constStrCarteJack
        tblStrCard(38, 1) = constStrSymboleCarre
        tblStrCard(38, 2) = constStrCouleurRouge
        'J PIQUE NOIR
        tblStrCard(39, 0) = constStrCarteJack
        tblStrCard(39, 1) = constStrSymbolePique
        tblStrCard(39, 2) = constStrCouleurNoir
        '************************************************************
        'Q COEUR ROUGE
        tblStrCard(40, 0) = constStrCarteQueen
        tblStrCard(40, 1) = constStrSymboleCoeur
        tblStrCard(40, 2) = constStrCouleurRouge
        'Q TREFLE NOIR
        tblStrCard(41, 0) = constStrCarteQueen
        tblStrCard(41, 1) = constStrSymboleTreple
        tblStrCard(41, 2) = constStrCouleurNoir
        'Q CARRE ROUGE
        tblStrCard(42, 0) = constStrCarteQueen
        tblStrCard(42, 1) = constStrSymboleCarre
        tblStrCard(42, 2) = constStrCouleurRouge
        'Q PIQUE NOIR
        tblStrCard(43, 0) = constStrCarteQueen
        tblStrCard(43, 1) = constStrSymbolePique
        tblStrCard(43, 2) = constStrCouleurNoir
        '************************************************************
        'K COUER ROUGE
        tblStrCard(44, 0) = constStrCarteKing
        tblStrCard(44, 1) = constStrSymboleCoeur
        tblStrCard(44, 2) = constStrCouleurRouge
        'K TREFLE NOIR
        tblStrCard(45, 0) = constStrCarteKing
        tblStrCard(45, 1) = constStrSymboleTreple
        tblStrCard(45, 2) = constStrCouleurNoir
        'K CARRE ROUGE
        tblStrCard(46, 0) = constStrCarteKing
        tblStrCard(46, 1) = constStrSymboleCarre
        tblStrCard(46, 2) = constStrCouleurRouge
        'K PIQUE NOIR
        tblStrCard(47, 0) = constStrCarteKing
        tblStrCard(47, 1) = constStrSymbolePique
        tblStrCard(47, 2) = constStrCouleurNoir
        '************************************************************
        'AS COEUR ROUGE
        tblStrCard(48, 0) = constStrCarteAs
        tblStrCard(48, 1) = constStrSymboleCoeur
        tblStrCard(48, 2) = constStrCouleurRouge
        'AS TREFLE NOIR
        tblStrCard(49, 0) = constStrCarteAs
        tblStrCard(49, 1) = constStrSymboleTreple
        tblStrCard(49, 2) = constStrCouleurNoir
        'AS CARRE ROUGE
        tblStrCard(50, 0) = constStrCarteAs
        tblStrCard(50, 1) = constStrSymboleCarre
        tblStrCard(50, 2) = constStrCouleurRouge
        'AS PIQUE NOIR
        tblStrCard(51, 0) = constStrCarteAs
        tblStrCard(51, 1) = constStrSymbolePique
        tblStrCard(51, 2) = constStrCouleurNoir
        '************************************************************

    End Sub

    Private Function fncCoupageEtBrassageDeCarte(ByVal tblCard(,) As String) As String(,)

        Dim tblStrPaquetGauge(26, 3) As String
        Dim tblStrPaquetDroite(26, 3) As String

        '******************************************************************
        'COUPAGE SELON LE HASARD DU TEMPS EN SECONDE
        '******************************************************************

        'ON COUPE LES CARTES EN 2 PAQUETS SELON LA SECONDE SYSTEM ON COMMANCE PAR LE PAQUET DROITE OU GAUCHE EN PREMIER
        'SI LA SECONDE EST PAIRE ON COMMENCE A FAIRE UN PAQUET GAUCE
        'SINON UN PAQET DROITE
        If ((Second(TimeOfDay) Mod 2) = 0) Then
            For i = 0 To 51
                'ON COUPE LE TABLEAU DE CARTE EN 2
                'ON Y FAIT 2 PAQUETS DE CARTE
                '1 PAQUET DE GAUCHE ET 1 PAQUET DROIT
                If ((i Mod 2) = 0) Then
                    tblStrPaquetGauge(i, 0) = tblCard(i, 0)
                    tblStrPaquetGauge(i, 1) = tblCard(i, 1)
                    tblStrPaquetGauge(i, 2) = tblCard(i, 2)
                Else
                    tblStrPaquetDroite(i, 0) = tblCard(i, 0)
                    tblStrPaquetDroite(i, 1) = tblCard(i, 1)
                    tblStrPaquetDroite(i, 2) = tblCard(i, 2)
                End If
            Next
        Else
            For i = 0 To 51
                'ON COUPE LE TABLEAU DE CARTE EN 2
                'ON Y FAIT 2 PAQUETS DE CARTE
                '1 PAQUET DE GAUCHE ET 1 PAQUET DROIT
                If ((i Mod 2) = 0) Then
                    tblStrPaquetDroite(i, 0) = tblCard(i, 0)
                    tblStrPaquetDroite(i, 1) = tblCard(i, 1)
                    tblStrPaquetDroite(i, 2) = tblCard(i, 2)
                Else
                    tblStrPaquetGauge(i, 0) = tblCard(i, 0)
                    tblStrPaquetGauge(i, 1) = tblCard(i, 1)
                    tblStrPaquetGauge(i, 2) = tblCard(i, 2)
                End If
            Next
        End If

        '******************************************************************
        'COUPAGE SELON LE HASARD DU TEMPS EN SECONDE
        '******************************************************************

        'ON PREND LES 2 PAQUETS POUR EN REFAIRE UN SEUL PAQUET DE CARTE SELOND SI LA SECONDE SYSTEM EST PAIRE OU IMPAIRE
        'SI PAIRE JE MET LE PAQUET DE DROITE AU DESSUS DE CELUI DE GAUCHE
        'SINON JE MET LE PAQUET DE GAUCHE AU DESSUS DE CELUI DE DROITE
        If ((Second(TimeOfDay) Mod 2) = 0) Then
            'PAQUET DROIT
            For i = 0 To 25
                tblCard(i, 0) = tblStrPaquetDroite(i, 0)
                tblCard(i, 1) = tblStrPaquetDroite(i, 1)
                tblCard(i, 2) = tblStrPaquetDroite(i, 2)

            Next
            'PAQUET GAUCHE
            For i = 26 To 51
                tblCard(i, 0) = tblStrPaquetGauge(i, 0)
                tblCard(i, 1) = tblStrPaquetGauge(i, 1)
                tblCard(i, 2) = tblStrPaquetGauge(i, 2)
            Next
        Else
            'PAQUET GAUCHE
            For i = 0 To 25
                tblCard(i, 0) = tblStrPaquetGauge(i, 0)
                tblCard(i, 1) = tblStrPaquetGauge(i, 1)
                tblCard(i, 2) = tblStrPaquetGauge(i, 2)

            Next
            'PAQUET DROIT
            For i = 26 To 51
                tblCard(i, 0) = tblStrPaquetDroite(i, 0)
                tblCard(i, 1) = tblStrPaquetDroite(i, 1)
                tblCard(i, 2) = tblStrPaquetDroite(i, 2)
            Next
        End If

        '******************************************************************
        'BRASSAGE SELON LE HASARD DU TEMPS EN SECONDE
        '******************************************************************

        'ON COUPE LES CARTES EN 2 PAQUETS SELON LA SECONDE SYSTEM ON COMMANCE PAR LE PAQUET DROITE OU GAUCHE EN PREMIER
        'SI LA SECONDE EST PAIRE ON COMMENCE A FAIRE UN PAQUET GAUCE
        'SINON UN PAQET DROITE
        If ((Second(TimeOfDay) Mod 2) = 0) Then
            For i = 0 To 51
                'ON COUPE LE TABLEAU DE CARTE EN 2
                'ON Y FAIT 2 PAQUETS DE CARTE
                '1 PAQUET DE GAUCHE ET 1 PAQUET DROIT
                If ((i Mod 2) = 0) Then
                    tblStrPaquetGauge(i, 0) = tblCard(i, 0)
                    tblStrPaquetGauge(i, 1) = tblCard(i, 1)
                    tblStrPaquetGauge(i, 2) = tblCard(i, 2)
                Else
                    tblStrPaquetDroite(i, 0) = tblCard(i, 0)
                    tblStrPaquetDroite(i, 1) = tblCard(i, 1)
                    tblStrPaquetDroite(i, 2) = tblCard(i, 2)
                End If
            Next
        Else
            For i = 0 To 51
                'ON COUPE LE TABLEAU DE CARTE EN 2
                'ON Y FAIT 2 PAQUETS DE CARTE
                '1 PAQUET DE GAUCHE ET 1 PAQUET DROIT
                If ((i Mod 2) = 0) Then
                    tblStrPaquetDroite(i, 0) = tblCard(i, 0)
                    tblStrPaquetDroite(i, 1) = tblCard(i, 1)
                    tblStrPaquetDroite(i, 2) = tblCard(i, 2)
                Else
                    tblStrPaquetGauge(i, 0) = tblCard(i, 0)
                    tblStrPaquetGauge(i, 1) = tblCard(i, 1)
                    tblStrPaquetGauge(i, 2) = tblCard(i, 2)
                End If
            Next
        End If

        '********************************************************
        'ON BRASSE LES CARTES
        '********************************************************
        If ((Second(TimeOfDay) Mod 2) = 0) Then
            For i = 0 To 51
                If ((i Mod 2)) = 0 Then
                    tblCard(i, 0) = tblStrPaquetGauge(i, 0)
                    tblCard(i, 1) = tblStrPaquetGauge(i, 1)
                    tblCard(i, 2) = tblStrPaquetGauge(i, 2)
                Else
                    tblCard(i, 0) = tblStrPaquetDroite(i, 0)
                    tblCard(i, 1) = tblStrPaquetDroite(i, 1)
                    tblCard(i, 2) = tblStrPaquetDroite(i, 2)

                End If

            Next
        Else
            For i = 0 To 51
                If ((i Mod 2)) = 0 Then
                    tblCard(i, 0) = tblStrPaquetDroite(i, 0)
                    tblCard(i, 1) = tblStrPaquetDroite(i, 1)
                    tblCard(i, 2) = tblStrPaquetDroite(i, 2)
                Else
                    tblCard(i, 0) = tblStrPaquetGauge(i, 0)
                    tblCard(i, 1) = tblStrPaquetGauge(i, 1)
                    tblCard(i, 2) = tblStrPaquetGauge(i, 2)

                End If

            Next
        End If

        fncCoupageEtBrassageDeCarte = tblCard
    End Function

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click

    End Sub
End Class
