﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmicaPokerTimeHoldem
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEmicaPokerTimeHoldem))
        Me.tmrLoadingCart = New System.Windows.Forms.Timer(Me.components)
        Me.btnInscription = New System.Windows.Forms.Button()
        Me.btnMember = New System.Windows.Forms.Button()
        Me.btnQuitter = New System.Windows.Forms.Button()
        Me.mnsMenuPoker = New System.Windows.Forms.MenuStrip()
        Me.JeuxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDevenirMembre = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDejaMembre = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmQuitter = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAide = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAPropos = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblTitreDuJeux = New System.Windows.Forms.Label()
        Me.picLogoBCK = New System.Windows.Forms.PictureBox()
        Me.picBackgroundImage = New System.Windows.Forms.PictureBox()
        Me.mnsMenuPoker.SuspendLayout()
        CType(Me.picLogoBCK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tmrLoadingCart
        '
        Me.tmrLoadingCart.Interval = 1000
        '
        'btnInscription
        '
        Me.btnInscription.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnInscription.AutoEllipsis = True
        Me.btnInscription.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnInscription.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnInscription.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInscription.Location = New System.Drawing.Point(572, 650)
        Me.btnInscription.Name = "btnInscription"
        Me.btnInscription.Size = New System.Drawing.Size(250, 39)
        Me.btnInscription.TabIndex = 5
        Me.btnInscription.Text = "&Devenir Membre"
        Me.btnInscription.UseVisualStyleBackColor = False
        '
        'btnMember
        '
        Me.btnMember.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnMember.AutoEllipsis = True
        Me.btnMember.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnMember.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMember.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnMember.Location = New System.Drawing.Point(828, 650)
        Me.btnMember.Name = "btnMember"
        Me.btnMember.Size = New System.Drawing.Size(250, 39)
        Me.btnMember.TabIndex = 6
        Me.btnMember.Text = "Deja &Membre"
        Me.btnMember.UseVisualStyleBackColor = False
        '
        'btnQuitter
        '
        Me.btnQuitter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnQuitter.AutoEllipsis = True
        Me.btnQuitter.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnQuitter.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnQuitter.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnQuitter.Location = New System.Drawing.Point(1084, 650)
        Me.btnQuitter.Name = "btnQuitter"
        Me.btnQuitter.Size = New System.Drawing.Size(250, 39)
        Me.btnQuitter.TabIndex = 7
        Me.btnQuitter.Text = "&Quitter le jeux"
        Me.btnQuitter.UseVisualStyleBackColor = False
        '
        'mnsMenuPoker
        '
        Me.mnsMenuPoker.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JeuxToolStripMenuItem, Me.tsmHelp})
        Me.mnsMenuPoker.Location = New System.Drawing.Point(0, 0)
        Me.mnsMenuPoker.Name = "mnsMenuPoker"
        Me.mnsMenuPoker.Size = New System.Drawing.Size(1346, 24)
        Me.mnsMenuPoker.TabIndex = 8
        Me.mnsMenuPoker.Text = "MenuStrip1"
        '
        'JeuxToolStripMenuItem
        '
        Me.JeuxToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmDevenirMembre, Me.tsmDejaMembre, Me.tsmQuitter})
        Me.JeuxToolStripMenuItem.Name = "JeuxToolStripMenuItem"
        Me.JeuxToolStripMenuItem.Size = New System.Drawing.Size(42, 20)
        Me.JeuxToolStripMenuItem.Text = "Jeux"
        '
        'tsmDevenirMembre
        '
        Me.tsmDevenirMembre.Name = "tsmDevenirMembre"
        Me.tsmDevenirMembre.Size = New System.Drawing.Size(162, 22)
        Me.tsmDevenirMembre.Text = "Devenir Membre"
        '
        'tsmDejaMembre
        '
        Me.tsmDejaMembre.Name = "tsmDejaMembre"
        Me.tsmDejaMembre.Size = New System.Drawing.Size(162, 22)
        Me.tsmDejaMembre.Text = "Deja Membre"
        '
        'tsmQuitter
        '
        Me.tsmQuitter.Name = "tsmQuitter"
        Me.tsmQuitter.Size = New System.Drawing.Size(162, 22)
        Me.tsmQuitter.Text = "Quitter"
        '
        'tsmHelp
        '
        Me.tsmHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAide, Me.tsmAPropos})
        Me.tsmHelp.Name = "tsmHelp"
        Me.tsmHelp.Size = New System.Drawing.Size(24, 20)
        Me.tsmHelp.Text = "?"
        '
        'tsmAide
        '
        Me.tsmAide.Name = "tsmAide"
        Me.tsmAide.Size = New System.Drawing.Size(122, 22)
        Me.tsmAide.Text = "Aide"
        '
        'tsmAPropos
        '
        Me.tsmAPropos.Name = "tsmAPropos"
        Me.tsmAPropos.Size = New System.Drawing.Size(122, 22)
        Me.tsmAPropos.Text = "A Propos"
        '
        'lblTitreDuJeux
        '
        Me.lblTitreDuJeux.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTitreDuJeux.AutoSize = True
        Me.lblTitreDuJeux.BackColor = System.Drawing.Color.Transparent
        Me.lblTitreDuJeux.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lblTitreDuJeux.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitreDuJeux.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblTitreDuJeux.Location = New System.Drawing.Point(264, 326)
        Me.lblTitreDuJeux.Name = "lblTitreDuJeux"
        Me.lblTitreDuJeux.Size = New System.Drawing.Size(665, 60)
        Me.lblTitreDuJeux.TabIndex = 10
        Me.lblTitreDuJeux.Text = "EPTH - Émica Poker Time Holdem"
        Me.lblTitreDuJeux.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picLogoBCK
        '
        Me.picLogoBCK.Location = New System.Drawing.Point(217, 122)
        Me.picLogoBCK.Name = "picLogoBCK"
        Me.picLogoBCK.Size = New System.Drawing.Size(756, 504)
        Me.picLogoBCK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogoBCK.TabIndex = 9
        Me.picLogoBCK.TabStop = False
        '
        'picBackgroundImage
        '
        Me.picBackgroundImage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.picBackgroundImage.Location = New System.Drawing.Point(0, 24)
        Me.picBackgroundImage.Name = "picBackgroundImage"
        Me.picBackgroundImage.Size = New System.Drawing.Size(1346, 677)
        Me.picBackgroundImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBackgroundImage.TabIndex = 3
        Me.picBackgroundImage.TabStop = False
        '
        'frmEmicaPokerTimeHoldem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 701)
        Me.Controls.Add(Me.lblTitreDuJeux)
        Me.Controls.Add(Me.picLogoBCK)
        Me.Controls.Add(Me.btnQuitter)
        Me.Controls.Add(Me.btnMember)
        Me.Controls.Add(Me.btnInscription)
        Me.Controls.Add(Me.picBackgroundImage)
        Me.Controls.Add(Me.mnsMenuPoker)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnsMenuPoker
        Me.Name = "frmEmicaPokerTimeHoldem"
        Me.Text = "EPTH - Emica Poker Time Holdem"
        Me.mnsMenuPoker.ResumeLayout(False)
        Me.mnsMenuPoker.PerformLayout()
        CType(Me.picLogoBCK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tmrLoadingCart As System.Windows.Forms.Timer
    Friend WithEvents picBackgroundImage As System.Windows.Forms.PictureBox
    Friend WithEvents btnInscription As System.Windows.Forms.Button
    Friend WithEvents btnMember As System.Windows.Forms.Button
    Friend WithEvents btnQuitter As System.Windows.Forms.Button
    Friend WithEvents mnsMenuPoker As System.Windows.Forms.MenuStrip
    Friend WithEvents JeuxToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmDevenirMembre As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmDejaMembre As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmQuitter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAide As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAPropos As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblTitreDuJeux As System.Windows.Forms.Label
    Friend WithEvents picLogoBCK As System.Windows.Forms.PictureBox

End Class
