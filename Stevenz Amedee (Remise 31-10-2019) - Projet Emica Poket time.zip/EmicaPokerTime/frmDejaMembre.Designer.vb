﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDejaMembre
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDejaMembre))
        Me.picBackgroundImage = New System.Windows.Forms.PictureBox()
        Me.btnConnection = New System.Windows.Forms.Button()
        Me.btnQuitter = New System.Windows.Forms.Button()
        Me.btnQuitterConnection = New System.Windows.Forms.Button()
        Me.mnsMenuPoker = New System.Windows.Forms.MenuStrip()
        Me.JeuxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmItemAccueil = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDevenirMembre = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmQuittezLeJeux = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAideMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAPropaoMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.lblPasseword = New System.Windows.Forms.Label()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.lblMessageErreurSystem = New System.Windows.Forms.Label()
        Me.btnEffacerTout = New System.Windows.Forms.Button()
        Me.picImgJettonJoueur = New System.Windows.Forms.PictureBox()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnsMenuPoker.SuspendLayout()
        CType(Me.picImgJettonJoueur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBackgroundImage
        '
        Me.picBackgroundImage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.picBackgroundImage.Location = New System.Drawing.Point(0, 24)
        Me.picBackgroundImage.Name = "picBackgroundImage"
        Me.picBackgroundImage.Size = New System.Drawing.Size(1346, 677)
        Me.picBackgroundImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBackgroundImage.TabIndex = 0
        Me.picBackgroundImage.TabStop = False
        '
        'btnConnection
        '
        Me.btnConnection.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnConnection.AutoEllipsis = True
        Me.btnConnection.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnConnection.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnConnection.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnConnection.Location = New System.Drawing.Point(817, 650)
        Me.btnConnection.Name = "btnConnection"
        Me.btnConnection.Size = New System.Drawing.Size(250, 39)
        Me.btnConnection.TabIndex = 3
        Me.btnConnection.Text = "&Connection"
        Me.btnConnection.UseVisualStyleBackColor = False
        '
        'btnQuitter
        '
        Me.btnQuitter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnQuitter.AutoEllipsis = True
        Me.btnQuitter.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnQuitter.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnQuitter.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnQuitter.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnQuitter.Location = New System.Drawing.Point(1073, 650)
        Me.btnQuitter.Name = "btnQuitter"
        Me.btnQuitter.Size = New System.Drawing.Size(250, 39)
        Me.btnQuitter.TabIndex = 6
        Me.btnQuitter.Text = "&Quitter le jeux"
        Me.btnQuitter.UseVisualStyleBackColor = False
        '
        'btnQuitterConnection
        '
        Me.btnQuitterConnection.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnQuitterConnection.AutoEllipsis = True
        Me.btnQuitterConnection.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnQuitterConnection.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnQuitterConnection.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnQuitterConnection.Location = New System.Drawing.Point(305, 650)
        Me.btnQuitterConnection.Name = "btnQuitterConnection"
        Me.btnQuitterConnection.Size = New System.Drawing.Size(250, 39)
        Me.btnQuitterConnection.TabIndex = 5
        Me.btnQuitterConnection.Text = "&Accueil"
        Me.btnQuitterConnection.UseVisualStyleBackColor = False
        '
        'mnsMenuPoker
        '
        Me.mnsMenuPoker.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JeuxToolStripMenuItem, Me.tsmHelp})
        Me.mnsMenuPoker.Location = New System.Drawing.Point(0, 0)
        Me.mnsMenuPoker.Name = "mnsMenuPoker"
        Me.mnsMenuPoker.Size = New System.Drawing.Size(1346, 24)
        Me.mnsMenuPoker.TabIndex = 10
        Me.mnsMenuPoker.Text = "MenuStrip1"
        '
        'JeuxToolStripMenuItem
        '
        Me.JeuxToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmItemAccueil, Me.tsmDevenirMembre, Me.tsmQuittezLeJeux})
        Me.JeuxToolStripMenuItem.Name = "JeuxToolStripMenuItem"
        Me.JeuxToolStripMenuItem.Size = New System.Drawing.Size(42, 20)
        Me.JeuxToolStripMenuItem.Text = "Jeux"
        '
        'tsmItemAccueil
        '
        Me.tsmItemAccueil.Name = "tsmItemAccueil"
        Me.tsmItemAccueil.Size = New System.Drawing.Size(162, 22)
        Me.tsmItemAccueil.Text = "Accueil"
        '
        'tsmDevenirMembre
        '
        Me.tsmDevenirMembre.Name = "tsmDevenirMembre"
        Me.tsmDevenirMembre.Size = New System.Drawing.Size(162, 22)
        Me.tsmDevenirMembre.Text = "Devenir Membre"
        '
        'tsmQuittezLeJeux
        '
        Me.tsmQuittezLeJeux.Name = "tsmQuittezLeJeux"
        Me.tsmQuittezLeJeux.Size = New System.Drawing.Size(162, 22)
        Me.tsmQuittezLeJeux.Text = "Quittez"
        '
        'tsmHelp
        '
        Me.tsmHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAideMenu, Me.tsmAPropaoMenu})
        Me.tsmHelp.Name = "tsmHelp"
        Me.tsmHelp.Size = New System.Drawing.Size(24, 20)
        Me.tsmHelp.Text = "?"
        '
        'tsmAideMenu
        '
        Me.tsmAideMenu.Name = "tsmAideMenu"
        Me.tsmAideMenu.Size = New System.Drawing.Size(122, 22)
        Me.tsmAideMenu.Text = "Aide"
        '
        'tsmAPropaoMenu
        '
        Me.tsmAPropaoMenu.Name = "tsmAPropaoMenu"
        Me.tsmAPropaoMenu.Size = New System.Drawing.Size(122, 22)
        Me.tsmAPropaoMenu.Text = "A Propos"
        '
        'lblMessage
        '
        Me.lblMessage.AutoSize = True
        Me.lblMessage.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblMessage.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblMessage.Location = New System.Drawing.Point(187, 125)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(936, 60)
        Me.lblMessage.TabIndex = 1
        Me.lblMessage.Text = "Déja Membre : Entrez votre nom d'usager et mot de passe"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblUsername.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblUsername.Location = New System.Drawing.Point(352, 268)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(319, 60)
        Me.lblUsername.TabIndex = 2
        Me.lblUsername.Text = "Adresse Courriel :"
        '
        'lblPasseword
        '
        Me.lblPasseword.AutoSize = True
        Me.lblPasseword.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblPasseword.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblPasseword.Location = New System.Drawing.Point(420, 351)
        Me.lblPasseword.Name = "lblPasseword"
        Me.lblPasseword.Size = New System.Drawing.Size(251, 60)
        Me.lblPasseword.TabIndex = 3
        Me.lblPasseword.Text = "Mot de Passe"
        '
        'txtUsername
        '
        Me.txtUsername.AccessibleDescription = ""
        Me.txtUsername.AccessibleName = ""
        Me.txtUsername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtUsername.BackColor = System.Drawing.Color.LightGray
        Me.txtUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!)
        Me.txtUsername.Location = New System.Drawing.Point(740, 289)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(309, 31)
        Me.txtUsername.TabIndex = 1
        '
        'txtPassword
        '
        Me.txtPassword.BackColor = System.Drawing.Color.LightGray
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!)
        Me.txtPassword.Location = New System.Drawing.Point(740, 380)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(309, 31)
        Me.txtPassword.TabIndex = 2
        Me.txtPassword.UseSystemPasswordChar = True
        '
        'lblMessageErreurSystem
        '
        Me.lblMessageErreurSystem.Font = New System.Drawing.Font("Stencil", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessageErreurSystem.ForeColor = System.Drawing.Color.White
        Me.lblMessageErreurSystem.Location = New System.Drawing.Point(426, 483)
        Me.lblMessageErreurSystem.Name = "lblMessageErreurSystem"
        Me.lblMessageErreurSystem.Size = New System.Drawing.Size(623, 115)
        Me.lblMessageErreurSystem.TabIndex = 7
        Me.lblMessageErreurSystem.Text = "asdfadsfadsf"
        Me.lblMessageErreurSystem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnEffacerTout
        '
        Me.btnEffacerTout.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEffacerTout.AutoEllipsis = True
        Me.btnEffacerTout.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnEffacerTout.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnEffacerTout.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnEffacerTout.Location = New System.Drawing.Point(561, 650)
        Me.btnEffacerTout.Name = "btnEffacerTout"
        Me.btnEffacerTout.Size = New System.Drawing.Size(250, 39)
        Me.btnEffacerTout.TabIndex = 4
        Me.btnEffacerTout.Text = "&Effacer Tout"
        Me.btnEffacerTout.UseVisualStyleBackColor = False
        '
        'picImgJettonJoueur
        '
        Me.picImgJettonJoueur.Location = New System.Drawing.Point(23, 351)
        Me.picImgJettonJoueur.Name = "picImgJettonJoueur"
        Me.picImgJettonJoueur.Size = New System.Drawing.Size(391, 274)
        Me.picImgJettonJoueur.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picImgJettonJoueur.TabIndex = 11
        Me.picImgJettonJoueur.TabStop = False
        '
        'frmDejaMembre
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 701)
        Me.Controls.Add(Me.picImgJettonJoueur)
        Me.Controls.Add(Me.btnEffacerTout)
        Me.Controls.Add(Me.btnQuitterConnection)
        Me.Controls.Add(Me.btnQuitter)
        Me.Controls.Add(Me.lblMessageErreurSystem)
        Me.Controls.Add(Me.btnConnection)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtUsername)
        Me.Controls.Add(Me.lblPasseword)
        Me.Controls.Add(Me.lblUsername)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.picBackgroundImage)
        Me.Controls.Add(Me.mnsMenuPoker)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnsMenuPoker
        Me.Name = "frmDejaMembre"
        Me.Text = "EPTH - Emica Poker Time Holdem : Membre"
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnsMenuPoker.ResumeLayout(False)
        Me.mnsMenuPoker.PerformLayout()
        CType(Me.picImgJettonJoueur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picBackgroundImage As System.Windows.Forms.PictureBox
    Friend WithEvents btnConnection As System.Windows.Forms.Button
    Friend WithEvents btnQuitter As System.Windows.Forms.Button
    Friend WithEvents btnQuitterConnection As System.Windows.Forms.Button
    Friend WithEvents mnsMenuPoker As System.Windows.Forms.MenuStrip
    Friend WithEvents JeuxToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmItemAccueil As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmQuittezLeJeux As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAideMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAPropaoMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmDevenirMembre As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents lblUsername As System.Windows.Forms.Label
    Friend WithEvents lblPasseword As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblMessageErreurSystem As System.Windows.Forms.Label
    Friend WithEvents btnEffacerTout As System.Windows.Forms.Button
    Friend WithEvents picImgJettonJoueur As System.Windows.Forms.PictureBox
End Class
