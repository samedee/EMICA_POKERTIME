﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAide
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAide))
        Me.picBackgroundImage = New System.Windows.Forms.PictureBox()
        Me.btnFermer = New System.Windows.Forms.Button()
        Me.rtbAideMessage = New System.Windows.Forms.RichTextBox()
        Me.lblAideTitle = New System.Windows.Forms.Label()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBackgroundImage
        '
        Me.picBackgroundImage.Location = New System.Drawing.Point(-1, 0)
        Me.picBackgroundImage.Name = "picBackgroundImage"
        Me.picBackgroundImage.Size = New System.Drawing.Size(1348, 700)
        Me.picBackgroundImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBackgroundImage.TabIndex = 0
        Me.picBackgroundImage.TabStop = False
        '
        'btnFermer
        '
        Me.btnFermer.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnFermer.AutoEllipsis = True
        Me.btnFermer.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnFermer.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFermer.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnFermer.Location = New System.Drawing.Point(1069, 651)
        Me.btnFermer.Name = "btnFermer"
        Me.btnFermer.Size = New System.Drawing.Size(250, 39)
        Me.btnFermer.TabIndex = 8
        Me.btnFermer.Text = "&Fermer"
        Me.btnFermer.UseVisualStyleBackColor = False
        '
        'rtbAideMessage
        '
        Me.rtbAideMessage.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbAideMessage.Location = New System.Drawing.Point(145, 87)
        Me.rtbAideMessage.Name = "rtbAideMessage"
        Me.rtbAideMessage.ReadOnly = True
        Me.rtbAideMessage.Size = New System.Drawing.Size(876, 456)
        Me.rtbAideMessage.TabIndex = 7
        Me.rtbAideMessage.Text = resources.GetString("rtbAideMessage.Text")
        '
        'lblAideTitle
        '
        Me.lblAideTitle.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblAideTitle.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblAideTitle.Location = New System.Drawing.Point(141, 18)
        Me.lblAideTitle.Name = "lblAideTitle"
        Me.lblAideTitle.Size = New System.Drawing.Size(880, 52)
        Me.lblAideTitle.TabIndex = 6
        Me.lblAideTitle.Text = "Membre"
        '
        'frmAide
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 701)
        Me.Controls.Add(Me.rtbAideMessage)
        Me.Controls.Add(Me.lblAideTitle)
        Me.Controls.Add(Me.btnFermer)
        Me.Controls.Add(Me.picBackgroundImage)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAide"
        Me.Text = "Aide"
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picBackgroundImage As System.Windows.Forms.PictureBox
    Friend WithEvents btnFermer As System.Windows.Forms.Button
    Friend WithEvents rtbAideMessage As System.Windows.Forms.RichTextBox
    Friend WithEvents lblAideTitle As System.Windows.Forms.Label
End Class
