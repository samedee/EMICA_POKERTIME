﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReglement
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReglement))
        Me.picBackgroundImage = New System.Windows.Forms.PictureBox()
        Me.btnFermer = New System.Windows.Forms.Button()
        Me.btnAllIn = New System.Windows.Forms.Button()
        Me.btnRaiseUpCentsMille = New System.Windows.Forms.Button()
        Me.btnRaiseDownCentsMille = New System.Windows.Forms.Button()
        Me.btnEqualiser = New System.Windows.Forms.Button()
        Me.btnJouer = New System.Windows.Forms.Button()
        Me.btnRaiseUp = New System.Windows.Forms.Button()
        Me.btnRaiseDonw = New System.Windows.Forms.Button()
        Me.btnFold = New System.Windows.Forms.Button()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.lblConseilDeJeu = New System.Windows.Forms.Label()
        Me.picImgJettonJoueur = New System.Windows.Forms.PictureBox()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picImgJettonJoueur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBackgroundImage
        '
        Me.picBackgroundImage.Location = New System.Drawing.Point(0, 0)
        Me.picBackgroundImage.Name = "picBackgroundImage"
        Me.picBackgroundImage.Size = New System.Drawing.Size(1348, 703)
        Me.picBackgroundImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBackgroundImage.TabIndex = 0
        Me.picBackgroundImage.TabStop = False
        '
        'btnFermer
        '
        Me.btnFermer.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnFermer.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnFermer.Location = New System.Drawing.Point(1212, 644)
        Me.btnFermer.Name = "btnFermer"
        Me.btnFermer.Size = New System.Drawing.Size(122, 45)
        Me.btnFermer.TabIndex = 1
        Me.btnFermer.Text = "Fermer"
        Me.btnFermer.UseVisualStyleBackColor = False
        '
        'btnAllIn
        '
        Me.btnAllIn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAllIn.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnAllIn.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnAllIn.Location = New System.Drawing.Point(67, 33)
        Me.btnAllIn.Name = "btnAllIn"
        Me.btnAllIn.Size = New System.Drawing.Size(186, 69)
        Me.btnAllIn.TabIndex = 37
        Me.btnAllIn.Text = "All In"
        Me.btnAllIn.UseVisualStyleBackColor = False
        '
        'btnRaiseUpCentsMille
        '
        Me.btnRaiseUpCentsMille.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRaiseUpCentsMille.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRaiseUpCentsMille.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRaiseUpCentsMille.Location = New System.Drawing.Point(67, 108)
        Me.btnRaiseUpCentsMille.Name = "btnRaiseUpCentsMille"
        Me.btnRaiseUpCentsMille.Size = New System.Drawing.Size(186, 68)
        Me.btnRaiseUpCentsMille.TabIndex = 36
        Me.btnRaiseUpCentsMille.Text = "Augmenter la mise X 100,000$"
        Me.btnRaiseUpCentsMille.UseVisualStyleBackColor = False
        '
        'btnRaiseDownCentsMille
        '
        Me.btnRaiseDownCentsMille.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRaiseDownCentsMille.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRaiseDownCentsMille.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRaiseDownCentsMille.Location = New System.Drawing.Point(279, 108)
        Me.btnRaiseDownCentsMille.Name = "btnRaiseDownCentsMille"
        Me.btnRaiseDownCentsMille.Size = New System.Drawing.Size(186, 68)
        Me.btnRaiseDownCentsMille.TabIndex = 35
        Me.btnRaiseDownCentsMille.Text = "Diminuer la mise X 100,000$"
        Me.btnRaiseDownCentsMille.UseVisualStyleBackColor = False
        '
        'btnEqualiser
        '
        Me.btnEqualiser.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEqualiser.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnEqualiser.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnEqualiser.Location = New System.Drawing.Point(67, 256)
        Me.btnEqualiser.Name = "btnEqualiser"
        Me.btnEqualiser.Size = New System.Drawing.Size(186, 68)
        Me.btnEqualiser.TabIndex = 34
        Me.btnEqualiser.Text = "Egaliser"
        Me.btnEqualiser.UseVisualStyleBackColor = False
        '
        'btnJouer
        '
        Me.btnJouer.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnJouer.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnJouer.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnJouer.Location = New System.Drawing.Point(279, 34)
        Me.btnJouer.Name = "btnJouer"
        Me.btnJouer.Size = New System.Drawing.Size(186, 68)
        Me.btnJouer.TabIndex = 33
        Me.btnJouer.Text = "Miser"
        Me.btnJouer.UseVisualStyleBackColor = False
        '
        'btnRaiseUp
        '
        Me.btnRaiseUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRaiseUp.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRaiseUp.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRaiseUp.Location = New System.Drawing.Point(67, 182)
        Me.btnRaiseUp.Name = "btnRaiseUp"
        Me.btnRaiseUp.Size = New System.Drawing.Size(186, 68)
        Me.btnRaiseUp.TabIndex = 32
        Me.btnRaiseUp.Text = "Augmenter la mise X 1,000$"
        Me.btnRaiseUp.UseVisualStyleBackColor = False
        '
        'btnRaiseDonw
        '
        Me.btnRaiseDonw.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRaiseDonw.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRaiseDonw.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRaiseDonw.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRaiseDonw.Location = New System.Drawing.Point(279, 182)
        Me.btnRaiseDonw.Name = "btnRaiseDonw"
        Me.btnRaiseDonw.Size = New System.Drawing.Size(186, 68)
        Me.btnRaiseDonw.TabIndex = 31
        Me.btnRaiseDonw.Text = "Diminuer la mise X 1,000$"
        Me.btnRaiseDonw.UseVisualStyleBackColor = False
        '
        'btnFold
        '
        Me.btnFold.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnFold.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnFold.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFold.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnFold.Location = New System.Drawing.Point(279, 256)
        Me.btnFold.Name = "btnFold"
        Me.btnFold.Size = New System.Drawing.Size(186, 68)
        Me.btnFold.TabIndex = 30
        Me.btnFold.Text = "FOLD"
        Me.btnFold.UseVisualStyleBackColor = False
        '
        'btnCheck
        '
        Me.btnCheck.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCheck.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnCheck.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCheck.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnCheck.Location = New System.Drawing.Point(67, 330)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(186, 68)
        Me.btnCheck.TabIndex = 29
        Me.btnCheck.Text = "Check"
        Me.btnCheck.UseVisualStyleBackColor = False
        '
        'lblMessage
        '
        Me.lblMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.Location = New System.Drawing.Point(540, 34)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(644, 216)
        Me.lblMessage.TabIndex = 38
        Me.lblMessage.Text = "Pour commencer une nouvelle partie, Cliquez dans le menu Jeu et option Commencer"
        '
        'lblConseilDeJeu
        '
        Me.lblConseilDeJeu.Font = New System.Drawing.Font("Old English Text MT", 27.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConseilDeJeu.Location = New System.Drawing.Point(128, 586)
        Me.lblConseilDeJeu.Name = "lblConseilDeJeu"
        Me.lblConseilDeJeu.Size = New System.Drawing.Size(855, 68)
        Me.lblConseilDeJeu.TabIndex = 39
        Me.lblConseilDeJeu.Text = "N'oubliez jamais le jeu, ce doit de rester un jeu" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'picImgJettonJoueur
        '
        Me.picImgJettonJoueur.Location = New System.Drawing.Point(609, 298)
        Me.picImgJettonJoueur.Name = "picImgJettonJoueur"
        Me.picImgJettonJoueur.Size = New System.Drawing.Size(558, 260)
        Me.picImgJettonJoueur.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picImgJettonJoueur.TabIndex = 40
        Me.picImgJettonJoueur.TabStop = False
        '
        'frmReglement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 701)
        Me.Controls.Add(Me.picImgJettonJoueur)
        Me.Controls.Add(Me.lblConseilDeJeu)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.btnAllIn)
        Me.Controls.Add(Me.btnRaiseUpCentsMille)
        Me.Controls.Add(Me.btnRaiseDownCentsMille)
        Me.Controls.Add(Me.btnEqualiser)
        Me.Controls.Add(Me.btnJouer)
        Me.Controls.Add(Me.btnRaiseUp)
        Me.Controls.Add(Me.btnRaiseDonw)
        Me.Controls.Add(Me.btnFold)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.btnFermer)
        Me.Controls.Add(Me.picBackgroundImage)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmReglement"
        Me.Text = "Reglement"
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picImgJettonJoueur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picBackgroundImage As System.Windows.Forms.PictureBox
    Friend WithEvents btnFermer As System.Windows.Forms.Button
    Friend WithEvents btnAllIn As System.Windows.Forms.Button
    Friend WithEvents btnRaiseUpCentsMille As System.Windows.Forms.Button
    Friend WithEvents btnRaiseDownCentsMille As System.Windows.Forms.Button
    Friend WithEvents btnEqualiser As System.Windows.Forms.Button
    Friend WithEvents btnJouer As System.Windows.Forms.Button
    Friend WithEvents btnRaiseUp As System.Windows.Forms.Button
    Friend WithEvents btnRaiseDonw As System.Windows.Forms.Button
    Friend WithEvents btnFold As System.Windows.Forms.Button
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents lblConseilDeJeu As System.Windows.Forms.Label
    Friend WithEvents picImgJettonJoueur As System.Windows.Forms.PictureBox
End Class
