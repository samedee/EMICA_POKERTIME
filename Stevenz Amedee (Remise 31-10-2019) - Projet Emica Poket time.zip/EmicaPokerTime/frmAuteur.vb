﻿Option Strict On
Public Class frmAPropos

    Private Sub frmAuteur_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim strPathImgBacground As String = "\Images\" & "imgAuteurStevenzAmedee.jpg"

        Dim intWidthX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intheightY As Integer = Screen.PrimaryScreen.Bounds.Height

        'AFFECTATION DES VALEUR DE LARGEUR HAUTEUR DU FRAME
        Me.Size = New System.Drawing.Size(1362, 740)
        'POSITIONNER LE FRAME AU CENTRE DE L ECRAN
        Me.Location = New Point(CInt((intWidthX / 2) - (Me.Width / 2)), CInt(((intheightY / 2) - (Me.Height / 2))))

        'AFFECTATION DES IMAGES ET LA LOCALISATION
        picBackgroundImage.Image = Image.FromFile(Application.StartupPath & strPathImgBacground)
        lblAuteur.Parent = picBackgroundImage
        lblAuteur.BackColor = Color.Transparent

    End Sub

    Private Sub btnFermer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFermer.Click

        'FERMER LE FRAME
        Me.Hide()

    End Sub

End Class