﻿Option Strict On
Public Class frmLoading

    Const constIntSecondeDansMinute As Integer = 60
    Const constIntPourcentage As Integer = 100
    Public intProgression As Integer

    Private Sub frmLoading_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim intStep As Integer = CInt((intProgression / constIntSecondeDansMinute))
        Dim intPourcentage As Double = CDbl((intStep / constIntPourcentage))

        'INITIALISATION DE LA BARRE DE PROGRESSION
        pgbBrassage.Minimum = 0
        pgbBrassage.Maximum = CInt(intPourcentage)
        pgbBrassage.Step = intStep

    End Sub

    Public Sub subFonctionBrassageEnCour()

        Dim intPourcentage As Integer = CInt((pgbBrassage.Value / constIntPourcentage))

        pgbBrassage.Value += pgbBrassage.Step
        pgbBrassage.Refresh()
        lblProgression.Text = intPourcentage & "%"


    End Sub
End Class