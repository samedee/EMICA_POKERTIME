﻿Option Strict On
Imports System.IO
Public Class frmInscription

    'CONSTANCE POUR LA DOYENNE AGE
    Const constIntDoyenne As Integer = 150
    Const constIntMageur As Integer = 18

    'CONSTANCE MSG ERREUR
    Const constStrErreurSaissi As String = "Erreur : Veuillez entrer votre : "
    Const constStrErreurUserExit As String = "Erreur-CE01 : Compte existant si vous avec oublier votre mot de passe," & vbCr & "communiquez avec l'administration."
    Const constStrErreurNonMajeur As String = "Désolé ce jeu est réservé au 18 ans et +. "
    Const constStrErreurAnneDeNaissance As String = "Année de naissance."
    Const constStrErreurNom As String = "Nom."
    Const constStrErreurPrenom As String = "Prénom."
    Const constStrErreurUsager As String = "Adresse Courriel"
    Const constStrErreurUsagerInvalide As String = "Adresse courrielle invalide."
    Const constStrErreurPSW As String = "Mot de passe."

    'CONSTANTE DU FICHIER SAVE DATA
    Const constStringSaveData As String = "\Textes\data.csv"

    'CONSTANTE DE MESSAGE DE BIENVENU
    Const constStrMerci As String = "Merci "
    Const constStrMembreDe As String = "Vous etes maintenant membre de EPTH,"
    Const constStrUserNameIs As String = "Votre nom d'usager est : "
    Const constStrUserPSW As String = "N'oubliez pas de concerver votre mot de passe"
    Const constStrSucces As String = "Inscription réussi : "
    Const constStrSeparateur As String = ";"
    Const constStrDefaultAmount As String = "1000000"

    Dim strPlayer As String

    Private Sub btnRegister_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRegister.Click

        strPlayer = (txtUsername.Text).ToLower
        'L USAGER N EXISTE PAS ON LE CREE
        If Not fntUsernameExist(strPlayer) Then
            subFntSauvegarderNouvelleUtilisateur()
        Else
            'ERREUR L USAGER EXIST DEJA
            fntMessageJoueur(constStrErreurUserExit)
        End If

    End Sub

    Private Function fntUsernameExist(ByVal strUsername As String) As Boolean

        'VERIFIE SI CE NOM D UTILISATEUR EXIST DEJA
        Dim bolUserExist As Boolean = False
        Dim strUser As String

        Using MyReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(Application.StartupPath & constStringSaveData)
            MyReader.TextFieldType = FileIO.FieldType.Delimited
            MyReader.SetDelimiters(constStrSeparateur)

            'TABLEAU D INFORMATION DE LA LIGNE EN COURS
            Dim currentRow As String()

            While Not MyReader.EndOfData
                Try
                    'ON LIE TOUTES LES LIGNE DU CVS ET JE VEUX LE CHAMP A LA POSITION 4 DANS LE DOCUMENT
                    currentRow = MyReader.ReadFields()
                    strUser = currentRow(3)

                    'EXIT DE FORCE DE LA BOUCLE WHILE DES QUE J AI TROUVER MON USER
                    If (strUser = strUsername) Then
                        'J AI TROUVE LE USER
                        bolUserExist = True
                        Exit While
                    End If
                Catch ex As Exception

                End Try
            End While

        End Using

        fntUsernameExist = bolUserExist

    End Function

    Private Sub subFntSauvegarderNouvelleUtilisateur()
        'DECLARATION DES VARIABLES
        Dim strNom As String
        Dim strPrenom As String
        Dim strAnneeDeNaissance As String
        Dim strUsager As String
        Dim strPSW As String
        Dim intAnneeEnCours As Integer = Date.Now.Year
        Dim intAge As Integer
        Dim strSubString As String = ""
        Dim intPosition As Integer = -1

        'SAISSIR L ANNEE DE NAISSANCE
        strAnneeDeNaissance = txtDateOfBorn.Text
        'VERIFIER QUE ANNEE DE NAISSANCE SOIS NUMÉRIQUE
        If IsNumeric(strAnneeDeNaissance) Then
            intAge = intAnneeEnCours - CInt(strAnneeDeNaissance)
            'NOT (EST CE QUE L AGE EST SUPERIEUR OU EGALE A LA MAJORITER ET PLUS PETIT OU EGALE A LA DOYENNE)
            If intAge < constIntMageur Then
                'MESSAGE D ERREUR
                fntMessageJoueur(constStrErreurNonMajeur)
                Me.Hide()
                frmEmicaPokerTimeHoldem.Show()
            ElseIf Not ((intAge >= constIntMageur) And (intAge <= constIntDoyenne)) Then
                'MESSAGE D ERREUR
                fntMessageJoueur(constStrErreurSaissi & constStrErreurAnneDeNaissance)
            Else
                'VÉRIFICATION DU NOM
                strNom = txtFirstName.Text
                If String.IsNullOrWhiteSpace(strNom) Then
                    'MESSAGE D ERREUR
                    fntMessageJoueur(constStrErreurSaissi & constStrErreurNom)
                Else
                    'VERIFICATION DU PRÉNOM
                    strPrenom = txtLastName.Text
                    If String.IsNullOrWhiteSpace(strPrenom) Then
                        'MESSAGE D ERREUR
                        fntMessageJoueur(constStrErreurSaissi & constStrErreurPrenom)
                    Else
                        'VÉRIFICATION DU USERNAME ET LE METTRE EN MINUSCULE
                        'ON VERIFIE QUE CE SOIT UNE ADRESSE COURRIEL
                        strUsager = (txtUsername.Text).ToLower
                        strSubString = txtUsername.Text
                        If ((Not strUsager.Contains("@")) And (Not strUsager.Contains("."))) Then
                            'MESSAGE D ERREUR EMAIL INVALIDE
                            fntMessageJoueur(constStrErreurSaissi & constStrErreurUsagerInvalide)
                            'ElseIf (strSubString.Length > 4) Then
                            '    strSubString = Strings.Right(strSubString, 4)
                            '    intPosition = strSubString.IndexOf(".")
                            '    If Not (intPosition = 0) Then
                            '        fntMessageJoueur(constStrErreurSaissi & constStrErreurUsagerInvalide)
                            '    End If
                        ElseIf String.IsNullOrWhiteSpace(strUsager) Then
                            'MESSAGE D ERREUR
                            fntMessageJoueur(constStrErreurSaissi & constStrErreurUsager)
                        Else
                            'VÉRIFICATION DU PSW
                            strPSW = (txtPassword.Text).ToLower
                            If String.IsNullOrWhiteSpace(strPSW) Then
                                'MESSAGE D ERREUR
                                fntMessageJoueur(constStrErreurSaissi & constStrErreurPSW)
                            Else
                                'ENREGISTREMENT DU NOUVEAU JOUEUR
                                Dim fichierData As String = Application.StartupPath & constStringSaveData
                                If System.IO.File.Exists(fichierData) = True Then

                                    Dim objWriter As New System.IO.StreamWriter(fichierData, True)
                                    Dim strData As String
                                    strData = strNom & constStrSeparateur & strPrenom & constStrSeparateur & strAnneeDeNaissance & constStrSeparateur & strUsager & constStrSeparateur & strPSW & constStrSeparateur & constStrDefaultAmount & constStrSeparateur & True & vbCr
                                    objWriter.Write(strData)
                                    objWriter.Close()

                                    'MESSAGE DE BIENVENU
                                    Dim strBienvenu As String = vbCr & constStrMerci & strPrenom & " " & strNom & "." & vbCr & constStrMembreDe & vbCr & constStrUserNameIs & strUsager & vbCr & constStrUserPSW
                                    MessageBox.Show(constStrSucces & vbCr & strBienvenu)

                                End If

                                'ON FERME LA PAGE ACTUEL ET ON OUVRE LE FRAME GAME PLAY.
                                Me.Hide()
                                frmGamePlay.strPlayer = strUsager
                                frmGamePlay.strNomPrenom = strPrenom & " " & strNom
                                frmGamePlay.strAmount = constStrDefaultAmount
                                frmGamePlay.Show()
                            End If
                        End If
                    End If
                End If
            End If
        Else
            'MESSAGE D ERREUR
            fntMessageJoueur(constStrErreurSaissi & constStrErreurAnneDeNaissance)
        End If

    End Sub

    Private Sub frmInscription_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim strImgBackgroundPath As String = "\Images\" & "imgTapis.jpg"
        Dim strPathImgJettonJoueur As String = "\Images\" & "imgJettonJoueur.png"

        ''OBTENIR LA HAUTEUR LARGEUR DE L ECRAN DE L UTILISATEUR
        Dim intWidthX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intHeightY As Integer = Screen.PrimaryScreen.Bounds.Height

        'POSITIONER LE FRAME
        Me.Size = New System.Drawing.Size(1362, 740)
        Me.Location = New Point(CInt((intWidthX / 2) - (Me.Width / 2)), CInt(((intHeightY / 2) - (Me.Height / 2))))

        'AFFECTER L IMAGE BCK A SON CONTENANT
        picBackgroundImage.Image = Image.FromFile(Application.StartupPath & strImgBackgroundPath)
        picImgJettonJoueur.Image = Image.FromFile(Application.StartupPath & strPathImgJettonJoueur)

        picImgJettonJoueur.Parent = picBackgroundImage
        picImgJettonJoueur.BackColor = Color.Transparent

        'GESTION DE LA TRANSPARANCE
        lblMessage.BackColor = Color.Transparent
        lblFirstName.BackColor = Color.Transparent
        lblLastName.BackColor = Color.Transparent
        lblDateOfBorn.BackColor = Color.Transparent
        lblUserName.BackColor = Color.Transparent
        lblPasseword.BackColor = Color.Transparent

        lblMessage.Parent = picBackgroundImage
        lblFirstName.Parent = picBackgroundImage
        lblLastName.Parent = picBackgroundImage
        lblDateOfBorn.Parent = picBackgroundImage
        lblUserName.Parent = picBackgroundImage
        lblPasseword.Parent = picBackgroundImage

    End Sub

    Private Sub txtFirstName_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFirstName.LostFocus

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL PERD LE FOCUS
        txtFirstName.BackColor = Color.LightGray

    End Sub

    Private Sub txtFirstName_GotFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFirstName.TextChanged

        'SI TOUTES LES TEXTBOX SONT COMPLÉTÉ ON ACTIVE LE BOUTON REGISTER
        If (((Not String.IsNullOrEmpty(txtFirstName.Text)) And (Not String.IsNullOrEmpty(txtLastName.Text)) And (Not String.IsNullOrEmpty(txtDateOfBorn.Text)) And (Not String.IsNullOrEmpty(txtUsername.Text)) And (Not String.IsNullOrEmpty(txtPassword.Text)))) Then
            btnRegister.Enabled = True
        Else
            btnRegister.Enabled = False
        End If

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL A LE FOCUS
        txtFirstName.BackColor = Color.White

    End Sub

    Private Sub txtLastName_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLastName.LostFocus

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL PERD LE FOCUS
        txtLastName.BackColor = Color.LightGray

    End Sub

    Private Sub txtLastName_GotFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLastName.TextChanged

        'SI TOUTES LES TEXTBOX SONT COMPLÉTÉ ON ACTIVE LE BOUTON REGISTER
        If (((Not String.IsNullOrEmpty(txtFirstName.Text)) And (Not String.IsNullOrEmpty(txtLastName.Text)) And (Not String.IsNullOrEmpty(txtDateOfBorn.Text)) And (Not String.IsNullOrEmpty(txtUsername.Text)) And (Not String.IsNullOrEmpty(txtPassword.Text)))) Then
            btnRegister.Enabled = True
        Else
            btnRegister.Enabled = False
        End If

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL A LE FOCUS
        txtLastName.BackColor = Color.White

    End Sub

    Private Sub txtDateOfBorn_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDateOfBorn.LostFocus

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL PERD LE FOCUS
        txtDateOfBorn.BackColor = Color.LightGray

    End Sub

    Private Sub txtDateOfBorn_GotFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDateOfBorn.TextChanged

        'SI TOUTES LES TEXTBOX SONT COMPLÉTÉ ON ACTIVE LE BOUTON REGISTER
        If (((Not String.IsNullOrEmpty(txtFirstName.Text)) And (Not String.IsNullOrEmpty(txtLastName.Text)) And (Not String.IsNullOrEmpty(txtDateOfBorn.Text)) And (Not String.IsNullOrEmpty(txtUsername.Text)) And (Not String.IsNullOrEmpty(txtPassword.Text)))) Then
            btnRegister.Enabled = True
        Else
            btnRegister.Enabled = False
        End If

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL A LE FOCUS
        txtDateOfBorn.BackColor = Color.White

    End Sub

    Private Sub txtUsername_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtUsername.LostFocus

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL PERD LE FOCUS
        txtUsername.BackColor = Color.LightGray

    End Sub

    Private Sub txtUsername_GotFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtUsername.TextChanged

        'SI TOUTES LES TEXTBOX SONT COMPLÉTÉ ON ACTIVE LE BOUTON REGISTER
        If (((Not String.IsNullOrEmpty(txtFirstName.Text)) And (Not String.IsNullOrEmpty(txtLastName.Text)) And (Not String.IsNullOrEmpty(txtDateOfBorn.Text)) And (Not String.IsNullOrEmpty(txtUsername.Text)) And (Not String.IsNullOrEmpty(txtPassword.Text)))) Then
            btnRegister.Enabled = True
        Else
            btnRegister.Enabled = False
        End If

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL A LE FOCUS
        txtUsername.BackColor = Color.White

    End Sub

    Private Sub txtPassword_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPassword.LostFocus

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL PERD LE FOCUS
        txtPassword.BackColor = Color.LightGray

    End Sub

    Private Sub txtPassword_GotFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPassword.TextChanged

        'SI TOUTES LES TEXTBOX SONT COMPLÉTÉ ON ACTIVE LE BOUTON REGISTER
        If (((Not String.IsNullOrEmpty(txtFirstName.Text)) And (Not String.IsNullOrEmpty(txtLastName.Text)) And (Not String.IsNullOrEmpty(txtDateOfBorn.Text)) And (Not String.IsNullOrEmpty(txtUsername.Text)) And (Not String.IsNullOrEmpty(txtPassword.Text)))) Then
            btnRegister.Enabled = True
        Else
            btnRegister.Enabled = False
        End If

        'CHANGEMNT DE LA COULEUR DU BACKGROUND LORSQU IL A LE FOCUS
        txtPassword.BackColor = Color.White

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click

        'EFFACER TOUS LES CHAMPS TEXT
        txtFirstName.Clear()
        txtLastName.Clear()
        txtDateOfBorn.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        btnRegister.Enabled = False

    End Sub

    Private Sub btnQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitter.Click

        'QUITTER LE JEUX
        frmEmicaPokerTimeHoldem.fntArretProgramme()

    End Sub

    Private Sub btnQuitterInscription_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitterInscription.Click

        'QUITTER LA PAGE ACTUEL ET RETOUR A LA PAGE D ACCEUIL
        Me.Hide()
        frmEmicaPokerTimeHoldem.Show()

    End Sub

    Private Sub fntMessageJoueur(ByRef msg As String)

        'AFFICHE UN MESSAGE A L UTILISATEUR
        MsgBox(strPlayer & " : " & vbCr & msg)

    End Sub

    Private Sub tsmAccueil_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAccueil.Click

        'CACHER LE FREME ACTUEL
        Me.Hide()
        'AFFICHER LE FORM EMICA POKER TIME HOLDEM
        frmEmicaPokerTimeHoldem.Show()

    End Sub

    Private Sub tsmDejaMembre_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmDejaMembre.Click

        'QUITTER LA SECTION ACTUEL ET ALLER AU FORM DEJA MEMEBRE
        Me.Hide()
        frmDejaMembre.Show()

    End Sub

    Private Sub tsmQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmQuitter.Click

        'QUITTER LE JEUX
        frmEmicaPokerTimeHoldem.fntArretProgramme()

    End Sub

    Private Sub tsmAide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAide.Click

        'ON OUVRE LE FRAME AIDE
        frmAide.Show()

    End Sub

    Private Sub tsmAPropos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAPropos.Click

        'AFFICHER LE FRAME AUTEUR
        frmAPropos.Show()

    End Sub

End Class