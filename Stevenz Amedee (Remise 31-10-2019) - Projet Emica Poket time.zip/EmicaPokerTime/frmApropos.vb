﻿Public Class frmApropos

    Private Sub frmApropos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        picBackgroundImage.Image = Image.FromFile(Application.StartupPath & "\Images\" & "imgTapis.jpg")
    End Sub

    Private Sub btnCloseWindow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseWindow.Click
        Me.Hide()
    End Sub

End Class