﻿Option Strict On
Public Class frmGamePlay

    'NOM ET MONTANT DU JOUEUR EN COUR
    Public strPlayer As String
    Public strNomPrenom As String
    Public strAmount As String

    'PATH DU FICHIER DE SAUVEGARDE ET VALEUR DU SEPARATEUR
    Const constStringSaveData As String = "\Textes\data.csv"
    Const constStrSeparateur As String = ";"

    'MESSAGE UTILISATEUR
    Const constStrDebutPartie As String = "A vous de commencer entrez votre mise de départ"
    Const constStrWinnerCroupier As String = "Le Croupier"
    Const constStrWinner As String = "LE GAGNANT EST : "
    Const constStrFelicitation As String = " Felicitation"
    Const constStringGainDeLaMaison As String = "Gain De La Maison"
    Const constStrMontantDuPotEnCour As String = "Pot Total"
    Const constStrRelanceCroupier As String = "LE CROUPIER VOUS RELANCE DE : "
    Const constStrJeuCroupier As String = "Le jeu du Croupier est : "
    Const constStrJeuJoueur As String = "Votre jeu est : "
    Const constStrGameOver As String = "Desoler, il vous reste pu d'argent : Total "
    Const constStrSauvegarde As String = "Votre partie a été enregistrez"
    Const constStrErreurDeSauvegarde As String = "Erreur de sauvegarde le ficher " & constStringSaveData & " a ete corompu ou effacer"

    'Declaration des constant string Carte
    Const constStrCarteAs As String = "A"
    Const constStrCarteKing As String = "K"
    Const constStrCarteQueen As String = "Q"
    Const constStrCarteJack As String = "J"
    Const constStrCarte10 As String = "10"
    Const constStrCarte9 As String = "9"
    Const constStrCarte8 As String = "8"
    Const constStrCarte7 As String = "7"
    Const constStrCarte6 As String = "6"
    Const constStrCarte5 As String = "5"
    Const constStrCarte4 As String = "4"
    Const constStrCarte3 As String = "3"
    Const constStrCarte2 As String = "2"

    'DECLARARION DES COULEURS
    Const constStrCouleurNoir As String = "Noir"
    Const constStrCouleurRouge As String = "Rouge"

    'DECLARATION DES SYMBOLE COUEUR CARRE TREFLE ET PIQUE
    Const constStrSymboleCoeur As String = "Coeur"
    Const constStrSymboleCarre As String = "Carre"
    Const constStrSymboleTrefle As String = "Trefle"
    Const constStrSymbolePique As String = "Pique"

    'IMAGE COEUR ROUGE
    Const constStrCarteImgAsCoeurRouge As String = "imgACoeurRouge.jpg"
    Const constStrCarteImgKingCoeurRouge As String = "imgKCoeurRouge.jpg"
    Const constStrCarteImgQueenCoeurRouge As String = "imgQCoeurRouge.jpg"
    Const constStrCarteImgJackCoeurRouge As String = "imgJCoeurRouge.jpg"
    Const constStrCarteImg10CoeurRouge As String = "img10CoeurRouge.jpg"
    Const constStrCarteImg9CoeurRouge As String = "img9CoeurRouge.jpg"
    Const constStrCarteImg8CoeurRouge As String = "img8CoeurRouge.jpg"
    Const constStrCarteImg7CoeurRouge As String = "img7CoeurRouge.jpg"
    Const constStrCarteImg6CoeurRouge As String = "img6CoeurRouge.jpg"
    Const constStrCarteImg5CoeurRouge As String = "img5CoeurRouge.jpg"
    Const constStrCarteImg4CoeurRouge As String = "img4CoeurRouge.jpg"
    Const constStrCarteImg3CoeurRouge As String = "img3CoeurRouge.jpg"
    Const constStrCarteImg2CoeurRouge As String = "img2CoeurRouge.jpg"

    'IMAGE CARREAU ROUGE
    Const constStrCarteImgAsCarreauRouge As String = "imgACarreauRouge.jpg"
    Const constStrCarteImgKingCarreauRouge As String = "imgKCarreauRouge.jpg"
    Const constStrCarteImgQueenCarreauRouge As String = "imgQCarreauRouge.jpg"
    Const constStrCarteImgJackCarreauRouge As String = "imgJCarreauRouge.jpg"
    Const constStrCarteImg10CarreauRouge As String = "img10CarreauRouge.jpg"
    Const constStrCarteImg9CarreauRouge As String = "img9CarreauRouge.jpg"
    Const constStrCarteImg8CarreauRouge As String = "img8CarreauRouge.jpg"
    Const constStrCarteImg7CarreauRouge As String = "img7CarreauRouge.jpg"
    Const constStrCarteImg6CarreauRouge As String = "img6CarreauRouge.jpg"
    Const constStrCarteImg5CarreauRouge As String = "img5CarreauRouge.jpg"
    Const constStrCarteImg4CarreauRouge As String = "img4CarreauRouge.jpg"
    Const constStrCarteImg3CarreauRouge As String = "img3CarreauRouge.jpg"
    Const constStrCarteImg2CarreauRouge As String = "img2CarreauRouge.jpg"

    'IMAGE TREFLE NOIR
    Const constStrCarteImgAsTrefleNoir As String = "imgATrefleNoir.jpg"
    Const constStrCarteImgKingTrefleNoir As String = "imgKTrefleNoir.jpg"
    Const constStrCarteImgQueenTrefleNoir As String = "imgQTrefleNoir.jpg"
    Const constStrCarteImgJackTrefleNoir As String = "imgJTrefleNoir.jpg"
    Const constStrCarteImg10TrefleNoir As String = "img10TrefleNoir.jpg"
    Const constStrCarteImg9TrefleNoir As String = "img9TrefleNoir.jpg"
    Const constStrCarteImg8TrefleNoir As String = "img8TrefleNoir.jpg"
    Const constStrCarteImg7TrefleNoir As String = "img7TrefleNoir.jpg"
    Const constStrCarteImg6TrefleNoir As String = "img6TrefleNoir.jpg"
    Const constStrCarteImg5TrefleNoir As String = "img5TrefleNoir.jpg"
    Const constStrCarteImg4TrefleNoir As String = "img4TrefleNoir.jpg"
    Const constStrCarteImg3TrefleNoir As String = "img3TrefleNoir.jpg"
    Const constStrCarteImg2TrefleNoir As String = "img2TrefleNoir.jpg"

    'IMAGE PIQUE NOIR
    Const constStrpPathImgCarteImgAsPiqueNoir As String = "imgAPiqueNoir.jpg"
    Const constStrPathImgCarteImgKingPiqueNoir As String = "imgKPiqueNoir.jpg"
    Const constStrPathImgCarteImgQueenPiqueNoir As String = "imgQPiqueNoir.jpg"
    Const constStrPathImgCarteImgJackPiqueNoir As String = "imgJPiqueNoir.jpg"
    Const constStrPathImgCarteImg10PiqueNoir As String = "img10PiqueNoir.jpg"
    Const constStrPathImgCarteImg9PiqueNoir As String = "img9PiqueNoir.jpg"
    Const constStrPathImgCarteImg8PiqueNoir As String = "img8PiqueNoir.jpg"
    Const constStrPathImgCarteImg7PiqueNoir As String = "img7PiqueNoir.jpg"
    Const constStrPathImgCarteImg6PiqueNoir As String = "img6PiqueNoir.jpg"
    Const constStrPathImgCarteImg5PiqueNoir As String = "img5PiqueNoir.jpg"
    Const constStrPathImgCarteImg4PiqueNoir As String = "img4PiqueNoir.jpg"
    Const constStrPathImgCarteImg3PiqueNoir As String = "img3PiqueNoir.jpg"
    Const constStrPathImgCarteImg2PiqueNoir As String = "img2PiqueNoir.jpg"

    'IMAGE DU BACKGROUND DES CARTES
    Const constStrPathImgCarteBackground As String = "imgBack.jpg"

    'PATH DES IMAGES
    Const constStrImgPath As String = "\Images\"

    'FAIT UN BRASSAGE X NOMBRE DE FOIS 4 EST LE CHIFFRE CHANCEUX DE MON COLLEGUE DE CLASSE JEAN-PIERRE
    'EMILIE DAVIE
    Const constIntLuckyNumberOfJeanPierreBourgetNombre As Integer = 4
    Const constIntLuckyNumberOfEmilieDavyNombre As Integer = 7
    Const constIntLuckyNumberOfOlivierLeDouxTreamblayNombre As Integer = 5
    Const constIntLuckyNumberOfStevenzAmedeeNombre As Integer = 18

    'TABLEAU QUI VA CONTENIR MES 52 
    'DIMENSION 0 : NOMBRE
    'DIMENSION 1 : SYMBOLE COEUR, CARREAU, PIQUE ET TREFLE
    'DIMENSION 2 : COULEUR ROUGE OU NOIR
    'DIMENSION 3 : PATH IMG
    Const constIntDimensionPositionNOMBRE As Integer = 0
    Const constIntDimensionPositionSYMBOLE As Integer = 1
    Const constIntDimensionPositionCOULEUR As Integer = 2
    Const constIntDimensionPositionPATH As Integer = 3

    'DECLARATION DES TABLEAU DE CARTES
    Dim tblStrCard(51, 3) As String
    Dim tblStrCarteJoueur(6, 3) As String
    Dim tblStrCarteCroupier(6, 3) As String

    'DECLARATION DES FORCE DE JEUX DE CARTE
    Const constIntForceCarteRoyaleFlush As Integer = 10
    Const constIntForceCarteStraitFlush As Integer = 9
    Const constIntForceCarteFourOfKind As Integer = 8
    Const constIntForceCarteFullHouse As Integer = 7
    Const constIntForceCarteFlushCouleur As Integer = 6
    Const constIntForceCarteSuiteStraight As Integer = 5
    Const constIntForceCarteBrelan As Integer = 4
    Const constIntForceCarteTwoPaire As Integer = 3
    Const constIntForceCarteOnePaire As Integer = 2
    Const constIntForceCarteHishCard As Integer = 1

    'DECLARATION DES FORCE DE CARTES
    Const constIntCarteAs As Integer = 13
    Const constIntCarteKing As Integer = 12
    Const constIntCarteQueen As Integer = 11
    Const constIntCarteJack As Integer = 10
    Const constIntCarte10 As Integer = 8
    Const constIntCarte9 As Integer = 8
    Const constIntCarte8 As Integer = 7
    Const constIntCarte7 As Integer = 6
    Const constIntCarte6 As Integer = 5
    Const constIntCarte5 As Integer = 4
    Const constIntCarte4 As Integer = 3
    Const constIntCarte3 As Integer = 2
    Const constIntCarte2 As Integer = 1

    'DECLARATION DES JEUX
    Const constStrForceCarteRoyaleFlush As String = "Royal Flush"
    Const constStrForceCarteStraitFlush As String = "Straight Flush"
    Const constStrForceCarteFourOfKind As String = "Four Of Kind"
    Const constStrForceCarteFullHouse As String = "Full House"
    Const constStrForceCarteFlushCouleur As String = "Flush"
    Const constStrForceCarteSuiteStraight As String = "Straight"
    Const constStrForceCarteBrelan As String = "Brelan"
    Const constStrForceCarteTwoPaire As String = "Two Paire"
    Const constStrForceCarteOnePaire As String = "One Paire"
    Const constStrForceCarteHishCard As String = "High Card"

    'DECLARATION DES AFFICHAGE MONAITAIRE
    Const constStrCurrency As String = "{0:n2} $"
    Const constStrCurrencyDefaultValue As String = "0"
    Const constStrCurrencyMiseDefaultValue As String = "1000"
    Const constStrCurrencyMiseCentMilleValue As String = "100000"

    'DECLARATION DES ETAPES DU JEU
    Const constIntEtapeJeuTournageJoueur As Integer = 0
    Const constIntEtapeJeuTournageFlop As Integer = 1
    Const constIntEtapeJeuTournageTurn As Integer = 2
    Const constIntEtapeJeuTournageRiver As Integer = 3
    Const constIntEtapeJeuTournageCroupier As Integer = 4

    'CONSTANTE DE TEMP
    Const constIntMillisecondeEnSec As Integer = 1000
    Const constIntSecEnMinute As Integer = 60
    Const constIntSauvegardeAutomatique As Integer = 3

    'VARIABLE IA CROUPIER - NOMBRE DE RELACE EN COUR
    Dim intRlanceEnCour As Integer = 0

    Dim intEtapeJeuTournage As Integer = -1
    Dim intGainDeLaMaison As Integer = 0
    Dim intCompteurCarte As Integer = 0
    Dim intCagnotte As Integer = 0
    Dim bolAllIn As Boolean = False

    Private Sub frmGamePlay_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        'DECLARATION ET INITIALISATION DE LA VARIABLE PATH IMG BCK
        Dim strPathImgBackground As String = "imgTapis"
        Dim strPathImgJettonJoueur As String = "\Images\imgJettonJoueur.png"

        ''OBTENIR LA HAUTEUR LARGEUR DE L ECRAN DE L UTILISATEUR
        Dim intWidthX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intHeighY As Integer = Screen.PrimaryScreen.Bounds.Height

        'AFFECTATION DE VALEUR AUX LABELS
        lblJoueur.Text = strNomPrenom
        lblMiseCroupier.Text = fntStrCurrency(constStrCurrencyDefaultValue)
        lblPot.Text = fntStrCurrency(constStrCurrencyDefaultValue)
        lblMiseJoeur.Text = fntStrCurrency(constStrCurrencyDefaultValue)
        lblMontant.Text = fntStrCurrency(strAmount)

        'INITIALISATION DES VALEURS DE HAUTEUR ET LARGEUR DU FRAME ET POSITIONNEMETN AU CENTRE
        Me.Size = New System.Drawing.Size(1362, 740)
        Me.Location = New Point(CInt((intWidthX / 2) - (Me.Width / 2)), CInt(((intHeighY / 2) - (Me.Height / 2))))
        'AFFECTATION DU BACKGROUND IMAGE
        picBackgroundImage.Image = CType(My.Resources.ResourceManager.GetObject(strPathImgBackground), Image)
        picMisePot.Image = Image.FromFile(Application.StartupPath & strPathImgJettonJoueur)

        'GESTION DE LA TRANSPARANCE
        picMisePot.BackColor = Color.Transparent
        lblBanque.BackColor = Color.Transparent
        lblCroupier.BackColor = Color.Transparent
        lblMiseCroupier.BackColor = Color.Transparent
        lblJoueur.BackColor = Color.Transparent
        lblMiseJoeur.BackColor = Color.Transparent
        lblMontant.BackColor = Color.Transparent
        lblPot.BackColor = Color.Transparent

        picMisePot.Parent = picBackgroundImage
        lblBanque.Parent = picBackgroundImage
        lblCroupier.Parent = picBackgroundImage
        lblMiseCroupier.Parent = picBackgroundImage
        lblJoueur.Parent = picBackgroundImage
        lblMiseJoeur.Parent = picBackgroundImage
        lblMontant.Parent = picBackgroundImage
        lblPot.Parent = picBackgroundImage

        'GESTION DESIGN BUTON
        btnAllIn.TabIndex = 1
        btnAllIn.AutoEllipsis = True
        btnAllIn.FlatStyle = FlatStyle.System

        btnRaiseUpCentsMille.TabIndex = 2
        btnRaiseUpCentsMille.AutoEllipsis = True
        btnRaiseUpCentsMille.FlatStyle = FlatStyle.System

        btnRaiseDownCentsMille.TabIndex = 3
        btnRaiseDownCentsMille.AutoEllipsis = True
        btnRaiseDownCentsMille.FlatStyle = FlatStyle.System

        btnRaiseUp.TabIndex = 4
        btnRaiseUp.AutoEllipsis = True
        btnRaiseUp.FlatStyle = FlatStyle.System

        btnRaiseDonw.TabIndex = 5
        btnRaiseDonw.AutoEllipsis = True
        btnRaiseDonw.FlatStyle = FlatStyle.System

        btnFold.TabIndex = 6
        btnFold.AutoEllipsis = True
        btnFold.FlatStyle = FlatStyle.System

        btnCheck.TabIndex = 7
        btnCheck.AutoEllipsis = True
        btnCheck.FlatStyle = FlatStyle.System

        btnJouer.TabIndex = 8
        btnJouer.AutoEllipsis = True
        btnJouer.FlatStyle = FlatStyle.System

        'ON LOAD LES 52 CARTES D UN JEU DE PAQUET
        subFntLoadPaquetCard()

        'DEMARAGE DE LA SAUVEGARDE AUTOMATIQUE A TOUS LES 3 MINUTES
        timSauvegardeAutomatique.Interval = ((constIntMillisecondeEnSec * constIntSecEnMinute) * constIntSauvegardeAutomatique)
        timSauvegardeAutomatique.Enabled = True

        'AFFICHER LES IMAGES DES CARTES PAR DEFAULT
        subFntSetDefaultCarteBackgroundImage()

        'CACHER LES CARTE DU JEU
        picCarteJoueurOne.Visible = False
        picCarteJoueurTwo.Visible = False
        picCarteCommuneOne.Visible = False
        picCarteCommuneTwo.Visible = False
        picCarteCommuneTree.Visible = False
        picCarteCommuneFour.Visible = False
        picCarteCommuneFive.Visible = False
        picCarteCroupierOne.Visible = False
        picCarteCroupierTwo.Visible = False

        btnCommencerLaPartie.Visible = True
        btnCommencerLaPartie.Enabled = True


    End Sub


    Private Sub subFntLoadPaquetCard()

        'ON LOAD LES 52 CARTES D UN JEU DE PAQUET
        '2 COEUR ROUGE
        tblStrCard(0, constIntDimensionPositionNOMBRE) = constStrCarte2
        tblStrCard(0, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(0, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(0, constIntDimensionPositionPATH) = constStrCarteImg2CoeurRouge

        '2 TREFLE NOIR
        tblStrCard(1, constIntDimensionPositionNOMBRE) = constStrCarte2
        tblStrCard(1, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(1, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(1, constIntDimensionPositionPATH) = constStrCarteImg2TrefleNoir

        '2 CARRE ROUGE
        tblStrCard(2, constIntDimensionPositionNOMBRE) = constStrCarte2
        tblStrCard(2, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(2, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(2, constIntDimensionPositionPATH) = constStrCarteImg2CarreauRouge

        '2 PIQUE NOIR
        tblStrCard(3, constIntDimensionPositionNOMBRE) = constStrCarte2
        tblStrCard(3, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(3, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(3, constIntDimensionPositionPATH) = constStrPathImgCarteImg2PiqueNoir
        '************************************************************
        '3 COEUR ROUGE
        tblStrCard(4, constIntDimensionPositionNOMBRE) = constStrCarte3
        tblStrCard(4, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(4, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(4, constIntDimensionPositionPATH) = constStrCarteImg3CoeurRouge

        '3 TREFFLE NOIR
        tblStrCard(5, constIntDimensionPositionNOMBRE) = constStrCarte3
        tblStrCard(5, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(5, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(5, constIntDimensionPositionPATH) = constStrCarteImg3TrefleNoir

        '3 CARRE ROUGE
        tblStrCard(6, constIntDimensionPositionNOMBRE) = constStrCarte3
        tblStrCard(6, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(6, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(6, constIntDimensionPositionPATH) = constStrCarteImg3CarreauRouge

        '3 PIQUE NOIR
        tblStrCard(7, constIntDimensionPositionNOMBRE) = constStrCarte3
        tblStrCard(7, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(7, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(7, constIntDimensionPositionPATH) = constStrPathImgCarteImg3PiqueNoir
        '************************************************************
        '4 COEUR ROUGE
        tblStrCard(8, constIntDimensionPositionNOMBRE) = constStrCarte4
        tblStrCard(8, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(8, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(8, constIntDimensionPositionPATH) = constStrCarteImg4CoeurRouge

        '4 TREFLE NOIR
        tblStrCard(9, constIntDimensionPositionNOMBRE) = constStrCarte4
        tblStrCard(9, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(9, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(9, constIntDimensionPositionPATH) = constStrCarteImg4TrefleNoir

        '4 CARRE ROUGE
        tblStrCard(10, constIntDimensionPositionNOMBRE) = constStrCarte4
        tblStrCard(10, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(10, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(10, constIntDimensionPositionPATH) = constStrCarteImg4CarreauRouge

        '4 PIQUE NOIR
        tblStrCard(11, constIntDimensionPositionNOMBRE) = constStrCarte4
        tblStrCard(11, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(11, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(11, constIntDimensionPositionPATH) = constStrPathImgCarteImg4PiqueNoir
        '************************************************************
        '5 COEUR ROUGE
        tblStrCard(12, constIntDimensionPositionNOMBRE) = constStrCarte5
        tblStrCard(12, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(12, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(12, constIntDimensionPositionPATH) = constStrCarteImg5CoeurRouge

        '5 TREFLE NOIR
        tblStrCard(13, constIntDimensionPositionNOMBRE) = constStrCarte5
        tblStrCard(13, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(13, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(13, constIntDimensionPositionPATH) = constStrCarteImg5TrefleNoir

        '5 CARRE ROUGE
        tblStrCard(14, constIntDimensionPositionNOMBRE) = constStrCarte5
        tblStrCard(14, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(14, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(14, constIntDimensionPositionPATH) = constStrCarteImg5CarreauRouge

        '5 PIQUE NOIR
        tblStrCard(15, constIntDimensionPositionNOMBRE) = constStrCarte5
        tblStrCard(15, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(15, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(15, constIntDimensionPositionPATH) = constStrPathImgCarteImg5PiqueNoir

        '************************************************************
        '6 COEUR ROUGE
        tblStrCard(16, constIntDimensionPositionNOMBRE) = constStrCarte6
        tblStrCard(16, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(16, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(16, constIntDimensionPositionPATH) = constStrCarteImg6CoeurRouge

        '6 TREFLE NOIR
        tblStrCard(17, constIntDimensionPositionNOMBRE) = constStrCarte6
        tblStrCard(17, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(17, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(17, constIntDimensionPositionPATH) = constStrCarteImg6TrefleNoir

        '6 CARRE ROUGE
        tblStrCard(18, constIntDimensionPositionNOMBRE) = constStrCarte6
        tblStrCard(18, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(18, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(18, constIntDimensionPositionPATH) = constStrCarteImg6CarreauRouge

        '6 PIQUE NOIR
        tblStrCard(19, constIntDimensionPositionNOMBRE) = constStrCarte6
        tblStrCard(19, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(19, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(19, constIntDimensionPositionPATH) = constStrPathImgCarteImg6PiqueNoir
        '************************************************************
        '7 COEUR ROUGE
        tblStrCard(20, constIntDimensionPositionNOMBRE) = constStrCarte7
        tblStrCard(20, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(20, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(20, constIntDimensionPositionPATH) = constStrCarteImg7CoeurRouge

        '7 TREFLE NOIR
        tblStrCard(21, constIntDimensionPositionNOMBRE) = constStrCarte7
        tblStrCard(21, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(21, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(21, constIntDimensionPositionPATH) = constStrCarteImg7TrefleNoir

        '7 CARRE ROUGE
        tblStrCard(22, constIntDimensionPositionNOMBRE) = constStrCarte7
        tblStrCard(22, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(22, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(22, constIntDimensionPositionPATH) = constStrCarteImg7CarreauRouge

        '7 PIQUE NOIR
        tblStrCard(23, constIntDimensionPositionNOMBRE) = constStrCarte7
        tblStrCard(23, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(23, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(23, constIntDimensionPositionPATH) = constStrPathImgCarteImg7PiqueNoir

        '************************************************************
        '8 COEUR ROUGE
        tblStrCard(24, constIntDimensionPositionNOMBRE) = constStrCarte8
        tblStrCard(24, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(24, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(24, constIntDimensionPositionPATH) = constStrCarteImg8CoeurRouge

        '8 TREFLE NOIR
        tblStrCard(25, constIntDimensionPositionNOMBRE) = constStrCarte8
        tblStrCard(25, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(25, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(25, constIntDimensionPositionPATH) = constStrCarteImg8TrefleNoir

        '8 CARRE ROUGE
        tblStrCard(26, constIntDimensionPositionNOMBRE) = constStrCarte8
        tblStrCard(26, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(26, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(26, constIntDimensionPositionPATH) = constStrCarteImg8CarreauRouge

        '8 PIQUE NOIR
        tblStrCard(27, constIntDimensionPositionNOMBRE) = constStrCarte8
        tblStrCard(27, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(27, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(27, constIntDimensionPositionPATH) = constStrPathImgCarteImg8PiqueNoir

        '************************************************************
        '9 COEUR ROUGE
        tblStrCard(28, constIntDimensionPositionNOMBRE) = constStrCarte9
        tblStrCard(28, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(28, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(28, constIntDimensionPositionPATH) = constStrCarteImg9CoeurRouge

        '9 TREFLE NOIR
        tblStrCard(29, constIntDimensionPositionNOMBRE) = constStrCarte9
        tblStrCard(29, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(29, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(29, constIntDimensionPositionPATH) = constStrCarteImg9TrefleNoir

        '9 CARRE ROUGE
        tblStrCard(30, constIntDimensionPositionNOMBRE) = constStrCarte9
        tblStrCard(30, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(30, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(30, constIntDimensionPositionPATH) = constStrCarteImg9CarreauRouge

        '9 PIQUE NOIR
        tblStrCard(31, constIntDimensionPositionNOMBRE) = constStrCarte9
        tblStrCard(31, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(31, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(31, constIntDimensionPositionPATH) = constStrPathImgCarteImg9PiqueNoir

        '************************************************************
        '10 COEUR ROUGE
        tblStrCard(32, constIntDimensionPositionNOMBRE) = constStrCarte10
        tblStrCard(32, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(32, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(32, constIntDimensionPositionPATH) = constStrCarteImg10CoeurRouge

        '10 TREFLE NOIR
        tblStrCard(33, constIntDimensionPositionNOMBRE) = constStrCarte10
        tblStrCard(33, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(33, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(33, constIntDimensionPositionPATH) = constStrCarteImg10TrefleNoir

        '10 CARRE ROUGE
        tblStrCard(34, constIntDimensionPositionNOMBRE) = constStrCarte10
        tblStrCard(34, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(34, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(34, constIntDimensionPositionPATH) = constStrCarteImg10CarreauRouge

        '10 PIQUE NOIR
        tblStrCard(35, constIntDimensionPositionNOMBRE) = constStrCarte10
        tblStrCard(35, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(35, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(35, constIntDimensionPositionPATH) = constStrPathImgCarteImg10PiqueNoir

        '************************************************************
        'J COEUR ROUGE
        tblStrCard(36, constIntDimensionPositionNOMBRE) = constStrCarteJack
        tblStrCard(36, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(36, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(36, constIntDimensionPositionPATH) = constStrCarteImgJackCoeurRouge

        'J TREFLE NOIR
        tblStrCard(37, constIntDimensionPositionNOMBRE) = constStrCarteJack
        tblStrCard(37, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(37, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(37, constIntDimensionPositionPATH) = constStrCarteImgJackTrefleNoir

        'J CARRE ROUGE
        tblStrCard(38, constIntDimensionPositionNOMBRE) = constStrCarteJack
        tblStrCard(38, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(38, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(38, constIntDimensionPositionPATH) = constStrCarteImgJackCarreauRouge

        'J PIQUE NOIR
        tblStrCard(39, constIntDimensionPositionNOMBRE) = constStrCarteJack
        tblStrCard(39, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(39, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(39, constIntDimensionPositionPATH) = constStrPathImgCarteImgJackPiqueNoir

        '************************************************************
        'Q COEUR ROUGE
        tblStrCard(40, constIntDimensionPositionNOMBRE) = constStrCarteQueen
        tblStrCard(40, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(40, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(40, constIntDimensionPositionPATH) = constStrCarteImgQueenCoeurRouge

        'Q TREFLE NOIR
        tblStrCard(41, constIntDimensionPositionNOMBRE) = constStrCarteQueen
        tblStrCard(41, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(41, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(41, constIntDimensionPositionPATH) = constStrCarteImgQueenTrefleNoir

        'Q CARRE ROUGE
        tblStrCard(42, constIntDimensionPositionNOMBRE) = constStrCarteQueen
        tblStrCard(42, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(42, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(42, constIntDimensionPositionPATH) = constStrCarteImgQueenCarreauRouge

        'Q PIQUE NOIR
        tblStrCard(43, constIntDimensionPositionNOMBRE) = constStrCarteQueen
        tblStrCard(43, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(43, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(43, constIntDimensionPositionPATH) = constStrPathImgCarteImgQueenPiqueNoir

        '************************************************************
        'K COUER ROUGE
        tblStrCard(44, constIntDimensionPositionNOMBRE) = constStrCarteKing
        tblStrCard(44, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(44, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(44, constIntDimensionPositionPATH) = constStrCarteImgKingCoeurRouge

        'K TREFLE NOIR
        tblStrCard(45, constIntDimensionPositionNOMBRE) = constStrCarteKing
        tblStrCard(45, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(45, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(45, constIntDimensionPositionPATH) = constStrCarteImgKingTrefleNoir

        'K CARRE ROUGE
        tblStrCard(46, constIntDimensionPositionNOMBRE) = constStrCarteKing
        tblStrCard(46, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(46, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(46, constIntDimensionPositionPATH) = constStrCarteImgKingCarreauRouge

        'K PIQUE NOIR
        tblStrCard(47, constIntDimensionPositionNOMBRE) = constStrCarteKing
        tblStrCard(47, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(47, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(47, constIntDimensionPositionPATH) = constStrPathImgCarteImgKingPiqueNoir
        '************************************************************
        'AS COEUR ROUGE
        tblStrCard(48, constIntDimensionPositionNOMBRE) = constStrCarteAs
        tblStrCard(48, constIntDimensionPositionSYMBOLE) = constStrSymboleCoeur
        tblStrCard(48, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(48, constIntDimensionPositionPATH) = constStrCarteImgAsCoeurRouge

        'AS TREFLE NOIR
        tblStrCard(49, constIntDimensionPositionNOMBRE) = constStrCarteAs
        tblStrCard(49, constIntDimensionPositionSYMBOLE) = constStrSymboleTrefle
        tblStrCard(49, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(49, constIntDimensionPositionPATH) = constStrCarteImgAsTrefleNoir

        'AS CARRE ROUGE
        tblStrCard(50, constIntDimensionPositionNOMBRE) = constStrCarteAs
        tblStrCard(50, constIntDimensionPositionSYMBOLE) = constStrSymboleCarre
        tblStrCard(50, constIntDimensionPositionCOULEUR) = constStrCouleurRouge
        tblStrCard(50, constIntDimensionPositionPATH) = constStrCarteImgAsCarreauRouge

        'AS PIQUE NOIR
        tblStrCard(51, constIntDimensionPositionNOMBRE) = constStrCarteAs
        tblStrCard(51, constIntDimensionPositionSYMBOLE) = constStrSymbolePique
        tblStrCard(51, constIntDimensionPositionCOULEUR) = constStrCouleurNoir
        tblStrCard(51, constIntDimensionPositionPATH) = constStrpPathImgCarteImgAsPiqueNoir
        '************************************************************


    End Sub

    Private Sub subFntCommencerLaPartier()

        'COMMENCER LE JEU  = LE PROGRAMME COMMENCE ICI
        Dim intRandom As Integer
        Dim intRandomDebut As Integer
        Dim intRandomFin As Integer
        Dim intRandomExtra As Integer

        'INITIALISATION DES VARIABLE DE DEPART
        intCompteurCarte = 0
        intRlanceEnCour = 0
        ReDim tblStrCarteJoueur(6, 3)
        ReDim tblStrCarteCroupier(6, 3)

        'Random de 1 a Second(TimeOfDay)
        intRandom = CInt((Second(TimeOfDay) * Rnd()) + constIntLuckyNumberOfEmilieDavyNombre)
        intRandomExtra = CInt(Second(TimeOfDay) * Rnd()) + 1

        'RANDOM DE BRASSAGE
        For j = 0 To intRandomExtra
            intRandomDebut = -(constIntLuckyNumberOfOlivierLeDouxTreamblayNombre * Second(TimeOfDay))
            intRandomFin = ((intRandom * constIntLuckyNumberOfJeanPierreBourgetNombre) + (constIntLuckyNumberOfStevenzAmedeeNombre * (Second(TimeOfDay))))
            'DOUBLE DE RANDOM BRASSAGE - BOUCLE DANS UNE BOUCLE
            For i As Integer = intRandomDebut To intRandomFin
                tblStrCard = fntCoupageEtBrassageDeCarte(tblStrCard)
            Next

        Next


        'AFFICHER LES IMAGES PAR DEFAULT
        subFntSetDefaultCarteBackgroundImage()

        'ON AFFICHE LES BOUTONS POUR JOUER SELON SI LE JOEUR A DE L ARGENT OU PAS
        If (CInt(lblMontant.Text) = 0) Then
            btnRaiseUpCentsMille.Visible = False
            btnRaiseUp.Visible = False
            btnAllIn.Visible = False
            btnFold.Visible = False
            btnCheck.Visible = False
            btnJouer.Visible = False
            btnAllIn.Visible = False
            btnRaiseDonw.Visible = False
            btnRaiseDownCentsMille.Visible = False
            subFntSauveGarderLaPartie(False)
        Else
            ' ON RE AFFICHE LES BOUTONS
            btnRaiseUpCentsMille.Enabled = True
            btnRaiseUp.Enabled = True
            btnAllIn.Enabled = True
            btnFold.Enabled = False
            btnCheck.Enabled = False
            btnJouer.Enabled = False

            'MESSAGE UTILISATEUR
            subFntMessageJoueur(constStrDebutPartie)
        End If

        'METTRE VISIBLE LES CARTES
        If Not picCarteJoueurOne.Visible Then
            btnCommencerLaPartie.Enabled = False
            btnCommencerLaPartie.Visible = False

            picCarteJoueurOne.Visible = True
            picCarteJoueurTwo.Visible = True
            picCarteCommuneOne.Visible = True
            picCarteCommuneTwo.Visible = True
            picCarteCommuneTree.Visible = True
            picCarteCommuneFour.Visible = True
            picCarteCommuneFive.Visible = True
            picCarteCroupierOne.Visible = True
            picCarteCroupierTwo.Visible = True
        End If
        

    End Sub

    Private Sub subFntSetDefaultCarteBackgroundImage()

        'SUB FUNCTION QUI GERE LES IMAGE DES CARTES MIS PAR DEFAUT AU DEPART
        'CARTE DU JOUEUR
        picCarteJoueurOne.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)
        picCarteJoueurTwo.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)

        'CARTE COMMUNE
        picCarteCommuneOne.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)
        picCarteCommuneTwo.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)
        picCarteCommuneTree.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)
        picCarteCommuneFour.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)
        picCarteCommuneFive.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)

        'CARTE DU CROUPIER
        picCarteCroupierOne.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)
        picCarteCroupierTwo.Image = Image.FromFile(Application.StartupPath & constStrImgPath & constStrPathImgCarteBackground)

    End Sub

    Private Function fntCoupageEtBrassageDeCarte(ByVal tblCard(,) As String) As String(,)

        'BRASSAGE ET COUPAGE DE CARTE
        Dim tblStrPaquetGauge(25, 3) As String
        Dim tblStrPaquetDroite(25, 3) As String
        Dim intDroitCompteur As Integer = 0
        Dim intGaucheCompteur As Integer = 0
        '******************************************************************
        'COUPAGE SELON LE HASARD DU TEMPS EN SECONDE
        '******************************************************************

        'ON COUPE LES CARTES EN 2 PAQUETS SELON LA SECONDE SYSTEM ON COMMANCE PAR LE PAQUET DROITE OU GAUCHE EN PREMIER
        'SI LA SECONDE EST PAIRE ON COMMENCE A FAIRE UN PAQUET GAUCE
        'SINON UN PAQET DROITE
        If ((Second(TimeOfDay) Mod 2) = 0) Then
            For i = 0 To 51
                'ON COUPE LE TABLEAU DE CARTE EN 2
                'ON Y FAIT 2 PAQUETS DE CARTE
                '1 PAQUET DE GAUCHE ET 1 PAQUET DROIT
                If ((i Mod 2) = 0) Then
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionNOMBRE) = tblCard(i, constIntDimensionPositionNOMBRE)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionSYMBOLE) = tblCard(i, constIntDimensionPositionSYMBOLE)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionCOULEUR) = tblCard(i, constIntDimensionPositionCOULEUR)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionPATH) = tblCard(i, constIntDimensionPositionPATH)
                    intGaucheCompteur += 1
                Else
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionNOMBRE) = tblCard(i, constIntDimensionPositionNOMBRE)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionSYMBOLE) = tblCard(i, constIntDimensionPositionSYMBOLE)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionCOULEUR) = tblCard(i, constIntDimensionPositionCOULEUR)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionPATH) = tblCard(i, constIntDimensionPositionPATH)
                    intDroitCompteur += 1
                End If
            Next
        Else
            For i = 0 To 51
                'ON COUPE LE TABLEAU DE CARTE EN 2
                'ON Y FAIT 2 PAQUETS DE CARTE
                '1 PAQUET DE GAUCHE ET 1 PAQUET DROIT
                If ((i Mod 2) = 0) Then
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionNOMBRE) = tblCard(i, constIntDimensionPositionNOMBRE)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionSYMBOLE) = tblCard(i, constIntDimensionPositionSYMBOLE)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionCOULEUR) = tblCard(i, constIntDimensionPositionCOULEUR)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionPATH) = tblCard(i, constIntDimensionPositionPATH)
                    intDroitCompteur += 1
                Else
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionNOMBRE) = tblCard(i, constIntDimensionPositionNOMBRE)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionSYMBOLE) = tblCard(i, constIntDimensionPositionSYMBOLE)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionCOULEUR) = tblCard(i, constIntDimensionPositionCOULEUR)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionPATH) = tblCard(i, constIntDimensionPositionPATH)
                    intGaucheCompteur += 1
                End If
            Next
        End If

        '******************************************************************
        'COUPAGE SELON LE HASARD DU TEMPS EN SECONDE
        '******************************************************************

        'ON PREND LES 2 PAQUETS POUR EN REFAIRE UN SEUL PAQUET DE CARTE SELOND SI LA SECONDE SYSTEM EST PAIRE OU IMPAIRE
        'SI PAIRE JE MET LE PAQUET DE DROITE AU DESSUS DE CELUI DE GAUCHE
        'SINON JE MET LE PAQUET DE GAUCHE AU DESSUS DE CELUI DE DROITE
        intGaucheCompteur = 0
        intDroitCompteur = 0

        If ((Second(TimeOfDay) Mod 2) = 0) Then
            'PAQUET DROIT
            For i = 0 To 25
                tblCard(i, constIntDimensionPositionNOMBRE) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionNOMBRE)
                tblCard(i, constIntDimensionPositionSYMBOLE) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionSYMBOLE)
                tblCard(i, constIntDimensionPositionCOULEUR) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionCOULEUR)
                tblCard(i, constIntDimensionPositionPATH) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionPATH)
                intDroitCompteur += 1
            Next
            'PAQUET GAUCHE
            For i = 26 To 51
                tblCard(i, constIntDimensionPositionNOMBRE) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionNOMBRE)
                tblCard(i, constIntDimensionPositionSYMBOLE) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionSYMBOLE)
                tblCard(i, constIntDimensionPositionCOULEUR) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionCOULEUR)
                tblCard(i, constIntDimensionPositionPATH) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionPATH)
                intGaucheCompteur += 1
            Next
        Else
            'PAQUET GAUCHE
            For i = 0 To 25
                tblCard(i, constIntDimensionPositionNOMBRE) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionNOMBRE)
                tblCard(i, constIntDimensionPositionSYMBOLE) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionSYMBOLE)
                tblCard(i, constIntDimensionPositionCOULEUR) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionCOULEUR)
                tblCard(i, constIntDimensionPositionPATH) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionPATH)
                intGaucheCompteur += 1

            Next
            'PAQUET DROIT
            For i = 26 To 51

                tblCard(i, constIntDimensionPositionNOMBRE) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionNOMBRE)
                tblCard(i, constIntDimensionPositionSYMBOLE) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionSYMBOLE)
                tblCard(i, constIntDimensionPositionCOULEUR) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionCOULEUR)
                tblCard(i, constIntDimensionPositionPATH) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionPATH)
                intDroitCompteur += 1
            Next
        End If

        '******************************************************************
        'BRASSAGE SELON LE HASARD DU TEMPS EN SECONDE
        '******************************************************************
        intGaucheCompteur = 0
        intDroitCompteur = 0
        'ON COUPE LES CARTES EN 2 PAQUETS SELON LA SECONDE SYSTEM ON COMMANCE PAR LE PAQUET DROITE OU GAUCHE EN PREMIER
        'SI LA SECONDE EST PAIRE ON COMMENCE A FAIRE UN PAQUET GAUCE
        'SINON UN PAQET DROITE
        If ((Second(TimeOfDay) Mod 2) = 0) Then
            For i = 0 To 51
                'ON COUPE LE TABLEAU DE CARTE EN 2
                'ON Y FAIT 2 PAQUETS DE CARTE
                '1 PAQUET DE GAUCHE ET 1 PAQUET DROIT
                If ((i Mod 2) = 0) Then
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionNOMBRE) = tblCard(i, constIntDimensionPositionNOMBRE)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionSYMBOLE) = tblCard(i, constIntDimensionPositionSYMBOLE)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionCOULEUR) = tblCard(i, constIntDimensionPositionCOULEUR)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionPATH) = tblCard(i, constIntDimensionPositionPATH)
                    intGaucheCompteur += 1
                Else
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionNOMBRE) = tblCard(i, constIntDimensionPositionNOMBRE)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionSYMBOLE) = tblCard(i, constIntDimensionPositionSYMBOLE)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionCOULEUR) = tblCard(i, constIntDimensionPositionCOULEUR)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionPATH) = tblCard(i, constIntDimensionPositionPATH)
                    intDroitCompteur += 1
                End If
            Next
        Else
            For i = 0 To 51
                'ON COUPE LE TABLEAU DE CARTE EN 2
                'ON Y FAIT 2 PAQUETS DE CARTE
                '1 PAQUET DE GAUCHE ET 1 PAQUET DROIT
                If ((i Mod 2) = 0) Then
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionNOMBRE) = tblCard(i, constIntDimensionPositionNOMBRE)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionSYMBOLE) = tblCard(i, constIntDimensionPositionSYMBOLE)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionCOULEUR) = tblCard(i, constIntDimensionPositionCOULEUR)
                    tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionPATH) = tblCard(i, constIntDimensionPositionPATH)
                    intDroitCompteur += 1
                Else
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionNOMBRE) = tblCard(i, constIntDimensionPositionNOMBRE)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionSYMBOLE) = tblCard(i, constIntDimensionPositionSYMBOLE)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionCOULEUR) = tblCard(i, constIntDimensionPositionCOULEUR)
                    tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionPATH) = tblCard(i, constIntDimensionPositionPATH)
                    intGaucheCompteur += 1
                End If
            Next
        End If

        '********************************************************
        'ON BRASSE LES CARTES
        '********************************************************
        intGaucheCompteur = 0
        intDroitCompteur = 0
        If ((Second(TimeOfDay) Mod 2) = 0) Then
            For i = 0 To 51
                If ((i Mod 2)) = 0 Then
                    tblCard(i, constIntDimensionPositionNOMBRE) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionNOMBRE)
                    tblCard(i, constIntDimensionPositionSYMBOLE) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionSYMBOLE)
                    tblCard(i, constIntDimensionPositionCOULEUR) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionCOULEUR)
                    tblCard(i, constIntDimensionPositionPATH) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionPATH)
                    intGaucheCompteur += 1
                Else
                    tblCard(i, constIntDimensionPositionNOMBRE) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionNOMBRE)
                    tblCard(i, constIntDimensionPositionSYMBOLE) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionSYMBOLE)
                    tblCard(i, constIntDimensionPositionCOULEUR) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionCOULEUR)
                    tblCard(i, constIntDimensionPositionPATH) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionPATH)
                    intDroitCompteur += 1

                End If

            Next
        Else
            For i = 0 To 51
                If ((i Mod 2)) = 0 Then
                    tblCard(i, constIntDimensionPositionNOMBRE) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionNOMBRE)
                    tblCard(i, constIntDimensionPositionSYMBOLE) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionSYMBOLE)
                    tblCard(i, constIntDimensionPositionCOULEUR) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionCOULEUR)
                    tblCard(i, constIntDimensionPositionPATH) = tblStrPaquetDroite(intDroitCompteur, constIntDimensionPositionPATH)
                    intDroitCompteur += 1
                Else
                    tblCard(i, constIntDimensionPositionNOMBRE) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionNOMBRE)
                    tblCard(i, constIntDimensionPositionSYMBOLE) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionSYMBOLE)
                    tblCard(i, constIntDimensionPositionCOULEUR) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionCOULEUR)
                    tblCard(i, constIntDimensionPositionPATH) = tblStrPaquetGauge(intGaucheCompteur, constIntDimensionPositionPATH)
                    intGaucheCompteur += 1

                End If

            Next
        End If

        'RETOUR DE FONCTION
        fntCoupageEtBrassageDeCarte = tblCard

    End Function

    Private Sub subFntCagnotte()

        'AFFICHE LE MONTANT DE LA CAGNOTTE
        lblPot.Text = constStrMontantDuPotEnCour & vbCr & (CInt(lblMiseJoeur.Text) * 2)

    End Sub


    Private Sub subFntMessageJoueur(ByRef msg As String)

        'AFFICHE UN MESSAGE A L UTILISATEUR
        MessageBox.Show(strNomPrenom & " : " & vbCr & msg)

    End Sub

    Private Sub btnRaiseDonw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseDonw.Click

        'LE JOUEUR VEUT BAISSER SA MISE
        Dim strMiseJoueur As String

        'CALCULER LE MONTANT MISER
        strMiseJoueur = CStr(CInt(lblMiseJoeur.Text) - CInt(constStrCurrencyMiseDefaultValue))
        lblMiseJoeur.Text = fntStrCurrency(strMiseJoueur)

        strMiseJoueur = CStr(CInt(lblMontant.Text) + CInt(constStrCurrencyMiseDefaultValue))
        lblMontant.Text = fntStrCurrency(strMiseJoueur)

        'DESACTIVE LE BOUTON DIMINUER LA MISE
        If CInt(lblMiseJoeur.Text) = 0 Then
            btnRaiseDonw.Enabled = False
            btnJouer.Enabled = False
        End If
        bolAllIn = False
    End Sub

    Private Sub btnJouer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnJouer.Click

        'TOUR DU CROUPIER A JOUER
        subFntJeuCroupier()

        'LE JOUEUR A CLIQUER SUR LE BOUTON MISER
        Dim intCalculeDeLaMiseCroupierPlusJoueur As Integer

        'DESACTIVATION DES BOUTONS 
        btnRaiseUp.Enabled = False
        btnRaiseDonw.Enabled = False
        btnRaiseDownCentsMille.Enabled = False
        btnEqualiser.Enabled = False
        btnEqualiser.Visible = False

        'AFFICHAGE DES MONTANT MISER PAR LE CROUPIER ET LA CAGNOTTE
        lblMiseCroupier.Text = fntStrCurrency(lblMiseJoeur.Text)
        intCalculeDeLaMiseCroupierPlusJoueur = CInt(lblMiseCroupier.Text) + CInt(lblMiseJoeur.Text) + CInt(lblPot.Text)
        intCagnotte += (CInt(lblMiseCroupier.Text) + CInt(lblMiseJoeur.Text))
        lblPot.Text = fntStrCurrency(CStr(intCalculeDeLaMiseCroupierPlusJoueur))

        'A QUELLE CARTE ON EST RENDU A TOURNER
        If intEtapeJeuTournage = 5 Then
            intEtapeJeuTournage = 0
        Else
            intEtapeJeuTournage += 1
        End If

        If bolAllIn Then
            For i = intEtapeJeuTournage To 5
                'ON RETOURNE LES CARTES COMMUNE ET CROUPIER - ALL IN
                fntTournerCarteJouer(i)
            Next
        Else
            'ON RETOURNE LES CARTES UNE PAR UNE
            fntTournerCarteJouer(intEtapeJeuTournage)
        End If


    End Sub

    Private Sub fntTournerCarteJouer(ByVal intEtap As Integer)

        'REMISE A ZERO DES MISES CROUPIER ET JOUEUR
        'lblMiseCroupier.Text = fntStrCurrency("0")
        lblMiseJoeur.Text = fntStrCurrency(constStrCurrencyDefaultValue)
        btnJouer.Enabled = False

        'DETERMINE QUEL SONT LES CARTES A RETOURNER
        Select Case intEtap

            Case constIntEtapeJeuTournageJoueur

                'SHOW CARTE DU JOUEUR UN
                picCarteJoueurOne.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteJoueur(0, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteJoueur(0, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteJoueur(0, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteJoueur(0, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)
                intCompteurCarte += 1

                'SHOW CARTE DU JOUEUR DEUX
                picCarteJoueurTwo.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteJoueur(1, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteJoueur(1, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteJoueur(1, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteJoueur(1, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

            Case constIntEtapeJeuTournageFlop

                'SHOW CARTE DU COMMUNE UN
                picCarteCommuneOne.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteJoueur(2, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteJoueur(2, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteJoueur(2, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteJoueur(2, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

                tblStrCarteCroupier(2, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteCroupier(2, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteCroupier(2, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteCroupier(2, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)
                intCompteurCarte += 1

                'SHOW CARTE DU COMMUNE DEUX
                picCarteCommuneTwo.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteJoueur(3, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteJoueur(3, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteJoueur(3, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteJoueur(3, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

                tblStrCarteCroupier(3, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteCroupier(3, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteCroupier(3, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteCroupier(3, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)
                intCompteurCarte += 1

                'SHOW CARTE DU COMMUNE TROIS
                picCarteCommuneTree.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteJoueur(4, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteJoueur(4, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteJoueur(4, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteJoueur(4, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

                tblStrCarteCroupier(4, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteCroupier(4, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteCroupier(4, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteCroupier(4, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

            Case constIntEtapeJeuTournageTurn
                'SHOW CARTE DU COMMUNE QUATRE
                picCarteCommuneFour.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteJoueur(5, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteJoueur(5, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteJoueur(5, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteJoueur(5, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

                tblStrCarteCroupier(5, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteCroupier(5, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteCroupier(5, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteCroupier(5, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

            Case constIntEtapeJeuTournageRiver
                'SHOW CARTE DU COMMUNE CINQ
                picCarteCommuneFive.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteJoueur(6, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteJoueur(6, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteJoueur(6, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteJoueur(6, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

                tblStrCarteCroupier(6, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteCroupier(6, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteCroupier(6, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteCroupier(6, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

            Case constIntEtapeJeuTournageCroupier
                'SHOW CARTE CROUPIER UNE
                picCarteCroupierOne.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteCroupier(0, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteCroupier(0, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteCroupier(0, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteCroupier(0, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)
                intCompteurCarte += 1

                'SHOW CARTE CROUPIER DEUX
                picCarteCroupierTwo.Image = Image.FromFile(Application.StartupPath & constStrImgPath & tblStrCard(intCompteurCarte, constIntDimensionPositionPATH))
                tblStrCarteCroupier(1, constIntDimensionPositionNOMBRE) = tblStrCard(intCompteurCarte, constIntDimensionPositionNOMBRE)
                tblStrCarteCroupier(1, constIntDimensionPositionSYMBOLE) = tblStrCard(intCompteurCarte, constIntDimensionPositionSYMBOLE)
                tblStrCarteCroupier(1, constIntDimensionPositionCOULEUR) = tblStrCard(intCompteurCarte, constIntDimensionPositionCOULEUR)
                tblStrCarteCroupier(1, constIntDimensionPositionPATH) = tblStrCard(intCompteurCarte, constIntDimensionPositionPATH)

        End Select


        If intEtap = constIntEtapeJeuTournageCroupier Then
            ' ON RE AFFICHE LES BOUTONS
            btnRaiseUp.Enabled = False
            btnFold.Enabled = False
            btnCheck.Enabled = False
            btnJouer.Enabled = False
            'DETERMINER LE GAGNANT ENTRE LE CROUPIER OU LE JOUEUR
            If fntDeterminerLeGagnant() Then
                subFntGainMaison()
            Else
                subFntGainJoueur()
            End If

            'ON RECOMMENCE UNE NOUVELLE PARTIE
            intCompteurCarte = 0
            intEtapeJeuTournage = -1

        Else
            ' ON RE AFFICHE LES BOUTONS
            btnRaiseUp.Enabled = True
            btnFold.Enabled = True
            btnCheck.Enabled = True
            btnJouer.Enabled = False
            intCompteurCarte += 1
        End If

    End Sub

    Private Sub subFntGainMaison()

        'LA MAISON GAGNE
        'ON ENCAISE LES GAIN ET ON LES AFFICHE GAIN DE LA MAISON
        'ON REMET LA CAGNOTTE A 0
        subFntMessageJoueur(constStrWinner & vbCr & constStrWinnerCroupier)

        'AFFICHAGE DES GAINS DE LA MAISON
        intGainDeLaMaison += CInt(lblPot.Text)
        lblBanque.Text = constStringGainDeLaMaison & vbCr & fntStrCurrency(CStr(intGainDeLaMaison))
        lblPot.Text = fntStrCurrency(constStrCurrencyDefaultValue)
        lblMiseCroupier.Text = fntStrCurrency(constStrCurrencyDefaultValue)

        'COMMENCER UNE NOUVELLE PARTIE
        subFntCommencerLaPartier()

    End Sub

    Private Sub subFntGainJoueur()

        'LE JOUEUR GAGNE
        'ON ENCAISE LES GAIN ET ON LES AFFICHE GAIN DU JOUEUR
        'ON REMET LA CAGNOTTE A 0
        subFntMessageJoueur(constStrWinner & vbCr & strNomPrenom & constStrFelicitation)

        'AFFICHAGE DES GAINS DE LA MAISON
        Dim intGainJoueur As Integer
        intGainJoueur = CInt(lblMontant.Text) + CInt(lblPot.Text)
        lblMontant.Text = fntStrCurrency(CStr(intGainJoueur))
        lblPot.Text = fntStrCurrency(constStrCurrencyDefaultValue)
        lblMiseCroupier.Text = fntStrCurrency(constStrCurrencyDefaultValue)

        'COMMENCER UNE NOUVELLE PARTIE
        subFntCommencerLaPartier()

    End Sub

    Private Function fntStrCurrency(ByRef strMontant As String) As String

        'RETOURNE LE FORMAT MONNAIRE EN FORMA 1.00$
        fntStrCurrency = String.Format(constStrCurrency, CType(strMontant, Double))

    End Function

    Private Function fntDeterminerLeGagnant() As Boolean

        'FONCTION QUI DETERMINE LE GAGNANT ENTRE LE CROUPIER ET LE JOUEUR
        Dim bolWinerCroupier = False
        Dim intForceJoeur As Integer
        Dim intForceCroupier As Integer
        Dim strCroupierJeu As String
        Dim strJoueurJeu As String
        Dim strMessage As String

        'CALCUL DU JEU DE CHAQUE JOUEUR
        intForceCroupier = fntForceCarte(True)
        strCroupierJeu = fntJeuEnMain(intForceCroupier)
        intForceJoeur = fntForceCarte(False)
        strJoueurJeu = fntJeuEnMain(intForceJoeur)

        'MESSAGE QUI AFFICHE LE JEU DE CHACUN
        strMessage = vbCr & constStrJeuCroupier & strCroupierJeu & vbCr & constStrJeuJoueur & strJoueurJeu
        subFntMessageJoueur(strMessage)

        'ON DETERMINE LE GAGNANT
        If (intForceCroupier > intForceJoeur) Then
            'CROUPIER WIN
            bolWinerCroupier = True
        ElseIf (intForceCroupier < intForceJoeur) Then
            'USER WIN
            bolWinerCroupier = False
        Else
            intForceCroupier = fntJeuEnMainHighCard(tblStrCarteCroupier)
            intForceJoeur = fntJeuEnMainHighCard(tblStrCarteJoueur)
            If (intForceCroupier > intForceJoeur) Then
                bolWinerCroupier = True
            Else
                bolWinerCroupier = False
            End If

        End If

        'RETOUR DE FONCTION
        fntDeterminerLeGagnant = bolWinerCroupier

    End Function

    Private Function fntForceCarte(ByVal boolCroupier As Boolean) As Integer

        'FONCTION QUI RETOURNE LA FORCE DU JEU QUE LE CROUPIER OU LE JOUEUR A EN MAIN
        Dim intForce As Integer

        If boolCroupier Then
            'CALCULE DES CARTES DU CROUPIER
            intForce = fntJeuEnMain(tblStrCarteCroupier)
        Else
            'CALCULE DES CARTES DU JOUEUR
            intForce = fntJeuEnMain(tblStrCarteJoueur)
        End If

        fntForceCarte = intForce

    End Function

    Private Function fntJeuEnMain(ByVal tableauJeuCarte(,) As String) As Integer

        'FONCTION QUI DETERMINE LE JEU QUE TU AS EN MAIN
        Dim intValeurDuJeuEnMain As Integer = constIntForceCarteHishCard

        If fntJeuEnMainRoyaleFlush(tableauJeuCarte) Then
            'ROYALE FLUSH
            intValeurDuJeuEnMain = constIntForceCarteRoyaleFlush
        ElseIf fntJeuEnMainStraightFlush(tableauJeuCarte) Then
            'STRAIGHT FLUSH
            intValeurDuJeuEnMain = constIntForceCarteStraitFlush
        ElseIf fntJeuEnMainFourOfKind(tableauJeuCarte) Then
            'CARRE OU FOUR OF KIND
            intValeurDuJeuEnMain = constIntForceCarteFourOfKind
        ElseIf fntJeuEnMainFullHouse(tableauJeuCarte) Then
            'FULL HOUSE
            intValeurDuJeuEnMain = constIntForceCarteFullHouse
        ElseIf fntJeuEnMainFlushCouleur(tableauJeuCarte) Then
            'FLUSH OU COULEUR
            intValeurDuJeuEnMain = constIntForceCarteFlushCouleur
        ElseIf fntJeuEnMainSuiteStraight(tableauJeuCarte) Then
            'QUITE - SUITE - STRAIGHT
            intValeurDuJeuEnMain = constIntForceCarteSuiteStraight
        ElseIf fntJeuEnMainBrelan(tableauJeuCarte) Then
            'BRELAN
            intValeurDuJeuEnMain = constIntForceCarteBrelan
        ElseIf fntJeuEnMainDeuxPaire(tableauJeuCarte) Then
            'DEUX PAIRE
            intValeurDuJeuEnMain = constIntForceCarteTwoPaire
        ElseIf fntJeuEnMainOnePaire(tableauJeuCarte, 7) Then
            'ONE PAIRE
            intValeurDuJeuEnMain = constIntForceCarteOnePaire
        End If

        'RETOUR DE VALEUR
        fntJeuEnMain = intValeurDuJeuEnMain

    End Function

    Private Sub btnFold_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFold.Click

        'LE JOUEUR JETTE SES CARTE
        intEtapeJeuTournage = -1
        btnEqualiser.Visible = False
        bolAllIn = False
        lblMiseCroupier.Text = fntStrCurrency(constStrCurrencyDefaultValue)
        'LE JOUEUR A JETER SES CARTES
        subFntGainMaison()

    End Sub

    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click

        'APPEL DE FONCTION SI ON RELANCE OU PAS
        subFntRelance()

    End Sub

    Private Sub subFntRelance()

        'VERIFICATION SI LE CROUPIER RELANCE LE JOUEUR OU CHECK
        Dim intRelance As Integer

        intRelance = CInt((Second(TimeOfDay) * Rnd()) + 1) * CInt(constStrCurrencyMiseDefaultValue)

        'LE CROUPIER PASSE - ON TOURNE LES PROCHAINE CARTE
        If fntBoolCroupierCheck() Then
            'A QUELLE CARTE ON EST RENDU A TOURNER
            If intEtapeJeuTournage = 5 Then
                intEtapeJeuTournage = 0
            Else
                intEtapeJeuTournage += 1
            End If

            'ON RETOURNE LES CARTE UNE PAR UNE
            fntTournerCarteJouer(intEtapeJeuTournage)
        Else
            'LE CROUPIER VOUS RELANCE DE
            lblMiseCroupier.Text = fntStrCurrency(CStr(intRelance))
            subFntMessageJoueur(constStrRelanceCroupier & fntStrCurrency(CStr(intRelance)))
            btnJouer.Enabled = False
            btnEqualiser.Visible = True
            btnEqualiser.Enabled = True
            btnRaiseUp.Enabled = False
            btnRaiseDonw.Enabled = False
            btnFold.Enabled = True
            btnCheck.Enabled = False
        End If

        bolAllIn = False

    End Sub

    Private Function fntBoolCroupierCheck() As Boolean

        'LE CROUPIER PASSE SON TOUR OU PAS
        'UNE FOIS SUR 2 IL PASSE
        If (Second(TimeOfDay) Mod 2) = 0 Then
            fntBoolCroupierCheck = False
        Else
            fntBoolCroupierCheck = True
        End If

    End Function

    Private Sub btnEqualiser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEqualiser.Click

        'LE JOUEUR EQUALISE LA MISE DU CROUPIER
        lblMiseJoeur.Text = lblMiseCroupier.Text
        lblMiseCroupier.Text = fntStrCurrency(constStrCurrencyDefaultValue)
        bolAllIn = False
        btnJouer.Enabled = True
        btnEqualiser.Enabled = False
        btnEqualiser.Visible = False

    End Sub

    Private Function fntJeuEnMainRoyaleFlush(ByVal tableauJeuCarte(,) As String) As Boolean

        'ROYAL FLUSH
        'POUR AVOIR UN ROYAL FLUSH STEP 1 AVOIR 5 FOIS LE MEME SYMBOLE

        Dim boolJeuEnMain As Boolean = False

        Dim boolPresentA As Boolean = False
        Dim boolPresentK As Boolean = False
        Dim boolPresentQ As Boolean = False
        Dim boolPresentJ As Boolean = False
        Dim boolPresent10 As Boolean = False

        Dim intSymboleCoeur As Integer = 0
        Dim intSymboleCarre As Integer = 0
        Dim intSymboleTrefle As Integer = 0
        Dim intSymbolePique As Integer = 0

        'ETAPE 1
        'ON VERIFIE CHAQUE CARTE
        Dim intTapNombreRow As Integer = tableauJeuCarte.GetLength(0) - 1
        For i = 0 To intTapNombreRow
            'ON VERIFIE QU IL Y A 5 SYMBOLE IDENTIQUE
            Select Case tableauJeuCarte(i, constIntDimensionPositionSYMBOLE)
                Case constStrSymboleCoeur
                    intSymboleCoeur += 1
                Case constStrSymboleCarre
                    intSymboleCarre += 1
                Case constStrSymboleTrefle
                    intSymboleTrefle += 1
                Case constStrSymbolePique
                    intSymbolePique += 1
            End Select
        Next

        'ETAPE 2
        'OUI ON A 5 CARTES AVEC LE MEME SYMBOLE
        If (intSymboleCoeur >= 5) Or (intSymboleCarre >= 5) Or (intSymboleTrefle >= 5) Or (intSymbolePique >= 5) Then
            'ON VERIFIE SI ON A LE A, K, Q, J ET 10
            'ON VERIFIE CHAQUE CARTE
            For i = 0 To intTapNombreRow
                'ON VERIFIE QUE LE AS, K, Q, J ET 10 SOIS PRESENT
                Select Case tableauJeuCarte(i, constIntDimensionPositionNOMBRE)
                    Case constStrCarteAs
                        boolPresentA = True
                    Case constStrCarteKing
                        boolPresentK = True
                    Case constStrCarteQueen
                        boolPresentQ = True
                    Case constStrCarteJack
                        boolPresentJ = True
                    Case constStrCarte10
                        boolPresent10 = True
                End Select
            Next
        End If

        If boolPresentA And boolPresentK And boolPresentQ And boolPresentJ And boolPresent10 Then
            boolJeuEnMain = True
        End If

        'ON RETOURNE TRUE OR FALSE LE ROYALE FLUSH EST PRESENT
        fntJeuEnMainRoyaleFlush = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainStraightFlush(ByVal tableauJeuCarte(,) As String) As Boolean

        'STARIGHT FULSH
        'POUR AVOIR UN STRAIGHT FLUSH IL FAUT
        '1 - AVOIR 5 SYMBPLE IDENTIQUE COEUR, CARRE, PIQUE, TREFLE
        '2 - AVOIR LES CARTES 9, 8, 7, 6, 5
        Dim boolJeuEnMain As Boolean = False

        Dim boolPresent9 As Boolean = False
        Dim boolPresent8 As Boolean = False
        Dim boolPresent7 As Boolean = False
        Dim boolPresent6 As Boolean = False
        Dim boolPresent5 As Boolean = False

        Dim intSymboleCoeur As Integer = 0
        Dim intSymboleCarre As Integer = 0
        Dim intSymboleTrefle As Integer = 0
        Dim intSymbolePique As Integer = 0

        'ETAPE 1
        'ON VERIFIE CHAQUE CARTE
        Dim intNombreDeRow As Integer = tableauJeuCarte.GetLength(0) - 1
        For i = 0 To intNombreDeRow
            'ON VERIFIE QU IL Y A 5 SYMBOLE IDENTIQUE
            Select Case tableauJeuCarte(i, constIntDimensionPositionSYMBOLE)
                Case constStrSymboleCoeur
                    intSymboleCoeur += 1
                Case constStrSymboleCarre
                    intSymboleCarre += 1
                Case constStrSymboleTrefle
                    intSymboleTrefle += 1
                Case constStrSymbolePique
                    intSymbolePique += 1
            End Select
        Next

        'ETAPE 2
        'OUI ON A 5 CARTES AVEC LE MEME SYMBOLE
        If (intSymboleCoeur >= 5) Or (intSymboleCarre >= 5) Or (intSymboleTrefle >= 5) Or (intSymbolePique >= 5) Then
            'ON VERIFIE SI ON A LE 9, 8, 7, 6 ET 5
            'ON VERIFIE CHAQUE CARTE
            For i = 0 To intNombreDeRow
                'ON VERIFIE QUE LE 9, 8, 7, 6 ET 5 SOIS PRESENT
                Select Case tableauJeuCarte(i, constIntDimensionPositionNOMBRE)
                    Case constStrCarteAs
                        boolPresent9 = True
                    Case constStrCarteKing
                        boolPresent8 = True
                    Case constStrCarteQueen
                        boolPresent7 = True
                    Case constStrCarteJack
                        boolPresent6 = True
                    Case constStrCarte10
                        boolPresent5 = True
                End Select
            Next
        End If

        If boolPresent9 And boolPresent8 And boolPresent7 And boolPresent6 And boolPresent5 Then
            boolJeuEnMain = True
        End If

        'ON RETOURNE TRUE OU FALSE SI LE STRAIGHT FLUSH EST PRESENT
        fntJeuEnMainStraightFlush = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainFourOfKind(ByVal tableauJeuCarte(,) As String) As Boolean

        'FOUR OF KIND
        'COMPTEUR DE CARTE
        Dim boolJeuEnMain As Boolean = False
        Dim intCompteurA As Integer = 0
        Dim intCompteurK As Integer = 0
        Dim intCompteurQ As Integer = 0
        Dim intCompteurJ As Integer = 0
        Dim intCompteur10 As Integer = 0
        Dim intCompteur9 As Integer = 0
        Dim intCompteur8 As Integer = 0
        Dim intCompteur7 As Integer = 0
        Dim intCompteur6 As Integer = 0
        Dim intCompteur5 As Integer = 0
        Dim intCompteur4 As Integer = 0
        Dim intCompteur3 As Integer = 0
        Dim intCompteur2 As Integer = 0

        'POUR AVOIR UN CARRE FOUR OF KIND, IL FAUT 4 CARTES DU MEME NOMBRE PEUT IMPORTE LE SYMBOLE
        Dim intNombreDeRow As Integer = tableauJeuCarte.GetLength(0) - 1
        For i = 0 To intNombreDeRow
            Select Case tableauJeuCarte(i, constIntDimensionPositionNOMBRE)
                Case constStrCarteAs
                    'ON COMPTE LE NOMBRE DE A
                    intCompteurA += 1
                    If intCompteurA >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteKing
                    'ON COMPTE LE NOMBRE DE K
                    intCompteurK += 1
                    If intCompteurK >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteQueen
                    'ON COMPTE LE NOMBRE DE Q
                    intCompteurQ += 1
                    If intCompteurQ >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteJack
                    'ON COMPTE LE NOMBRE DE J
                    intCompteurJ += 1
                    If intCompteurJ >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte10
                    'ON COMPTE LE NOMBRE DE 10
                    intCompteur10 += 1
                    If intCompteur10 >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte9
                    'ON COMPTE LE NOMBRE DE 9
                    intCompteur9 += 1
                    If intCompteur9 >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte8
                    'ON COMPTE LE NOMBRE DE 8
                    intCompteur8 += 1
                    If intCompteur8 >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte7
                    'ON COMPTE LE NOMBRE DE 7
                    intCompteur7 += 1
                    If intCompteur7 >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte6
                    'ON COMPTE LE NOMBRE DE 6
                    intCompteur6 += 1
                    If intCompteur6 >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte5
                    'ON COMPTE LE NOMBRE DE 5
                    intCompteur5 += 1
                    If intCompteur5 >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte4
                    'ON COMPTE LE NOMBRE DE 4
                    intCompteur4 += 1
                    If intCompteur4 >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte3
                    'ON COMPTE LE NOMBRE DE 3
                    intCompteur3 += 1
                    If intCompteur3 >= 4 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte2
                    'ON COMPTE LE NOMBRE DE 2
                    intCompteur2 += 1
                    If intCompteur2 >= 4 Then
                        boolJeuEnMain = True
                    End If
            End Select
        Next

        'ON RETOURNE TRUE OU FALSE SI LE FOUR OF KIND EST PRESENT
        fntJeuEnMainFourOfKind = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainFullHouse(ByVal tableauJeuCarte(,) As String) As Boolean

        'FULL HOUSE
        'COMPTEUR DE CARTE
        Dim boolJeuEnMain As Boolean = False
        Dim boolJeuEnMainBrelan As Boolean = False
        Dim boolJeuEnMainOnePaire As Boolean = False

        'SAVOIR SI LE JEU CONTIENT A LA FOIS UN BRELAN ET UNE PAIRE
        boolJeuEnMainBrelan = fntJeuEnMainBrelan(tableauJeuCarte)
        boolJeuEnMainOnePaire = fntJeuEnMainOnePaire(tableauJeuCarte, tableauJeuCarte.GetLength(0))

        If boolJeuEnMainBrelan And boolJeuEnMainOnePaire Then
            boolJeuEnMain = True
        End If

        fntJeuEnMainFullHouse = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainFlushCouleur(ByVal tableauJeuCarte(,) As String) As Boolean

        'FLUSH COULEUR
        'ON VERIFIE SI LE JEUX CONTIENT 5 CARTE DU MEME SYMBOLE
        Dim boolJeuEnMain As Boolean = False

        Dim intSymboleCoeur As Integer = 0
        Dim intSymboleCarre As Integer = 0
        Dim intSymboleTrefle As Integer = 0
        Dim intSymbolePique As Integer = 0

        'ETAPE 1
        'ON VERIFIE CHAQUE CARTE
        Dim intNombreDeRow As Integer = tableauJeuCarte.GetLength(0) - 1
        For i = 0 To intNombreDeRow
            'ON VERIFIE QU IL Y A 5 SYMBOLE IDENTIQUE
            Select Case tableauJeuCarte(i, constIntDimensionPositionSYMBOLE)
                Case constStrSymboleCoeur
                    intSymboleCoeur += 1
                Case constStrSymboleCarre
                    intSymboleCarre += 1
                Case constStrSymboleTrefle
                    intSymboleTrefle += 1
                Case constStrSymbolePique
                    intSymbolePique += 1
            End Select
        Next

        'ETAPE 2
        'ON VERIFIE QU IL Y A 5 CARTES DU MEME SYMBOLE
        If (intSymboleCoeur >= 5) Or (intSymboleCarre >= 5) Or (intSymboleTrefle >= 5) Or (intSymbolePique >= 5) Then
            boolJeuEnMain = True
        End If
        'RETOUR DE FONCTION
        fntJeuEnMainFlushCouleur = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainSuiteStraight(ByVal tableauJeuCarte(,) As String) As Boolean

        'VERIFIE SI IL Y A UNE SUITE
        Dim boolJeuEnMain As Boolean = False
        Dim boolCompteurA As Boolean = False
        Dim boolCompteurK As Boolean = False
        Dim boolCompteurQ As Boolean = False
        Dim boolCompteurJ As Boolean = False
        Dim boolCompteur10 As Boolean = False
        Dim boolCompteur9 As Boolean = False
        Dim boolCompteur8 As Boolean = False
        Dim boolCompteur7 As Boolean = False
        Dim boolCompteur6 As Boolean = False
        Dim boolCompteur5 As Boolean = False
        Dim boolCompteur4 As Boolean = False
        Dim boolCompteur3 As Boolean = False
        Dim boolCompteur2 As Boolean = False

        Dim intNowmbreDeRow As Integer = tableauJeuCarte.GetLength(0) - 1
        For i = 0 To intNowmbreDeRow
            Select Case tableauJeuCarte(i, constIntDimensionPositionNOMBRE)
                Case constStrCarteAs
                    'ON COMPTE LE NOMBRE DE A
                    boolCompteurA = True

                Case constStrCarteKing
                    'ON COMPTE LE NOMBRE DE K
                    boolCompteurK = True

                Case constStrCarteQueen
                    'ON COMPTE LE NOMBRE DE Q
                    boolCompteurQ = True

                Case constStrCarteJack
                    'ON COMPTE LE NOMBRE DE J
                    boolCompteurJ = True

                Case constStrCarte10
                    'ON COMPTE LE NOMBRE DE 10
                    boolCompteur10 = True

                Case constStrCarte9
                    'ON COMPTE LE NOMBRE DE 9
                    boolCompteur9 = True

                Case constStrCarte8
                    'ON COMPTE LE NOMBRE DE 8
                    boolCompteur8 = True

                Case constStrCarte7
                    'ON COMPTE LE NOMBRE DE 7
                    boolCompteur7 = True

                Case constStrCarte6
                    'ON COMPTE LE NOMBRE DE 6
                    boolCompteur6 = True

                Case constStrCarte5
                    'ON COMPTE LE NOMBRE DE 5
                    boolCompteur5 = True

                Case constStrCarte4
                    'ON COMPTE LE NOMBRE DE 4
                    boolCompteur4 = True

                Case constStrCarte3
                    'ON COMPTE LE NOMBRE DE 3
                    boolCompteur3 = True

                Case constStrCarte2
                    'ON COMPTE LE NOMBRE DE 2
                    boolCompteur2 = True

            End Select
        Next

        'ON VERIFIE SI IL Y A UNE SUITE DE 5 CARTES
        If (boolCompteurA) And (boolCompteurK) And (boolCompteurQ) And (boolCompteurJ) And (boolCompteur10) Then
            boolJeuEnMain = True
        ElseIf (boolCompteurK) And (boolCompteurQ) And (boolCompteurJ) And (boolCompteur10) And (boolCompteur9) Then
            boolJeuEnMain = True
        ElseIf (boolCompteurQ) And (boolCompteurJ) And (boolCompteur10) And (boolCompteur9) And (boolCompteur8) Then
            boolJeuEnMain = True
        ElseIf (boolCompteurJ) And (boolCompteur10) And (boolCompteur9) And (boolCompteur8) And (boolCompteur7) Then
            boolJeuEnMain = True
        ElseIf (boolCompteur10) And (boolCompteur9) And (boolCompteur8) And (boolCompteur7) And (boolCompteur6) Then
            boolJeuEnMain = True
        ElseIf (boolCompteur9) And (boolCompteur8) And (boolCompteur7) And (boolCompteur6) And (boolCompteur5) Then
            boolJeuEnMain = True
        ElseIf (boolCompteur8) And (boolCompteur7) And (boolCompteur6) And (boolCompteur5) And (boolCompteur4) Then
            boolJeuEnMain = True
        ElseIf (boolCompteur7) And (boolCompteur6) And (boolCompteur5) And (boolCompteur4) And (boolCompteur3) Then
            boolJeuEnMain = True
        ElseIf (boolCompteur6) And (boolCompteur5) And (boolCompteur4) And (boolCompteur3) And (boolCompteur2) Then
            boolJeuEnMain = True
        End If

        'ON RETOURNE TRUE OU FALSE SI IL Y A UNE SUITE
        fntJeuEnMainSuiteStraight = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainBrelan(ByVal tableauJeuCarte(,) As String) As Boolean

        'BRELAN
        Dim boolJeuEnMain As Boolean = False

        Dim intCompteurA As Integer = 0
        Dim intCompteurK As Integer = 0
        Dim intCompteurQ As Integer = 0
        Dim intCompteurJ As Integer = 0
        Dim intCompteur10 As Integer = 0
        Dim intCompteur9 As Integer = 0
        Dim intCompteur8 As Integer = 0
        Dim intCompteur7 As Integer = 0
        Dim intCompteur6 As Integer = 0
        Dim intCompteur5 As Integer = 0
        Dim intCompteur4 As Integer = 0
        Dim intCompteur3 As Integer = 0
        Dim intCompteur2 As Integer = 0

        'POUR AVOIR UN FULL HOUSE IL FAUT AVOIR 3 CARTES DU MEME TYPE ET 2 CARTES D UN AUTRE TYPE
        Dim intNombreDeRow As Integer = tableauJeuCarte.GetLength(0) - 1
        For i = 0 To intNombreDeRow
            Select Case tableauJeuCarte(i, constIntDimensionPositionNOMBRE)
                Case constStrCarteAs
                    'ON COMPTE LE NOMBRE DE A
                    intCompteurA += 1
                    If intCompteurA >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteKing
                    'ON COMPTE LE NOMBRE DE K
                    intCompteurK += 1
                    If intCompteurK >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteQueen
                    'ON COMPTE LE NOMBRE DE Q
                    intCompteurQ += 1
                    If intCompteurQ >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteJack
                    'ON COMPTE LE NOMBRE DE J
                    intCompteurJ += 1
                    If intCompteurJ >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte10
                    'ON COMPTE LE NOMBRE DE 10
                    intCompteur10 += 1
                    If intCompteur10 >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte9
                    'ON COMPTE LE NOMBRE DE 9
                    intCompteur9 += 1
                    If intCompteur9 >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte8
                    'ON COMPTE LE NOMBRE DE 8
                    intCompteur8 += 1
                    If intCompteur8 >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte7
                    'ON COMPTE LE NOMBRE DE 7
                    intCompteur7 += 1
                    If intCompteur7 >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte6
                    'ON COMPTE LE NOMBRE DE 6
                    intCompteur6 += 1
                    If intCompteur6 >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte5
                    'ON COMPTE LE NOMBRE DE 5
                    intCompteur5 += 1
                    If intCompteur5 >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte4
                    'ON COMPTE LE NOMBRE DE 4
                    intCompteur4 += 1
                    If intCompteur4 >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte3
                    'ON COMPTE LE NOMBRE DE 3
                    intCompteur3 += 1
                    If intCompteur3 >= 3 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte2
                    'ON COMPTE LE NOMBRE DE 2
                    intCompteur2 += 1
                    If intCompteur2 >= 3 Then
                        boolJeuEnMain = True
                    End If
            End Select
        Next
        'RETOUR DE FONCTION
        fntJeuEnMainBrelan = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainDeuxPaire(ByVal tableauJeuCarte(,) As String) As Boolean

        'DEUX PAIRE
        Dim boolJeuEnMain As Boolean = False

        'COMPTEUR DE CARTE
        Dim intCompteurA As Integer = 0
        Dim intCompteurK As Integer = 0
        Dim intCompteurQ As Integer = 0
        Dim intCompteurJ As Integer = 0
        Dim intCompteur10 As Integer = 0
        Dim intCompteur9 As Integer = 0
        Dim intCompteur8 As Integer = 0
        Dim intCompteur7 As Integer = 0
        Dim intCompteur6 As Integer = 0
        Dim intCompteur5 As Integer = 0
        Dim intCompteur4 As Integer = 0
        Dim intCompteur3 As Integer = 0
        Dim intCompteur2 As Integer = 0
        Dim intCompteur As Integer = 0

        'POUR AVOIR DEUX PAIRES IL FAUT UNE PAIRE D UN TYPE ET UNE AUTRE PAIRE D UN AUTRE TYPE
        Dim intNombreDeRow As Integer = tableauJeuCarte.GetLength(0) - 1
        For i = 0 To intNombreDeRow
            Select Case tableauJeuCarte(i, constIntDimensionPositionNOMBRE)
                Case constStrCarteAs
                    'ON COMPTE LE NOMBRE DE A
                    intCompteurA += 1
                    If intCompteurA >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarteKing
                    'ON COMPTE LE NOMBRE DE K
                    intCompteurK += 1
                    If intCompteurK >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarteQueen
                    'ON COMPTE LE NOMBRE DE Q
                    intCompteurQ += 1
                    If intCompteurQ >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarteJack
                    'ON COMPTE LE NOMBRE DE J
                    intCompteurJ += 1
                    If intCompteurJ >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte10
                    'ON COMPTE LE NOMBRE DE 10
                    intCompteur10 += 1
                    If intCompteur10 >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte9
                    'ON COMPTE LE NOMBRE DE 9
                    intCompteur9 += 1
                    If intCompteur9 >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte8
                    'ON COMPTE LE NOMBRE DE 8
                    intCompteur8 += 1
                    If intCompteur8 >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte7
                    'ON COMPTE LE NOMBRE DE 7
                    intCompteur7 += 1
                    If intCompteur7 >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte6
                    'ON COMPTE LE NOMBRE DE 6
                    intCompteur6 += 1
                    If intCompteur6 >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte5
                    'ON COMPTE LE NOMBRE DE 5
                    intCompteur5 += 1
                    If intCompteur5 >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte4
                    'ON COMPTE LE NOMBRE DE 4
                    intCompteur4 += 1
                    If intCompteur4 >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte3
                    'ON COMPTE LE NOMBRE DE 3
                    intCompteur3 += 1
                    If intCompteur3 >= 2 Then
                        intCompteur += 2
                    End If
                Case constStrCarte2
                    'ON COMPTE LE NOMBRE DE 2
                    intCompteur2 += 1
                    If intCompteur2 >= 2 Then
                        intCompteur += 2
                    End If
            End Select
        Next

        'EST CE QU IL Y A 2 PARE DONC 4 CARTES TOTALES.
        If (intCompteur >= 4) Then
            boolJeuEnMain = True
        End If

        'RETOURNE TRUE OU FALSE SI IL Y A UNE PAIRE
        fntJeuEnMainDeuxPaire = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainOnePaire(ByVal tableauJeuCarte(,) As String, ByVal intMax As Integer) As Boolean

        'ONE PAIRE
        Dim boolJeuEnMain As Boolean = False

        'COMPTEUR DE CARTE
        Dim intCompteurA As Integer = 0
        Dim intCompteurK As Integer = 0
        Dim intCompteurQ As Integer = 0
        Dim intCompteurJ As Integer = 0
        Dim intCompteur10 As Integer = 0
        Dim intCompteur9 As Integer = 0
        Dim intCompteur8 As Integer = 0
        Dim intCompteur7 As Integer = 0
        Dim intCompteur6 As Integer = 0
        Dim intCompteur5 As Integer = 0
        Dim intCompteur4 As Integer = 0
        Dim intCompteur3 As Integer = 0
        Dim intCompteur2 As Integer = 0

        'POUR AVOIR UN CARRE FOUR OF KIND, IL FAUT 4 CARTES DU MEME NOMBRE PEUT IMPORTE LE SYMBOLE
        intMax = -1
        For i = 0 To intMax
            Select Case tableauJeuCarte(i, constIntDimensionPositionNOMBRE)
                Case constStrCarteAs
                    'ON COMPTE LE NOMBRE DE A
                    intCompteurA += 1
                    If intCompteurA >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteKing
                    'ON COMPTE LE NOMBRE DE K
                    intCompteurK += 1
                    If intCompteurK >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteQueen
                    'ON COMPTE LE NOMBRE DE Q
                    intCompteurQ += 1
                    If intCompteurQ >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarteJack
                    'ON COMPTE LE NOMBRE DE J
                    intCompteurJ += 1
                    If intCompteurJ >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte10
                    'ON COMPTE LE NOMBRE DE 10
                    intCompteur10 += 1
                    If intCompteur10 >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte9
                    'ON COMPTE LE NOMBRE DE 9
                    intCompteur9 += 1
                    If intCompteur9 >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte8
                    'ON COMPTE LE NOMBRE DE 8
                    intCompteur8 += 1
                    If intCompteur8 >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte7
                    'ON COMPTE LE NOMBRE DE 7
                    intCompteur7 += 1
                    If intCompteur7 >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte6
                    'ON COMPTE LE NOMBRE DE 6
                    intCompteur6 += 1
                    If intCompteur6 >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte5
                    'ON COMPTE LE NOMBRE DE 5
                    intCompteur5 += 1
                    If intCompteur5 >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte4
                    'ON COMPTE LE NOMBRE DE 4
                    intCompteur4 += 1
                    If intCompteur4 >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte3
                    'ON COMPTE LE NOMBRE DE 3
                    intCompteur3 += 1
                    If intCompteur3 >= 2 Then
                        boolJeuEnMain = True
                    End If
                Case constStrCarte2
                    'ON COMPTE LE NOMBRE DE 2
                    intCompteur2 += 1
                    If intCompteur2 >= 2 Then
                        boolJeuEnMain = True
                    End If
            End Select
        Next

        'RETOURNE TRUE OU FALSE SI IL Y A UNE PAIRE
        fntJeuEnMainOnePaire = boolJeuEnMain

    End Function

    Private Function fntJeuEnMainHighCard(ByVal tableauJeuCarte(,) As String) As Integer

        'HIGH CARD
        Dim ibtJeuEnMain As Integer = 0
        Dim intTemp As Integer = 0
        Dim intNombreDeRow As Integer = tableauJeuCarte.GetLength(0) - 1
        For i = 0 To intNombreDeRow
            Select Case tableauJeuCarte(i, constIntDimensionPositionNOMBRE)
                Case constStrCarteAs
                    If (intTemp < constIntCarteAs) Then
                        intTemp = constIntCarteAs
                    End If
                Case constStrCarteKing
                    If (intTemp < constIntCarteKing) Then
                        intTemp = constIntCarteKing
                    End If
                Case constStrCarteQueen
                    If (intTemp < constIntCarteQueen) Then
                        intTemp = constIntCarteQueen
                    End If
                Case constStrCarteJack
                    If (intTemp < constIntCarteJack) Then
                        intTemp = constIntCarteJack
                    End If
                Case constStrCarte10
                    If (intTemp < constIntCarte10) Then
                        intTemp = constIntCarte10
                    End If
                Case constStrCarte9
                    If (intTemp < constIntCarte9) Then
                        intTemp = constIntCarte9
                    End If
                Case constStrCarte8
                    If (intTemp < constIntCarte8) Then
                        intTemp = constIntCarte8
                    End If
                Case constStrCarte7
                    If (intTemp < constIntCarte7) Then
                        intTemp = constIntCarte7
                    End If
                Case constStrCarte6
                    If (intTemp < constIntCarte6) Then
                        intTemp = constIntCarte6
                    End If
                Case constStrCarte5
                    If (intTemp < constIntCarte5) Then
                        intTemp = constIntCarte5
                    End If
                Case constStrCarte4
                    If (intTemp < constIntCarte4) Then
                        intTemp = constIntCarte4
                    End If
                Case constStrCarte3
                    If (intTemp < constIntCarte3) Then
                        intTemp = constIntCarte3
                    End If
                Case constStrCarte2
                    If (intTemp < constIntCarte2) Then
                        intTemp = constIntCarte2
                    End If

            End Select
        Next

        'RETOUR DE FONCTION
        fntJeuEnMainHighCard = intTemp

    End Function

    Private Function fntJeuEnMain(ByVal intJeu As Integer) As String

        Dim strJeu As String = ""
        'DONNE LE NOM DU TYPE DE JEU EN MAIN
        Select Case intJeu
            Case constIntForceCarteRoyaleFlush
                strJeu = constStrForceCarteRoyaleFlush
            Case constIntForceCarteStraitFlush
                strJeu = constStrForceCarteStraitFlush
            Case constIntForceCarteFourOfKind
                strJeu = constStrForceCarteFourOfKind
            Case constIntForceCarteFullHouse
                strJeu = constStrForceCarteFullHouse
            Case constIntForceCarteFlushCouleur
                strJeu = constStrForceCarteFlushCouleur
            Case constIntForceCarteSuiteStraight
                strJeu = constStrForceCarteSuiteStraight
            Case constIntForceCarteBrelan
                strJeu = constStrForceCarteBrelan
            Case constIntForceCarteTwoPaire
                strJeu = constStrForceCarteTwoPaire
            Case constIntForceCarteOnePaire
                strJeu = constStrForceCarteOnePaire
            Case constIntForceCarteHishCard
                strJeu = constStrForceCarteHishCard

        End Select

        'RETOUR DE FONCTION
        fntJeuEnMain = strJeu

    End Function

    Private Sub lblMontant_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblMontant.TextChanged

        'ON SURVEILLE LE STATUS DU JOEUR PAR SON ARGENT
        Dim intComparaisonNb1 As Integer
        Dim intComparaisonNb2 As Integer
        Dim intComparaisonNb3 As Integer
        Dim dblMontant As Double
        'COMPARAISON MONAITAIRE
        intComparaisonNb1 = CInt(lblMontant.Text)
        intComparaisonNb2 = CInt(constStrCurrencyMiseDefaultValue)
        intComparaisonNb3 = CInt(constStrCurrencyMiseCentMilleValue)

        'SI J AI MOIN DE 1000$ JE NE PEUT PAS AUGMENTER MA MISE
        If (intComparaisonNb1 < intComparaisonNb3) Then
            btnRaiseUp.Enabled = False
        End If

        'SI J AI MOIN DE 1000$ JE NE PEUT PAS AUGMENTER MA MISE
        If (intComparaisonNb1 < intComparaisonNb2) Then
            btnRaiseUp.Enabled = False
        End If

        'LE JOUEUR A FAITE FAILLITE
        dblMontant = CDbl(lblMontant.Text)
        If (dblMontant <= 0) Then
            btnEqualiser.Enabled = False
            btnFold.Enabled = False
            btnJouer.Enabled = False
            btnRaiseDonw.Enabled = False
            btnRaiseUp.Enabled = False
            btnCheck.Enabled = False
            lblMontant.Text = fntStrCurrency("0")
            subFntMessageJoueur(constStrGameOver & vbCr & lblMontant.Text)
        End If

    End Sub

    Private Sub btnRaiseUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseUp.Click

        'BTN RAISE UP LE JOEUR VEUT MONTER SA MISE
        Dim strMiseJoueur As String

        'CALCULER LE MONTANT MISER
        strMiseJoueur = CStr(CInt(lblMiseJoeur.Text) + CInt(constStrCurrencyMiseDefaultValue))
        lblMiseJoeur.Text = fntStrCurrency(strMiseJoueur)

        strMiseJoueur = CStr(CInt(lblMontant.Text) - CInt(constStrCurrencyMiseDefaultValue))
        lblMontant.Text = fntStrCurrency(strMiseJoueur)

        'ACTIVE LE BOUTON DIMINUER LA MISE
        If CInt(lblMiseJoeur.Text) > 0 Then
            btnRaiseDonw.Enabled = True
            btnJouer.Enabled = True
        End If

        bolAllIn = False

    End Sub

    Private Sub subFntSauveGarderLaPartie()

        'ON ENREGISTRE LA PARTIE EN COUR
        Dim strPath As String = Application.StartupPath & constStringSaveData
        Dim strNewline As String
        Dim tblStrDataUsager(6) As String
        Dim strNom As String
        Dim strPrenom As String
        Dim strAnneeDeNaissance As String
        Dim strUserName As String
        Dim strPsw As String
        Dim intMontant As Integer
        Dim boolCompteActif As Boolean

        'RECUPERER LES VALEURS DE L USAGER
        tblStrDataUsager = fnctRechercheUserData()
        strNom = tblStrDataUsager(0)
        strPrenom = tblStrDataUsager(1)
        strAnneeDeNaissance = tblStrDataUsager(2)
        strUserName = tblStrDataUsager(3)
        strPsw = tblStrDataUsager(4)
        'ON MODIFIE LE MONTANT D ARGENT QU IL AVAIT PAR LA SOMME QU IL A ACTUELLEMENT
        intMontant = CInt(lblMontant.Text)
        boolCompteActif = CBool(tblStrDataUsager(6))

        strNewline = strNom & constStrSeparateur & strPrenom & constStrSeparateur & strAnneeDeNaissance & constStrSeparateur & strUserName & constStrSeparateur & strPsw & constStrSeparateur & CStr(intMontant) & constStrSeparateur & boolCompteActif
        'ON REPLACE L ANCIENNE INFORMATION PAR LE NOUVEAU
        If System.IO.File.Exists(strPath) Then
            Dim lines() As String = IO.File.ReadAllLines(strPath)
            For i As Integer = 0 To lines.Length - 1
                If lines(i).Contains(strPlayer) Then
                    lines(i) = strNewline
                End If
            Next
            'SAVE DATA TO THE FILE
            IO.File.WriteAllLines(strPath, lines)
        Else
            'ERREUR FICHIER CORROMPU OU EFFACER
            subFntMessageJoueur(constStrErreurDeSauvegarde)
        End If

    End Sub

    Private Sub subFntSauveGarderLaPartie(ByVal boolCompteActif As Boolean)

        'ON ENREGISTRE LA PARTIE EN COUR
        Dim strPath As String = Application.StartupPath & constStringSaveData
        Dim strNewline As String
        Dim tblStrDataUsager(7) As String
        Dim strNom As String
        Dim strPrenom As String
        Dim strAnneeDeNaissance As String
        Dim strUserName As String
        Dim strPsw As String
        Dim intMontant As Integer

        'RECUPERER LES VALEURS DE L USAGER
        tblStrDataUsager = fnctRechercheUserData()
        strNom = tblStrDataUsager(0)
        strPrenom = tblStrDataUsager(1)
        strAnneeDeNaissance = tblStrDataUsager(2)
        strUserName = tblStrDataUsager(3)
        strPsw = tblStrDataUsager(4)
        'ON MODIFIE LE MONTANT D ARGENT QU IL AVAIT PAR LA SOMME QU IL A ACTUELLEMENT
        intMontant = CInt(lblMontant.Text)

        strNewline = strNom & constStrSeparateur & strPrenom & constStrSeparateur & strAnneeDeNaissance & constStrSeparateur & strUserName & constStrSeparateur & strPsw & constStrSeparateur & CStr(intMontant) & constStrSeparateur & boolCompteActif
        'ON REPLACE L ANCIENNE INFORMATION PAR LE NOUVEAU
        If System.IO.File.Exists(strPath) Then
            Dim lines() As String = IO.File.ReadAllLines(strPath)
            For i As Integer = 0 To lines.Length - 1
                If lines(i).Contains(strPlayer) Then
                    lines(i) = strNewline
                End If
            Next
            'SAVE DATA TO THE FILE
            IO.File.WriteAllLines(strPath, lines)
        Else
            'ERREUR FICHIER CORROMPU OU EFFACER
            subFntMessageJoueur(constStrErreurDeSauvegarde)
        End If

    End Sub

    Private Function fnctRechercheUserData() As String()

        'FONCTION QUI CHERCHE LES INFORMATION SUR LE JOUEUR EN COUR
        Dim tblStrDataUsager(6) As String
        Dim strNom As String
        Dim strPrenom As String
        Dim strAnneeDeNaissance As String
        Dim strUserName As String
        Dim strPsw As String
        Dim strMontant As String
        Dim boolCompteActif As Boolean = True

        If (CInt(lblMontant.Text) = 0) Then
            boolCompteActif = False
        End If

        'LECTURE DU FICHIER DE SAUVEGARDE
        Using MyReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(Application.StartupPath & constStringSaveData)
            MyReader.TextFieldType = FileIO.FieldType.Delimited
            MyReader.SetDelimiters(constStrSeparateur)

            'TABLEAU D INFORMATION DE LA LIGNE EN COURS
            Dim currentRow As String()

            While Not MyReader.EndOfData
                Try
                    'OBTENIR LES DONNEES DU FICHIER CSV
                    currentRow = MyReader.ReadFields()
                    strNom = currentRow(0)
                    strPrenom = currentRow(1)
                    strAnneeDeNaissance = currentRow(2)
                    strUserName = currentRow(3)
                    strPsw = currentRow(4)
                    strMontant = currentRow(5)
                    boolCompteActif = CBool(currentRow(6))

                    'EXIT DE FORCE DE LA BOUCLE WHILE DES QUE J AI TROUVER MON USER
                    If (strUserName = strPlayer) Then
                        tblStrDataUsager(0) = strNom
                        tblStrDataUsager(1) = strPrenom
                        tblStrDataUsager(2) = strAnneeDeNaissance
                        tblStrDataUsager(3) = strUserName
                        tblStrDataUsager(4) = strPsw
                        tblStrDataUsager(5) = strMontant
                        tblStrDataUsager(6) = CStr(boolCompteActif)
                        Exit While
                    End If
                Catch ex As Exception

                End Try
            End While

        End Using

        fnctRechercheUserData = tblStrDataUsager

    End Function

    Private Sub timSauvegardeAutomatique_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timSauvegardeAutomatique.Tick
        'SAUVEGARDE AUTOMATIQUE A TOUS LES 3 MINUTES
        subFntSauveGarderLaPartie()
    End Sub

    Private Sub btnRaiseUpCentsMille_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseUpCentsMille.Click

        'BTN RAISE UP LE JOEUR VEUT MONTER SA MISE
        Dim strMiseJoueur As String

        'CALCULER LE MONTANT MISER
        strMiseJoueur = CStr(CInt(lblMiseJoeur.Text) + CInt(constStrCurrencyMiseCentMilleValue))
        lblMiseJoeur.Text = fntStrCurrency(strMiseJoueur)

        strMiseJoueur = CStr(CInt(lblMontant.Text) - CInt(constStrCurrencyMiseCentMilleValue))
        lblMontant.Text = fntStrCurrency(strMiseJoueur)

        'ACTIVE LE BOUTON DIMINUER LA MISE
        If CInt(lblMiseJoeur.Text) > 0 Then
            btnRaiseDonw.Enabled = True
            btnRaiseDownCentsMille.Enabled = True
            btnJouer.Enabled = True
        End If
        bolAllIn = False
    End Sub

    Private Sub btnRaiseDownCentsMille_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseDownCentsMille.Click

        'LE JOUEUR VEUT BAISSER SA MISE
        Dim strMiseJoueur As String

        'CALCULER LE MONTANT MISER
        strMiseJoueur = CStr(CInt(lblMiseJoeur.Text) - CInt(constStrCurrencyMiseCentMilleValue))
        lblMiseJoeur.Text = fntStrCurrency(strMiseJoueur)

        strMiseJoueur = CStr(CInt(lblMontant.Text) + CInt(constStrCurrencyMiseCentMilleValue))
        lblMontant.Text = fntStrCurrency(strMiseJoueur)

        'DESACTIVE LE BOUTON DIMINUER LA MISE
        If CInt(lblMiseJoeur.Text) = 0 Then
            btnRaiseDonw.Enabled = False
            btnRaiseDownCentsMille.Enabled = False
            btnJouer.Enabled = False
        Else
            btnAllIn.Enabled = True
            btnRaiseUpCentsMille.Enabled = True
            btnRaiseUp.Enabled = True
            btnRaiseDonw.Enabled = True
            btnJouer.Enabled = True
        End If
        bolAllIn = False
    End Sub

    Private Sub btnAllIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAllIn.Click

        'ALL IN
        'CALCULER LE ALL IN ET L AFFICHER
        Dim intAllIn As Integer
        Dim intMEgualiserAllIn As Integer

        intMEgualiserAllIn = CInt(lblMiseJoeur.Text)
        intAllIn = CInt(lblMontant.Text) + intMEgualiserAllIn
        lblMiseJoeur.Text = fntStrCurrency(CStr(intAllIn))
        lblMontant.Text = fntStrCurrency(constStrCurrencyDefaultValue)

        'LE CROUPIER EGALISE LE ALL IN
        intAllIn = CInt(lblMiseCroupier.Text) + intMEgualiserAllIn
        lblMiseCroupier.Text = fntStrCurrency(CStr(intAllIn))

        'DESACTIVATION DES BOUTONS
        btnAllIn.Enabled = False
        btnRaiseUpCentsMille.Enabled = False
        btnRaiseUp.Enabled = False
        btnFold.Enabled = False
        btnCheck.Enabled = False
        btnJouer.Enabled = True
        bolAllIn = True

    End Sub

    Private Sub tsmCommencer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmCommencer.Click

        
        'COMMENCER LA PARTIE
        subFntCommencerLaPartier()

    End Sub

    Private Sub tsmSauvegarder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmSauvegarder.Click

        'SAUVEGARDE DU JEU

        subFntSauveGarderLaPartie()
        subFntMessageJoueur(constStrSauvegarde)

    End Sub

    Private Sub tsmDéconnecter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmDéconnecter.Click

        'ON SAUVEGARDE LA PARTIE EN COURS
        subFntSauveGarderLaPartie()
        'ON CACHE LE FRAME ACTUEL ET ON FAIT APPARAITRE CELUI DE LA PAGE D ACCUEIL
        Me.Hide()
        frmEmicaPokerTimeHoldem.Show()

    End Sub

    Private Sub tsmQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmQuitter.Click

        'Sauvegarder la partie
        subFntSauveGarderLaPartie()
        'ARRET DU PROGRAMME
        frmEmicaPokerTimeHoldem.fntArretProgramme()

    End Sub

    Private Sub tsmGameRules_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmGameRules.Click

        'AFFICHER LA FORM QUI DONNE LES REGLEMENT DU JEU.
        frmReglement.Show()

    End Sub

    Private Sub tsmAide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAide.Click

        'ON AFFICHE LE FRAME AIDE
        frmAide.Show()

    End Sub

    Private Sub tsmAPropos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAPropos.Click

        'AFFICHER LE FRAME AUTEUR
        frmAPropos.Show()

    End Sub


    Private Sub subFntJeuCroupier()

        'VERSION D INTELIGENCE ARTIFICIELLE - IA - POUR LE CROUPIER
        'C EST ON TOUR DU CROUPIER A JOUER
        Dim intCarteCroupierPosition As Integer = 7
        Dim intCarteCarteCommuneFlop As Integer = 2
        Dim strTabJeuCroupier(1, 3) As String
        Dim strTableauFlop(3, 3) As String

        intRlanceEnCour += 1

        Select Case intRlanceEnCour
            Case 1
                'CAS PREMIER RELANCE AVEC UNIQUEMENT NOS 2 CARTE EN MAIN
                strTabJeuCroupier(0, constIntDimensionPositionNOMBRE) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionNOMBRE)
                strTabJeuCroupier(0, constIntDimensionPositionSYMBOLE) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionSYMBOLE)
                strTabJeuCroupier(0, constIntDimensionPositionCOULEUR) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionCOULEUR)
                strTabJeuCroupier(0, constIntDimensionPositionPATH) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionPATH)
                intCarteCroupierPosition += 1

                strTabJeuCroupier(1, constIntDimensionPositionNOMBRE) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionNOMBRE)
                strTabJeuCroupier(1, constIntDimensionPositionSYMBOLE) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionSYMBOLE)
                strTabJeuCroupier(1, constIntDimensionPositionCOULEUR) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionCOULEUR)
                strTabJeuCroupier(1, constIntDimensionPositionPATH) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionPATH)

                'ON FAIT UN CHOIX SI ON RELANCE OU PAS
                If fntJeuEnMainOnePaire(strTabJeuCroupier, strTabJeuCroupier.GetLength(0)) Then
                    'SI LE CROUPIER A UNE PAIRE IL RELANCE
                    subFntRelance()
                ElseIf fnJeuEnMainFigure(strTabJeuCroupier, strTabJeuCroupier.GetLength(0)) Then
                    'SI LE CROUPIER A UNE FIGURE IL RELANCE
                    subFntRelance()
                End If
            Case 2
                ''CASE AVEC NOS 2 CARTE EN MAIN PLUS LA FLOP.
                strTableauFlop(0, constIntDimensionPositionNOMBRE) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionNOMBRE)
                strTableauFlop(0, constIntDimensionPositionSYMBOLE) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionSYMBOLE)
                strTableauFlop(0, constIntDimensionPositionCOULEUR) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionCOULEUR)
                strTableauFlop(0, constIntDimensionPositionPATH) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionPATH)
                intCarteCroupierPosition += 1

                strTableauFlop(1, constIntDimensionPositionNOMBRE) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionNOMBRE)
                strTableauFlop(1, constIntDimensionPositionSYMBOLE) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionSYMBOLE)
                strTableauFlop(1, constIntDimensionPositionCOULEUR) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionCOULEUR)
                strTableauFlop(1, constIntDimensionPositionPATH) = tblStrCard(intCarteCroupierPosition, constIntDimensionPositionPATH)

                strTableauFlop(2, constIntDimensionPositionNOMBRE) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionNOMBRE)
                strTableauFlop(2, constIntDimensionPositionSYMBOLE) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionSYMBOLE)
                strTableauFlop(2, constIntDimensionPositionCOULEUR) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionCOULEUR)
                strTableauFlop(2, constIntDimensionPositionPATH) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionPATH)
                intCarteCarteCommuneFlop += 1

                strTableauFlop(2, constIntDimensionPositionNOMBRE) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionNOMBRE)
                strTableauFlop(2, constIntDimensionPositionSYMBOLE) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionSYMBOLE)
                strTableauFlop(2, constIntDimensionPositionCOULEUR) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionCOULEUR)
                strTableauFlop(2, constIntDimensionPositionPATH) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionPATH)
                intCarteCarteCommuneFlop += 1

                strTableauFlop(3, constIntDimensionPositionNOMBRE) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionNOMBRE)
                strTableauFlop(3, constIntDimensionPositionSYMBOLE) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionSYMBOLE)
                strTableauFlop(3, constIntDimensionPositionCOULEUR) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionCOULEUR)
                strTableauFlop(3, constIntDimensionPositionPATH) = tblStrCard(intCarteCarteCommuneFlop, constIntDimensionPositionPATH)

                'LES 2 CARTES EN MAIN + LA FLOP ON VERIFIE SI ON A UN BON JEU.
                If fntJeuEnMain(strTableauFlop) >= constIntForceCarteFlushCouleur Then
                    'SI LE JEUX DU GROUPIER EST SUPERIEUR OU EGALE A LA FLUSH IL RELANCE
                    subFntRelance()
                End If



        End Select




    End Sub

    Private Function fnJeuEnMainFigure(ByVal strTabFigure(,) As String, ByVal intMax As Integer) As Boolean

        'VIRIFIE SI LE CROUPIER A L UNE DE CES CARTE EN MAIN
        'Const constStrCarteAs As String = "A"
        'Const constStrCarteKing As String = "K"
        'Const constStrCarteQueen As String = "Q"
        'Const constStrCarteJack As String = "J"
        'Const constStrCarte10 As String = "10"

        Dim bolFigure = False

        If strTabFigure(0, constIntDimensionPositionNOMBRE) = constStrCarteAs Then
            bolFigure = True
        ElseIf strTabFigure(0, constIntDimensionPositionNOMBRE) = constStrCarteKing Then
            bolFigure = True
        ElseIf strTabFigure(0, constIntDimensionPositionNOMBRE) = constStrCarteQueen Then
            bolFigure = True
        ElseIf strTabFigure(0, constIntDimensionPositionNOMBRE) = constStrCarteJack Then
            bolFigure = True
        ElseIf strTabFigure(0, constIntDimensionPositionNOMBRE) = constStrCarte10 Then
            bolFigure = True
        ElseIf strTabFigure(1, constIntDimensionPositionNOMBRE) = constStrCarteAs Then
            bolFigure = True
        ElseIf strTabFigure(1, constIntDimensionPositionNOMBRE) = constStrCarteKing Then
            bolFigure = True
        ElseIf strTabFigure(1, constIntDimensionPositionNOMBRE) = constStrCarteQueen Then
            bolFigure = True
        ElseIf strTabFigure(1, constIntDimensionPositionNOMBRE) = constStrCarteJack Then
            bolFigure = True
        ElseIf strTabFigure(1, constIntDimensionPositionNOMBRE) = constStrCarte10 Then
            bolFigure = True
        End If

        'RETOURNE SI ON A UNE FIGRUE OU PAS
        fnJeuEnMainFigure = bolFigure

    End Function

    Private Sub btnCommencerLaPartie_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCommencerLaPartie.Click

        'ON COMMENCE LA PARTIE
        subFntCommencerLaPartier()

    End Sub
End Class