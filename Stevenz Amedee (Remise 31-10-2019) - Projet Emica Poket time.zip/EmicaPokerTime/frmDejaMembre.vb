﻿Option Strict On
Imports System.IO

Public Class frmDejaMembre

    'CONSTANCE MSG ERREUR
    Const constStrErreurSaissi As String = "Erreur : Veuillez entrer votre : "
    Const constStrErreurUsagerInvalide As String = "Adresse courrielle invalide."
    Const constStrErreurUsagerInvalideNotFound As String = "Adresse courrielle invalide. Il n'a pas été trouvé."
    'DECLARATION DES CONSTANTE DU FICHIER SAVE DATA
    Const constStringSaveData As String = "\Textes\data.csv"
    Const constStrMessageErreur As String = "Erreur de : Nom d usager ou Mot de Passe."
    Const constStrSeparateur As String = ";"
    Const constStrNombreDeTentative As String = "Nombre de tentative : "
    Const constStrMessageErreurSystem As String = "Erreur-3TCF : Desole veuillez communiquez avec l'administrateur." & vbCr & "Si vous avez oublie votre nom d usager ou mot de passe." & vbCr & "Compte verouille"
    Const constStrMessageGameOver As String = "Erreur CVPA - Compte verrouillez pour insuffisance de fond."
    Const constIntTentativeMax As Integer = 3
    Const constIntPositionUsername As Integer = 3
    Const constIntPositionPSW As Integer = 4

    'DECLARATION DE VARIABLE
    Dim intTentative As Integer = 0
    Dim strNom As String = ""
    Dim strPrenom As String = ""


    Private Sub frmDejaMembre_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'SET L INTERFACE GUI UTLISATEUR
        'JE DEFINI L IMAGE EN BACKGROUE
        'JE DEFINI LA GRANDEUR DE L ECRAN UTILISATEUR POUR POSITIONNER L INTERFACE EN PLEIN CENTRE
        'DECLARATION DE VARIABLE ET INITIALISATION
        Dim strPathImgBackground As String = "\Images\" & "imgTapis.jpg"
        Dim strPathImgJettonJoueur As String = "\Images\" & "imgJettonJoueur.png"
        Dim intWidthX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intHeightY As Integer = Screen.PrimaryScreen.Bounds.Height

        'POSITIONER AU CENTRE MON PANEL
        Me.Size = New System.Drawing.Size(1362, 740)
        Me.Location = New Point(CInt((intWidthX / 2) - (Me.Width / 2)), CInt(((intHeightY / 2) - (Me.Height / 2))))

        'INSERTION DE L IMAGE BACKGROUND
        picBackgroundImage.Image = Image.FromFile(Application.StartupPath & strPathImgBackground)
        picImgJettonJoueur.Image = Image.FromFile(Application.StartupPath & strPathImgJettonJoueur)

        picImgJettonJoueur.Parent = picBackgroundImage
        picImgJettonJoueur.BackColor = Color.Transparent

        lblMessage.BackColor = Color.Transparent
        lblPasseword.BackColor = Color.Transparent
        lblUsername.BackColor = Color.Transparent
        lblMessageErreurSystem.BackColor = Color.Transparent

        lblMessage.Parent = picBackgroundImage
        lblPasseword.Parent = picBackgroundImage
        lblUsername.Parent = picBackgroundImage
        lblMessageErreurSystem.Parent = picBackgroundImage
        lblMessageErreurSystem.Visible = False

        txtUsername.TabIndex = 1
        txtPassword.TabIndex = 2

        btnConnection.TabIndex = 3
        btnConnection.AutoEllipsis = True
        btnConnection.FlatStyle = FlatStyle.System

        btnQuitterConnection.TabIndex = 4
        btnQuitterConnection.AutoEllipsis = True
        btnQuitterConnection.FlatStyle = FlatStyle.System

        btnQuitter.TabIndex = 5
        btnQuitter.AutoEllipsis = True
        btnQuitter.FlatStyle = FlatStyle.System

        txtUsername.Text = ""
        txtPassword.Text = ""

    End Sub

    Private Sub btnConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnection.Click

        'DECLARATION DE VARIABLE
        Dim strUsername As String = ""
        Dim strPSW As String = ""
        Dim strAmount As String = ""
        Dim boolActif As Boolean = False
        Dim strSubString As String = ""
        Dim intPosition As Integer = -1
        Dim bolEOFUserFound As Boolean = False

        strSubString = txtUsername.Text
        If (strSubString.Length > 4) Then
            strSubString = Strings.Right(strSubString, 4)
            intPosition = strSubString.IndexOf(".")
        End If
        

        If (((Not (txtUsername.Text).ToLower.Contains("@")) And (Not (txtUsername.Text).ToLower.Contains("."))) And Not (intPosition = 0)) Then
            'MESSAGE D ERREUR EMAIL INVALIDE
            MsgBox(constStrErreurSaissi & constStrErreurUsagerInvalide)
        Else

            'LECTURE DES DONNE DANS LE FICHIER DATA.CSV
            Using MyReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(Application.StartupPath & constStringSaveData)
                MyReader.TextFieldType = FileIO.FieldType.Delimited
                MyReader.SetDelimiters(constStrSeparateur)

                'TABLEAU D INFORMATION DE LA LIGNE EN COURS
                Dim currentRow As String()

                'TANT QU IL Y A DE QUOI A LIRE J USQU AU BOUT DU FICHIER EOF
                While Not MyReader.EndOfData
                    Try
                        currentRow = MyReader.ReadFields()
                        strNom = currentRow(0)
                        strPrenom = currentRow(1)
                        strUsername = currentRow(3)
                        strPSW = currentRow(4)
                        strAmount = currentRow(5)
                        boolActif = CBool(currentRow(6))

                        'EXIT DE FORCE DE LA BOUCLE WHILE DES QUE J AI TROUVER MON USER
                        If ((strUsername = (txtUsername.Text).ToLower) And (strPSW = (txtPassword.Text).ToLower)) Then
                            bolEOFUserFound = True
                            Exit While
                        Else
                            bolEOFUserFound = False
                        End If

                    Catch ex As Exception

                    End Try
                End While

            End Using

            If bolEOFUserFound Then
                'SI LE USER A ETE TROUVE PRENDRE LES PRINCIPAUX INFORMATION POUR INITIALISER LE NOUVEAU FRAME QUI VA S OUVRIRE
                If ((strUsername = (txtUsername.Text).ToLower) And (strPSW = (txtPassword.Text).ToLower)) And boolActif Then

                    'EEFACER LES VALEURS ACTUELLES
                    txtPassword.Text = ""
                    txtUsername.Text = ""

                    Me.Hide()
                    frmGamePlay.strPlayer = strUsername
                    frmGamePlay.strNomPrenom = strPrenom & " " & strNom
                    frmGamePlay.strAmount = strAmount
                    frmGamePlay.Show()
                ElseIf ((strUsername = (txtUsername.Text).ToLower) And (strPSW = (txtPassword.Text).ToLower)) And Not boolActif Then
                    'COMPTE INACTIF LE JOUEUR N A PU D ARGENT
                    subFntMessageJoueur(constStrMessageGameOver)
                Else
                    'ERRUER DE USER NAME OU DE MOT DE PASSE
                    'ON INCREMENTE LE NOMBRE DE TENTATICE DEJA FAITE
                    'ON EFFACE LE MOT PASSE INSCRIT DANS LE TEXTFIELD
                    'ON ENVOIE MESSAGE A L USAGER
                    intTentative += 1
                    txtPassword.Text = ""
                    subFntMessageJoueur(constStrMessageErreur & vbCr & constStrNombreDeTentative & " " & intTentative)

                    'SI IL Y A 3 TANTATIVE MESSAGE D ERREUR
                    'ON DESACTIF LE COMPTE DU USER
                    If intTentative = constIntTentativeMax Then
                        lblMessageErreurSystem.Visible = True
                        lblMessageErreurSystem.Text = constStrMessageErreurSystem
                        subFntSauveGarderLaPartie(strUsername)

                    End If

                End If
            Else
                'ADDRESE COURRIEL NON TROUVÉ
                strNom = txtUsername.Text
                subFntMessageJoueur(constStrErreurUsagerInvalideNotFound)
            End If
          

        End If

    End Sub

    Private Sub subFntMessageJoueur(ByRef msg As String)

        'AFFICHE UN MESSAGE A L UTILISATEUR
        lblMessageErreurSystem.Visible = True
        lblMessageErreurSystem.Text = txtUsername.Text & " : " & vbCr & msg

    End Sub

    Private Sub btnQuitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitter.Click

        'QUITTER LE JEUX
        frmEmicaPokerTimeHoldem.fntArretProgramme()

    End Sub

    Private Sub btnQuitterConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuitterConnection.Click

        'RETOUR A LA PAGE D'ACCEUIL
        Me.Hide()
        frmEmicaPokerTimeHoldem.Show()

    End Sub

    Private Sub subFntSauveGarderLaPartie(ByVal strPlayer As String)

        Dim strPath As String = Application.StartupPath & constStringSaveData
        Dim strNewline As String
        Dim tblStrDataUsager(7) As String
        Dim strNom As String
        Dim strPrenom As String
        Dim strAnneeDeNaissance As String
        Dim strUserName As String
        Dim strPsw As String
        Dim strMontant As String

        'RECUPERER LES VALEURS DE L USAGER
        tblStrDataUsager = fntRechercheUserData(strPlayer)
        strNom = tblStrDataUsager(0)
        strPrenom = tblStrDataUsager(1)
        strAnneeDeNaissance = tblStrDataUsager(2)
        strUserName = tblStrDataUsager(3)
        strPsw = tblStrDataUsager(4)
        strMontant = tblStrDataUsager(5)

        'ON DESACTIF LE COMPTE DU USER A FALSE
        strNewline = strNom & constStrSeparateur & strPrenom & constStrSeparateur & strAnneeDeNaissance & constStrSeparateur & strUserName & constStrSeparateur & strPsw & constStrSeparateur & strMontant & constStrSeparateur & False
        'ON REPLACE L ANCIENNE INFORMATION PAR LE NOUVEAU
        If System.IO.File.Exists(strPath) Then
            Dim lines() As String = IO.File.ReadAllLines(strPath)
            For i As Integer = 0 To lines.Length - 1
                If lines(i).Contains(strPlayer) Then
                    lines(i) = strNewline
                End If
            Next
            'SAVE DATA TO THE FILE
            IO.File.WriteAllLines(strPath, lines)
        End If

    End Sub

    Private Function fntRechercheUserData(ByVal strPlayer As String) As String()

        'FONCTION QUI CHERCHE LES INFORMATION SUR LE JOUEUR EN COUR
        Dim strNom As String
        Dim strPrenom As String
        Dim strAnneeDeNaissance As String
        Dim strUserName As String
        Dim strPsw As String
        Dim strMontant As String
        Dim boolCompteActif As Boolean = True

        Dim tblStrDataUsager(7) As String

        Using MyReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(Application.StartupPath & constStringSaveData)
            MyReader.TextFieldType = FileIO.FieldType.Delimited
            MyReader.SetDelimiters(constStrSeparateur)

            'TABLEAU D INFORMATION DE LA LIGNE EN COURS
            Dim currentRow As String()

            While Not MyReader.EndOfData
                Try
                    'OBTENIR LES DONNEES DU FICHIER CSV
                    currentRow = MyReader.ReadFields()
                    strNom = currentRow(0)
                    strPrenom = currentRow(1)
                    strAnneeDeNaissance = currentRow(2)
                    strUserName = currentRow(3)
                    strPsw = currentRow(4)
                    strMontant = currentRow(5)
                    boolCompteActif = CBool(currentRow(6))


                    'EXIT DE FORCE DE LA BOUCLE WHILE DES QUE J AI TROUVER MON USER
                    If (strUserName = strPlayer) Then
                        tblStrDataUsager(0) = strNom
                        tblStrDataUsager(1) = strPrenom
                        tblStrDataUsager(2) = strAnneeDeNaissance
                        tblStrDataUsager(3) = strUserName
                        tblStrDataUsager(4) = strPsw
                        tblStrDataUsager(5) = strMontant
                        tblStrDataUsager(6) = CStr(boolCompteActif)
                        Exit While
                    End If
                Catch ex As Exception

                End Try
            End While

        End Using

        fntRechercheUserData = tblStrDataUsager

    End Function

    Private Sub tsmDevenirMembre_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmDevenirMembre.Click

        'CACHER LA PAGE ACTUELLE
        Me.Hide()
        'OUVRIRE LA PAGE INSCRIPTION
        frmInscription.Show()
    End Sub

    Private Sub tsmItemAccueil_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmItemAccueil.Click

        'FERMER LA PAGE ACTUELLE
        Me.Hide()
        'OUVRIRE LA PAGE D AUCCUEIL
        frmEmicaPokerTimeHoldem.Show()

    End Sub

    Private Sub tsmQuittezLeJeux_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmQuittezLeJeux.Click

        'QUITTER LE JEUX
        frmEmicaPokerTimeHoldem.fntArretProgramme()

    End Sub

    Private Sub tsmAideMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAideMenu.Click

        'ON AFFICHE LE FRAME AIDE
        frmAide.Show()

    End Sub

    Private Sub tsmAPropaoMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAPropaoMenu.Click

    'AFFICHER LE FRAME AUTEUR
        frmAPropos.Show()

    End Sub

    Private Sub btnEffacerTout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEffacerTout.Click

        'EFFACER TOUT
        txtUsername.Text = ""
        txtPassword.Text = ""

    End Sub

    Private Sub txtUsername_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtUsername.LostFocus

        'CHANGEMENT DE COULEUR DU BACKGROUND LORSQU IL PERD LE FOCUS
        txtUsername.BackColor = Color.LightGray

    End Sub

    Private Sub txtUsername_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtUsername.TextChanged

        'CHANGEMENT DE COULEUR DU BACKGROUND LORSQU IL OBTIENT LE FOCUS
        txtUsername.BackColor = Color.White

    End Sub

    Private Sub txtPassword_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPassword.LostFocus

        'CHANGEMENT DE COULEUR DU BACKGROUND LORSQU IL PERD LE FOCUS
        txtPassword.BackColor = Color.LightGray

    End Sub

    Private Sub txtPassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPassword.TextChanged

        'CHANGEMENT DE COULEUR DU BACKGROUND LORSQU IL OBTIENT LE FOCUS
        txtPassword.BackColor = Color.White

    End Sub

End Class