﻿Option Strict On
Public Class frmReglement

    Private Sub frmReglement_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim strPathImgBackground As String = "imgTapis"
        Dim strPathImgJettonJoueur As String = "\Images\" & "imgJettonJoueur.png"

        ''OBTENIR LA HAUTEUR LARGEUR DE L ECRAN DE L UTILISATEUR
        Dim intWidthX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intHeighY As Integer = Screen.PrimaryScreen.Bounds.Height

        Me.Size = New System.Drawing.Size(1362, 740)
        Me.Location = New Point(CInt((intWidthX / 2) - (Me.Width / 2)), CInt(((intHeighY / 2) - (Me.Height / 2))))
        'AFFECTATION DU BACKGROUND IMAGE
        picBackgroundImage.Image = CType(My.Resources.ResourceManager.GetObject(strPathImgBackground), Image)
        picImgJettonJoueur.Image = Image.FromFile(Application.StartupPath & strPathImgJettonJoueur)

        picImgJettonJoueur.Parent = picBackgroundImage
        picImgJettonJoueur.BackColor = Color.Transparent

        lblMessage.Parent = picBackgroundImage
        lblMessage.BackColor = Color.Transparent

        lblConseilDeJeu.Parent = picBackgroundImage
        lblConseilDeJeu.BackColor = Color.Transparent

    End Sub

    Private Sub btnFermer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFermer.Click

        'FERNER LE FRAME ACTUELLE
        Me.Hide()

    End Sub

    Private Sub btnAllIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAllIn.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Cliquez dessus, si vous voulez faire tapis."
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub btnJouer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnJouer.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Ciquez dessus une fois que vous avez fait votre mise, le croupier devra égaliser votre mise"
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub btnRaiseUpCentsMille_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseUpCentsMille.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Cliquez dessus pour faire des mises par bon de 100,00.00$"
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub btnRaiseDownCentsMille_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseDownCentsMille.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Cliquez dessus pour baiser votre mise par bon de 100,00.00$"
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub btnRaiseUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseUp.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Cliquez dessus pour faire de mise par bon de 1,00.00$"
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub btnRaiseDonw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseDonw.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Cliquez dessus pour baiser votre mise par bon de 1,00.00$"
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub btnEqualiser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEqualiser.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Cliquez dessus, lorsque vous souhaite égaliser la mise du croupier"
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub btnFold_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFold.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Cliquez dessus pour jetter vos cartes et passer votre tour."
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click

        'DECLARATION ET INITIALISATION DU MESSAGE
        Dim strMessage As String = "Cliquez dessus pour donner la parole de la mise au croupier"
        'APPEL A LA SUB FUNCTION POUR AFFICHER MON MESSAGE
        subMessageUser(strMessage)

    End Sub

    Private Sub subMessageUser(ByVal strMessage As String)

        'AFFICHE UN MESSAGE A L UTILISATEUR
        lblMessage.Text = strMessage

    End Sub

End Class