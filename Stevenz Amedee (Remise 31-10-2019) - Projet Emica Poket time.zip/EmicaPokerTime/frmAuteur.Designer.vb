﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAPropos
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAPropos))
        Me.picBackgroundImage = New System.Windows.Forms.PictureBox()
        Me.btnFermer = New System.Windows.Forms.Button()
        Me.lblAuteur = New System.Windows.Forms.Label()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBackgroundImage
        '
        Me.picBackgroundImage.Location = New System.Drawing.Point(0, 0)
        Me.picBackgroundImage.Name = "picBackgroundImage"
        Me.picBackgroundImage.Size = New System.Drawing.Size(1346, 740)
        Me.picBackgroundImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBackgroundImage.TabIndex = 0
        Me.picBackgroundImage.TabStop = False
        '
        'btnFermer
        '
        Me.btnFermer.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnFermer.AutoEllipsis = True
        Me.btnFermer.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnFermer.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFermer.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnFermer.Location = New System.Drawing.Point(1084, 650)
        Me.btnFermer.Name = "btnFermer"
        Me.btnFermer.Size = New System.Drawing.Size(250, 39)
        Me.btnFermer.TabIndex = 8
        Me.btnFermer.Text = "&Fermer"
        Me.btnFermer.UseVisualStyleBackColor = False
        '
        'lblAuteur
        '
        Me.lblAuteur.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAuteur.Location = New System.Drawing.Point(514, 551)
        Me.lblAuteur.Name = "lblAuteur"
        Me.lblAuteur.Size = New System.Drawing.Size(552, 138)
        Me.lblAuteur.TabIndex = 9
        Me.lblAuteur.Text = resources.GetString("lblAuteur.Text")
        Me.lblAuteur.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmAPropos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 701)
        Me.Controls.Add(Me.lblAuteur)
        Me.Controls.Add(Me.btnFermer)
        Me.Controls.Add(Me.picBackgroundImage)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAPropos"
        Me.Text = "EPTH - Auteur Stevenz Amédée"
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picBackgroundImage As System.Windows.Forms.PictureBox
    Friend WithEvents btnFermer As System.Windows.Forms.Button
    Friend WithEvents lblAuteur As System.Windows.Forms.Label
End Class
