﻿Option Strict On
Public Class frmAide

    Private Sub frmAide_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'DECLARATION ET INITIALISATION DE LA VARIABLE PATH IMG BCK
        Dim strPathImgBackground As String = "imgTapis"
        Dim strTitle As String = "EPTH - AIDE AUX MEMBRES"

        ''OBTENIR LA HAUTEUR LARGEUR DE L ECRAN DE L UTILISATEUR
        Dim intWidthX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intHeighY As Integer = Screen.PrimaryScreen.Bounds.Height


        'INITIALISATION DES VALEURS DE HAUTEUR ET LARGEUR DU FRAME ET POSITIONNEMETN AU CENTRE
        Me.Size = New System.Drawing.Size(1362, 740)
        Me.Location = New Point(CInt((intWidthX / 2) - (Me.Width / 2)), CInt(((intHeighY / 2) - (Me.Height / 2))))

        'AFFECTATION DU BACKGROUND IMAGE
        picBackgroundImage.Image = CType(My.Resources.ResourceManager.GetObject(strPathImgBackground), Image)

        lblAideTitle.Text = strTitle
        lblAideTitle.Parent = picBackgroundImage
        lblAideTitle.BackColor = Color.Transparent

        rtbAideMessage.Parent = picBackgroundImage
        rtbAideMessage.Text = subFntMembre() & vbCr & vbCr & subFntSauvegarde() & vbCr & vbCr & subFntLoadMessageEreurUtilisateur()

    End Sub

    Private Sub btnFermer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFermer.Click

        'FERMER LE FRAME
        Me.Hide()

    End Sub

    Private Function subFntLoadMessageEreurUtilisateur() As String

        'DONNE LA DEFINISTION DES MESSAGE D ERREUR
        Dim msgTitle As String = "Message d'erreur :" & vbCr & vbCr
        Dim msgParagraphe1 As String = "Erreur 3TCF - 3 Tentative Compte Fermé : Votre compte a été verrouillé, après avoir essayé à 3 reprises. Erreur d’adresse courriel ou mot de passe incorrect. Trois essais compte fermé, veuillez communiquez avec l’administration." & vbCr & vbCr
        Dim msgParagraphe2 As String = "Erreur CVPA - Compte verrouillez pour insuffisance de fond. Vous avez perdu la totalité de votre prêt d’étude de 1,000,000.00$. Bonne chance dans la continuiter de votre programme d’étude. Toute fois vous pouvez toujours faire un autre prêt. Veuillez communiquez avec l’administration."
        Dim msgParagraphe As String = msgTitle & msgParagraphe1 & msgParagraphe2

        subFntLoadMessageEreurUtilisateur = msgParagraphe

    End Function

    Private Function subFntSauvegarde() As String

        'DONNE LA DEFINITION SUR LA SAUVEGARDE
        Dim msgTitle As String = "Sauvegarde :" & vbCr & vbCr
        Dim msgParagraphe1 As String = "Sauvegarde : vous pouvez sauvegardez votre partie à tout moment. Dans le Menu Jeu : Sauvegarde" & vbCr & vbCr
        Dim msgParagraphe2 As String = "Sauvegarde automatique : une sauvegarde automatique de votre compte est faite a tous les 3 minutes."
        Dim msgParagraphe As String = msgTitle & msgParagraphe1 & msgParagraphe2

        subFntSauvegarde = msgParagraphe

    End Function

    Private Function subFntMembre() As String

        Dim msgTitle As String = "Membre :" & vbCr & vbCr
        Dim msgParagraphe1 As String = "Devenir Membre : Cette section vous permet de vous enregistrez et de devenir membre de ÉPTH." & vbCr & vbCr
        Dim msgParagraphe2 As String = "Déjà Membre : Cette section vous permet de vous connectez à votre compte." & vbCr & vbCr
        Dim msgParagraphe3 As String = "Commencer La Partie: Dans le Menu Jeu : Commencer, pour debuter toute partie." & vbCr & vbCr
        Dim msgParagraphe4 As String = "Deconnecter : Vous pouvez vous deconnectez de tout partie debuter, vos gain seront automatiquement sauvegarder. Menu Jeu : Deconnecter" & vbCr & vbCr
        Dim msgParagraphe5 As String = "Quitter : Lorsque vous quitter le jeux une sauvegarde est automatiquement effectuée.. Menu Jeu : Quitter"
        Dim msgParagraphe As String = msgTitle & msgParagraphe1 & msgParagraphe2 & msgParagraphe3 & msgParagraphe4 & msgParagraphe5

        subFntMembre = msgParagraphe

    End Function

End Class