﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInscription
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmInscription))
        Me.picBackgroundImage = New System.Windows.Forms.PictureBox()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblDateOfBorn = New System.Windows.Forms.Label()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.lblPasseword = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtDateOfBorn = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.btnRegister = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnQuitter = New System.Windows.Forms.Button()
        Me.btnQuitterInscription = New System.Windows.Forms.Button()
        Me.mnsMenuPoker = New System.Windows.Forms.MenuStrip()
        Me.tsmItemJeu = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAccueil = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDejaMembre = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmQuitter = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmItemHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAide = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAPropos = New System.Windows.Forms.ToolStripMenuItem()
        Me.picImgJettonJoueur = New System.Windows.Forms.PictureBox()
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnsMenuPoker.SuspendLayout()
        CType(Me.picImgJettonJoueur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBackgroundImage
        '
        Me.picBackgroundImage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.picBackgroundImage.Location = New System.Drawing.Point(0, 24)
        Me.picBackgroundImage.Name = "picBackgroundImage"
        Me.picBackgroundImage.Size = New System.Drawing.Size(1346, 677)
        Me.picBackgroundImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBackgroundImage.TabIndex = 0
        Me.picBackgroundImage.TabStop = False
        '
        'lblMessage
        '
        Me.lblMessage.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblMessage.AutoSize = True
        Me.lblMessage.BackColor = System.Drawing.Color.Transparent
        Me.lblMessage.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblMessage.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblMessage.Location = New System.Drawing.Point(189, 135)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(991, 60)
        Me.lblMessage.TabIndex = 1
        Me.lblMessage.Text = "Devenez membre de EPTM : Emica Poker Time Holdem"
        '
        'lblFirstName
        '
        Me.lblFirstName.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.BackColor = System.Drawing.Color.Transparent
        Me.lblFirstName.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblFirstName.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblFirstName.Location = New System.Drawing.Point(547, 201)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(131, 60)
        Me.lblFirstName.TabIndex = 2
        Me.lblFirstName.Text = "Nom :"
        '
        'lblLastName
        '
        Me.lblLastName.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblLastName.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblLastName.Location = New System.Drawing.Point(500, 290)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(178, 60)
        Me.lblLastName.TabIndex = 3
        Me.lblLastName.Text = "Prénom :"
        '
        'lblDateOfBorn
        '
        Me.lblDateOfBorn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblDateOfBorn.AutoSize = True
        Me.lblDateOfBorn.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblDateOfBorn.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblDateOfBorn.Location = New System.Drawing.Point(313, 359)
        Me.lblDateOfBorn.Name = "lblDateOfBorn"
        Me.lblDateOfBorn.Size = New System.Drawing.Size(365, 60)
        Me.lblDateOfBorn.TabIndex = 4
        Me.lblDateOfBorn.Text = "Année de naissance :"
        '
        'lblUserName
        '
        Me.lblUserName.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblUserName.AutoSize = True
        Me.lblUserName.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblUserName.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblUserName.Location = New System.Drawing.Point(359, 441)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(319, 60)
        Me.lblUserName.TabIndex = 5
        Me.lblUserName.Text = "Adresse Courriel :"
        '
        'lblPasseword
        '
        Me.lblPasseword.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblPasseword.AutoSize = True
        Me.lblPasseword.Font = New System.Drawing.Font("Palace Script MT", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.lblPasseword.ForeColor = System.Drawing.Color.DodgerBlue
        Me.lblPasseword.Location = New System.Drawing.Point(422, 543)
        Me.lblPasseword.Name = "lblPasseword"
        Me.lblPasseword.Size = New System.Drawing.Size(256, 60)
        Me.lblPasseword.TabIndex = 6
        Me.lblPasseword.Text = "Mot de passe :"
        '
        'txtFirstName
        '
        Me.txtFirstName.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtFirstName.BackColor = System.Drawing.Color.LightGray
        Me.txtFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.Location = New System.Drawing.Point(698, 230)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(309, 31)
        Me.txtFirstName.TabIndex = 7
        '
        'txtLastName
        '
        Me.txtLastName.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtLastName.BackColor = System.Drawing.Color.LightGray
        Me.txtLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!)
        Me.txtLastName.Location = New System.Drawing.Point(698, 319)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(309, 31)
        Me.txtLastName.TabIndex = 8
        '
        'txtDateOfBorn
        '
        Me.txtDateOfBorn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtDateOfBorn.BackColor = System.Drawing.Color.LightGray
        Me.txtDateOfBorn.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!)
        Me.txtDateOfBorn.Location = New System.Drawing.Point(698, 388)
        Me.txtDateOfBorn.MaxLength = 4
        Me.txtDateOfBorn.Name = "txtDateOfBorn"
        Me.txtDateOfBorn.Size = New System.Drawing.Size(309, 31)
        Me.txtDateOfBorn.TabIndex = 9
        '
        'txtUsername
        '
        Me.txtUsername.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtUsername.BackColor = System.Drawing.Color.LightGray
        Me.txtUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!)
        Me.txtUsername.Location = New System.Drawing.Point(698, 470)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(309, 31)
        Me.txtUsername.TabIndex = 10
        '
        'txtPassword
        '
        Me.txtPassword.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtPassword.BackColor = System.Drawing.Color.LightGray
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.Location = New System.Drawing.Point(698, 572)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(309, 31)
        Me.txtPassword.TabIndex = 11
        Me.txtPassword.UseSystemPasswordChar = True
        '
        'btnRegister
        '
        Me.btnRegister.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRegister.AutoEllipsis = True
        Me.btnRegister.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRegister.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnRegister.Location = New System.Drawing.Point(834, 650)
        Me.btnRegister.Name = "btnRegister"
        Me.btnRegister.Size = New System.Drawing.Size(250, 39)
        Me.btnRegister.TabIndex = 12
        Me.btnRegister.Text = "&Inscription"
        Me.btnRegister.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClear.AutoEllipsis = True
        Me.btnClear.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClear.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnClear.Location = New System.Drawing.Point(578, 650)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(250, 39)
        Me.btnClear.TabIndex = 13
        Me.btnClear.Text = "&Effacer Tout"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnQuitter
        '
        Me.btnQuitter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnQuitter.AutoEllipsis = True
        Me.btnQuitter.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnQuitter.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnQuitter.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnQuitter.Location = New System.Drawing.Point(1090, 650)
        Me.btnQuitter.Name = "btnQuitter"
        Me.btnQuitter.Size = New System.Drawing.Size(250, 39)
        Me.btnQuitter.TabIndex = 14
        Me.btnQuitter.Text = "&Quitter le jeux"
        Me.btnQuitter.UseVisualStyleBackColor = False
        '
        'btnQuitterInscription
        '
        Me.btnQuitterInscription.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnQuitterInscription.AutoEllipsis = True
        Me.btnQuitterInscription.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnQuitterInscription.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnQuitterInscription.Font = New System.Drawing.Font("Harrington", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnQuitterInscription.Location = New System.Drawing.Point(322, 650)
        Me.btnQuitterInscription.Name = "btnQuitterInscription"
        Me.btnQuitterInscription.Size = New System.Drawing.Size(250, 39)
        Me.btnQuitterInscription.TabIndex = 15
        Me.btnQuitterInscription.Text = "&Accueil"
        Me.btnQuitterInscription.UseVisualStyleBackColor = False
        '
        'mnsMenuPoker
        '
        Me.mnsMenuPoker.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmItemJeu, Me.tsmItemHelp})
        Me.mnsMenuPoker.Location = New System.Drawing.Point(0, 0)
        Me.mnsMenuPoker.Name = "mnsMenuPoker"
        Me.mnsMenuPoker.Size = New System.Drawing.Size(1346, 24)
        Me.mnsMenuPoker.TabIndex = 16
        Me.mnsMenuPoker.Text = "MenuStrip1"
        '
        'tsmItemJeu
        '
        Me.tsmItemJeu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAccueil, Me.tsmDejaMembre, Me.tsmQuitter})
        Me.tsmItemJeu.Name = "tsmItemJeu"
        Me.tsmItemJeu.Size = New System.Drawing.Size(42, 20)
        Me.tsmItemJeu.Text = "Jeux"
        '
        'tsmAccueil
        '
        Me.tsmAccueil.Name = "tsmAccueil"
        Me.tsmAccueil.Size = New System.Drawing.Size(145, 22)
        Me.tsmAccueil.Text = "Acceuil"
        '
        'tsmDejaMembre
        '
        Me.tsmDejaMembre.Name = "tsmDejaMembre"
        Me.tsmDejaMembre.Size = New System.Drawing.Size(145, 22)
        Me.tsmDejaMembre.Text = "Deja Membre"
        '
        'tsmQuitter
        '
        Me.tsmQuitter.Name = "tsmQuitter"
        Me.tsmQuitter.Size = New System.Drawing.Size(145, 22)
        Me.tsmQuitter.Text = "Quitter"
        '
        'tsmItemHelp
        '
        Me.tsmItemHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAide, Me.tsmAPropos})
        Me.tsmItemHelp.Name = "tsmItemHelp"
        Me.tsmItemHelp.Size = New System.Drawing.Size(24, 20)
        Me.tsmItemHelp.Text = "?"
        '
        'tsmAide
        '
        Me.tsmAide.Name = "tsmAide"
        Me.tsmAide.Size = New System.Drawing.Size(122, 22)
        Me.tsmAide.Text = "Aide"
        '
        'tsmAPropos
        '
        Me.tsmAPropos.Name = "tsmAPropos"
        Me.tsmAPropos.Size = New System.Drawing.Size(122, 22)
        Me.tsmAPropos.Text = "A Propos"
        '
        'picImgJettonJoueur
        '
        Me.picImgJettonJoueur.Location = New System.Drawing.Point(12, 230)
        Me.picImgJettonJoueur.Name = "picImgJettonJoueur"
        Me.picImgJettonJoueur.Size = New System.Drawing.Size(318, 373)
        Me.picImgJettonJoueur.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picImgJettonJoueur.TabIndex = 17
        Me.picImgJettonJoueur.TabStop = False
        '
        'frmInscription
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 701)
        Me.Controls.Add(Me.picImgJettonJoueur)
        Me.Controls.Add(Me.btnQuitterInscription)
        Me.Controls.Add(Me.btnQuitter)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnRegister)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtUsername)
        Me.Controls.Add(Me.txtDateOfBorn)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.lblPasseword)
        Me.Controls.Add(Me.lblUserName)
        Me.Controls.Add(Me.lblDateOfBorn)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.picBackgroundImage)
        Me.Controls.Add(Me.mnsMenuPoker)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnsMenuPoker
        Me.Name = "frmInscription"
        Me.Text = "EPTH - Emica Poker Time Holdem : Inscription"
        CType(Me.picBackgroundImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnsMenuPoker.ResumeLayout(False)
        Me.mnsMenuPoker.PerformLayout()
        CType(Me.picImgJettonJoueur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picBackgroundImage As System.Windows.Forms.PictureBox
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblDateOfBorn As System.Windows.Forms.Label
    Friend WithEvents lblUserName As System.Windows.Forms.Label
    Friend WithEvents lblPasseword As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtDateOfBorn As System.Windows.Forms.TextBox
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents btnRegister As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnQuitter As System.Windows.Forms.Button
    Friend WithEvents btnQuitterInscription As System.Windows.Forms.Button
    Friend WithEvents mnsMenuPoker As System.Windows.Forms.MenuStrip
    Friend WithEvents tsmItemJeu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAccueil As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmDejaMembre As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmQuitter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmItemHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAide As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAPropos As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents picImgJettonJoueur As System.Windows.Forms.PictureBox
End Class
